from __future__ import annotations

import sys

sys.path.append('resources')

import __main__
import asyncio
import copy
import inspect
import itertools
import random
import re
import types
import typing
from abc import ABCMeta
from collections import defaultdict
from collections.abc import Generator, Iterable, Iterator
from enum import Enum
from typing import Any, Self, TypeVar
from unittest import mock

import chess

from resources import utils
from resources.backend import server

_LETTERS_FORMAT_LEFT_MARGIN = 4
_LETTERS_FORMAT_WIDTH = 9
_MAX_TYPE_HINTS_SCORE = 76
_NUMERIC_FORMAT_WIDTH = 7
_RANDOM_MOVES = 20


class _Mock:
    def __init__(self, **kwargs) -> None:
        for k, v in kwargs.items():
            setattr(self, k, v)


class _UniqueList(list):
    def __iadd__(self, other: Iterable) -> Self:
        for element in other:
            if element not in self:
                self.append(element)

        return self


def _assert_methods_type_hints(
    class_: type,
    type_hint_checks: tuple[tuple[tuple[str, dict[str, Any], Any], ...], ...]
) -> tuple[int, list[str]]:
    score = 0
    failed_methods = _UniqueList()
    if not type_hint_checks:
        return score, failed_methods

    for method_alternative_checks in type_hint_checks:
        is_implemented = False
        failed_method_alternatives = []
        for method_name, expected_parameter_types, return_type in method_alternative_checks:
            method = getattr(class_, method_name, None)
            try:
                if isinstance(method, property):
                    assert method.fget
                    method = method.fget
                elif not inspect.isfunction(method):
                    continue

                is_implemented = True
                actual_parameter_types = typing.get_type_hints(method)
                assert 'return' in actual_parameter_types
                assert _compare_types(return_type, actual_parameter_types.pop('return'))
                _assert_parameter_types(expected_parameter_types, actual_parameter_types)
            except AssertionError:
                failed_method_alternatives.append(str(method.__qualname__))
            else:
                break

        if not is_implemented or len(failed_method_alternatives) != len(method_alternative_checks):
            score += 1
        else:
            failed_methods.append(failed_method_alternatives[0])

    return score, failed_methods


def _assert_parameter_types(expected_parameter_types: dict[str, type], actual_parameter_types: dict[str, type]) -> None:
    if any(k.startswith('_') for k in expected_parameter_types):
        expected_types = list(expected_parameter_types.values())
        for actual_type in actual_parameter_types.values():
            for expected_type in expected_types:
                if _compare_types(expected_type, actual_type):
                    expected_types.remove(actual_type)
                    break
            else:
                are_same = False
                break
        else:
            are_same = not expected_types
        assert are_same
    else:
        expected_parameter_type_items = sorted(expected_parameter_types.items())
        actual_parameter_type_items = sorted(actual_parameter_types.items())
        assert len(expected_parameter_type_items) == len(actual_parameter_type_items)

        for (expected_k, expected_v), (actual_k, actual_v) in zip(
            expected_parameter_type_items,
            actual_parameter_type_items
        ):
            assert expected_k == actual_k
            assert _compare_types(expected_v, actual_v)


def _compare_generic_args(expected_args: list, actual_args: list) -> bool:
    if expected_args == actual_args:
        return True

    generics_expected_positions_items = defaultdict(list)
    generics_actual_positions_items = defaultdict(list)

    for i, (expected_arg, actual_arg) in enumerate(itertools.zip_longest(expected_args, actual_args)):
        if not isinstance(expected_arg, TypeVar) or not isinstance(actual_arg, TypeVar):
            return False

        generics_expected_positions_items[expected_arg].append(i)
        generics_actual_positions_items[expected_arg].append(i)

    remained_generic_expected_positions = list(generics_expected_positions_items.values())
    for generic_expected_positions in generics_actual_positions_items.values():
        remained_generic_expected_positions.remove(generic_expected_positions)

    return not remained_generic_expected_positions


def _compare_pieces(pieces_a: Iterable[__main__.Piece], pieces_b: Iterable[__main__.Piece]) -> bool:
    pieces_a = list(pieces_a)
    for piece_b in pieces_b:
        if not pieces_a:
            return False

        pieces_a.remove(piece_b)

    return not pieces_a


def _compare_types(expected: Any, actual: Any) -> bool:
    expected_origin = _get_type_origin(expected)
    actual_origin = _get_type_origin(actual)
    expected_args = _get_type_args(expected)
    actual_args = _get_type_args(actual)

    if _compare_generic_args(expected_args, actual_args):
        actual_args = expected_args

    return (
        expected_origin is actual_origin
        and
        (
            not expected_args
            and
            not actual_args or expected_origin[*expected_args] == actual_origin[*actual_args]
        )
    )


def _format_chapter(function_name: str, numbers=False) -> str:
    numbered_chapter = f"{function_name.replace('_test_', '').replace('_', '.')}"
    if numbers:
        return numbered_chapter

    numbers_ = [int(number) for number in numbered_chapter.split('.')]
    parts = [f'{_number_to_roman(numbers_[0]):>{_LETTERS_FORMAT_LEFT_MARGIN}}']
    for number in numbers_[1:]:
        parts.append(f'.{chr(96 + number)}')

    return ''.join(parts)


def _get_board_str(board_list: list[list[__main__.Piece | None]]) -> str:
    lines = []
    for row in board_list:
        line_parts = []
        for piece in row:
            if piece:
                line_parts.append(str(piece))
            else:
                line_parts.append('ㅤ')

        lines.append(' '.join(line_parts))

    return '\n'.join(lines)


def _get_lineal_moveset(
    piece: __main__.Piece,
    board_list: list[list[__main__.Piece | None]],
    directions: Iterable[tuple[int, int]] | None = (),
    limit: int | None = None,
    can_capture: bool = True
) -> list[tuple[int, int]]:
    positions = []
    if limit is None:
        limit = len(board_list)

    for vertical_direction, horizontal_direction in directions:
        new_row = piece.row
        new_column = piece.column
        for _ in range(limit):
            new_row += vertical_direction
            new_column += horizontal_direction
            if not _is_in_bounds(board_list, new_row, new_column):
                break

            if target_piece := board_list[new_row][new_column]:
                # noinspection PyProtectedMember,PyUnresolvedReferences
                if target_piece._color != piece._color and can_capture:
                    positions.append((new_row, new_column))

                break

            positions.append((new_row, new_column))

    return positions


def _get_moveset_at(chess_board: chess.Board, color: __main__.Color, row: int, column: int) -> set[tuple[int, int]]:
    moveset = set()
    chess_board.turn = utils.color_to_chess_color(color)
    for pseudo_legal_move in chess_board.pseudo_legal_moves:
        current_position = utils.chess_square_to_position(pseudo_legal_move.from_square)
        new_position = utils.chess_square_to_position(pseudo_legal_move.to_square)
        if current_position == (row, column):
            moveset.add(new_position)

    return moveset


def _get_type_args(type_: Any) -> list:
    return [None if arg is type(None) else arg for arg in typing.get_args(type_)]


def _get_type_origin(type_: Any) -> Any:
    if origin := typing.get_origin(type_):
        if origin is types.UnionType:
            return typing.Union

        return origin

    return None if type_ is type(None) else type_


def _is_in_bounds(board_list: list[list[__main__.Piece | None]], row: int, column: int) -> bool:
    return row in range(len(board_list)) and column in range(len(board_list))


def _iter_pieces[T](
    board_list: list[list[__main__.Piece | None]],
    color: __main__.Color | None = None,
    piece_class: type[T] = None
) -> Iterator[T]:
    piece_class = piece_class or __main__.Piece

    for row in board_list:
        for piece in row:
            # noinspection PyProtectedMember
            if isinstance(piece, piece_class) and (not color or piece._color is color):
                yield piece


async def _main(
    pawn: __main__.Pawn | None = None,
    knight: __main__.Knight | None = None,
    bishop: __main__.Bishop | None = None,
    rook: __main__.Rook | None = None,
    queen: __main__.Queen | None = None,
    king: __main__.King | None = None,
    board: __main__.Board | None = None,
    numbers=False,
    random_boards=10,
    play_game=True
) -> None:
    tasks = []

    if play_game:
        tasks.append(server.run_server(pawn, knight, bishop, rook, queen, king, board))

    tasks.append(_test(pawn, knight, bishop, rook, queen, king, board, numbers, random_boards))

    await asyncio.gather(*tasks)


def _number_to_roman(number: int) -> str:
    roman_numbers = {
        1000: "m",
        900: "cm",
        500: "d",
        400: "cd",
        100: "c",
        90: "xc",
        50: "l",
        40: "xl",
        10: "x",
        9: "ix",
        5: "v",
        4: "iv",
        1: "i"
    }

    def roman_generator(number_: int) -> Iterator[str]:
        for roman_value in roman_numbers:
            quotient, _ = divmod(number_, roman_value)
            yield roman_numbers[roman_value] * quotient
            number_ -= roman_value * quotient
            if number_ <= 0:
                break

    return ''.join(roman_generator(number))


def _re_find_internal_uses(class_: type) -> set[str]:
    internal_uses = set()
    for member in vars(class_).values():
        if not inspect.isfunction(member):
            continue

        source = inspect.getsource(member).split('\n', maxsplit=1)[1]
        internal_uses.update(_re_findall_without_comments(r'\.(_\w*)', source))

    return internal_uses


def _re_findall_without_comments(pattern: str, text: str) -> list[str]:
    return re.findall(f'^(?!.*#).*{pattern}', text, re.MULTILINE)


async def _test(
    pawn: __main__.Pawn | None = None,
    knight: __main__.Knight | None = None,
    bishop: __main__.Bishop | None = None,
    rook: __main__.Rook | None = None,
    queen: __main__.Queen | None = None,
    king: __main__.King | None = None,
    board: __main__.Board | None = None,
    numbers=False,
    random_boards=10
) -> None:
    def add_args(class_name_: str, piece_: Any) -> None:
        if class_name_.lower() in parameters:
            if not (piece_class := getattr(__main__, class_name_, None)) or not isinstance(piece_, piece_class):
                raise NotImplementedError

            args.append(copy.copy(piece_))

    format_width = _NUMERIC_FORMAT_WIDTH if numbers else _LETTERS_FORMAT_WIDTH

    for function_name, function in globals().items():
        if not function_name.startswith('_test_'):
            continue

        args = []
        result_prefix = f'{_format_chapter(function_name, numbers):{format_width}}'
        parameters = list(parameter_name.strip('_') for parameter_name in inspect.signature(function).parameters)

        class_names = ('Pawn', 'Knight', 'Bishop', 'Rook', 'Queen', 'King', 'Board')
        objects = (pawn, knight, bishop, rook, queen, king, board)

        try:
            for class_name, piece in zip(class_names, objects):
                add_args(class_name, piece)

            if 'random_boards' in parameters:
                args.append(random_boards)

            result = await function(*args)
        except NotImplementedError:
            result_message = '...'
        except ReferenceError as e:
            cause_function_name = e.__context__.__traceback__.tb_next.tb_frame.f_code.co_name
            failed_required_chapter = f' <- {_format_chapter(cause_function_name, numbers)}'
            result_message = f'❌{failed_required_chapter}'
        except AssertionError as e:
            result_message = f"❌{f' {e}' if str(e) else ''}"
        except Exception as e:
            traceback = e.__traceback__
            while traceback.tb_next:
                traceback = traceback.tb_next
            if (f_code := traceback.tb_frame.f_code).co_filename.endswith('main.py'):
                message = f'{e} ➡️ in {f_code.co_qualname}'
            else:
                message = str(e)
            result_message = f"❌{' ' if str(e) else ''}{message}"
        else:
            if function_name == '_test_1':
                ratio, _ = result
                result_message = f"{'✅' if ratio == 1 else '❌'} {ratio:.0%}"
            else:
                result_message = '✅'

        print(f'{result_prefix}{result_message}')


async def _test_1() -> tuple[float, list[str]]:
    if not any(
        hasattr(__main__, class_name) for class_name in (
            'OutOfBoundsError',
            'NoPieceError',
            'SamePositionError',
            'Color',
            'Piece',
            'LinealPiece',
            'AxialPiece',
            'DiagonalPiece',
            'Pawn',
            'Knight',
            'Bishop',
            'Rook',
            'Queen',
            'King',
            'Board'
        )
    ):
        raise NotImplementedError

    if not all(hasattr(__main__, class_name) for class_name in ('Piece', 'Board')):
        return _MAX_TYPE_HINTS_SCORE, []

    total_score = 0
    all_failed_methods = _UniqueList()

    if isinstance(getattr(__main__, 'OutOfBoundsError', None), type):
        score, failed_methods = _assert_methods_type_hints(__main__.OutOfBoundsError, ((('__init__', {}, None),),))
        total_score += score
        all_failed_methods += failed_methods
    else:
        total_score += 1

    if isinstance(getattr(__main__, 'NoPieceError', None), type):
        score, failed_methods = _assert_methods_type_hints(
            __main__.NoPieceError,
            (
                (('__init__', {'row': int, 'column': int}, None),),
            )
        )
        total_score += score
        all_failed_methods += failed_methods
    else:
        total_score += 1

    if isinstance(getattr(__main__, 'SamePositionError', None), type):
        score, failed_methods = _assert_methods_type_hints(__main__.SamePositionError, ((('__init__', {}, None),),))
        total_score += score
        all_failed_methods += failed_methods
    else:
        total_score += 1

    if isinstance(getattr(__main__, 'Color', None), type):
        score, failed_methods = _assert_methods_type_hints(__main__.Color, ((('opposite', {}, Self),),))
        total_score += score
        all_failed_methods += failed_methods

        for class_name in ('Piece', 'Pawn', 'Knight', 'Bishop', 'Rook', 'Queen', 'King'):
            if not isinstance(piece_class := getattr(__main__, class_name, None), type):
                total_score += 8
                continue

            score, failed_methods = _assert_methods_type_hints(
                piece_class,
                (
                    (('__init__', {'color': __main__.Color, 'row': int, 'column': int}, None),),
                    (('__eq__', {'_other': Any}, bool),),
                    (('__repr__', {}, str),),
                    (('color', {}, __main__.Color),),
                    (('get_moveset', {'_board': __main__.Board}, list[tuple[int, int]]),),
                    (('is_attacking_to', {'_board': __main__.Board, '_piece': __main__.Piece}, bool),),
                    (('move', {'_board': __main__.Board, '_row': int, '_column': int}, None),),
                    (('svg', {}, str),)
                )
            )
            total_score += score
            all_failed_methods += failed_methods

        if isinstance(getattr(__main__, 'King', None), type):
            # noinspection PyPep8Naming
            T = TypeVar('T')
            score, failed_methods = _assert_methods_type_hints(
                __main__.Board,
                (
                    (
                        ('__init__', {'fen_board': str | None}, None),
                        ('__init__', {'fen_board': str | None, 'human_color': __main__.Color}, None),
                    ),
                    (('__getitem__', {'_index': int}, list[__main__.Piece | None]),),
                    (
                        ('__iter__', {}, Iterator[list[__main__.Piece | None]]),
                        ('__iter__', {}, Generator[list[__main__.Piece | None], None, None])
                    ),
                    (('__len__', {}, int),),
                    (('__str__', {}, str), ('__repr__', {}, str)),
                    (
                        (
                            'iter_pieces',
                            {'color': __main__.Color | None, 'piece_class': type[T]},
                            Iterator[T]
                        ),
                        (
                            'iter_pieces',
                            {'color': __main__.Color | None, 'piece_class': type[T]},
                            Generator[T, None, None]
                        )
                    ),
                    (('get_king', {'_color': __main__.Color}, __main__.King),),
                    (('get_moveset_at', {'_row': int, '_column': int}, list[tuple[int, int]]),),
                    (('get_score', {'_color': __main__.Color}, int),),
                    (('is_check', {'_color': __main__.Color}, bool),),
                    (('is_checkmate', {'_color': __main__.Color}, bool),),
                    (('is_in_bounds', {'_row': int, '_column': int}, bool),),
                    (('load_fen', {'_fen_board': str}, None),)
                )
            )
            total_score += score
            all_failed_methods += failed_methods
        else:
            total_score += 13
    else:
        total_score += 1 + 8 * 7 + 13

    for class_name in ('LinealPiece', 'AxialPiece', 'DiagonalPiece'):
        if not isinstance(piece_class := getattr(__main__, class_name, None), type):
            total_score += 1
            continue

        score, failed_methods = _assert_methods_type_hints(
            piece_class,
            (
                (
                    (
                        'get_lineal_moveset',
                        {
                            'board': __main__.Board,
                            'directions': Iterable[tuple[int, int]],
                            'limit': int | None
                        },
                        list[tuple[int, int]]
                    ),
                    (
                        'get_lineal_moveset',
                        {
                            'board': __main__.Board,
                            'directions': Iterable[tuple[int, int]],
                            'limit': int | None,
                            'can_capture': bool
                        },
                        list[tuple[int, int]]
                    ),
                ),
            )
        )
        total_score += score
        all_failed_methods += failed_methods

    return total_score / _MAX_TYPE_HINTS_SCORE, all_failed_methods


async def _test_2_1() -> None:
    if not hasattr(__main__, 'OutOfBoundsError'):
        raise NotImplementedError

    assert issubclass(__main__.OutOfBoundsError, IndexError)
    assert str(__main__.OutOfBoundsError()) == 'position must be within board bounds'


async def _test_2_2() -> None:
    if not hasattr(__main__, 'NoPieceError'):
        raise NotImplementedError

    assert issubclass(__main__.NoPieceError, LookupError)
    for row in range(utils.BOARD_LENGTH):
        for column in range(utils.BOARD_LENGTH):
            assert str(__main__.NoPieceError(row, column)) == f'there is no piece at position ({row}, {column})'


async def _test_2_3() -> None:
    if not hasattr(__main__, 'SamePositionError'):
        raise NotImplementedError

    assert issubclass(__main__.SamePositionError, ValueError)
    assert str(__main__.SamePositionError()) == 'the piece is already at the target position'


async def _test_3_1() -> None:
    if not hasattr(__main__, 'Color'):
        raise NotImplementedError

    assert issubclass(__main__.Color, Enum)
    assert {member.name for member in __main__.Color} == {'WHITE', 'BLACK'}


async def _test_3_2() -> None:
    if not hasattr(__main__, 'Color') or not hasattr(__main__.Color, 'opposite'):
        raise NotImplementedError

    try:
        await _test_3_1()
    except (AssertionError, NotImplementedError):
        raise ReferenceError

    property_ = __main__.Color.opposite
    assert isinstance(property_, property) and property_.fget and not property_.fset and not property_.fdel
    assert (
        __main__.Color.WHITE.opposite is __main__.Color.BLACK
        and
        __main__.Color.WHITE.opposite is __main__.Color.BLACK
    )


async def _test_4_1() -> None:
    has_classes = [
        hasattr(__main__, class_name) for class_name in (
            'Piece',
            'LinealPiece',
            'AxialPiece',
            'DiagonalPiece',
            'Pawn',
            'Knight',
            'Bishop',
            'Rook',
            'Queen',
            'King'
        )
    ]
    if not any(has_classes):
        raise NotImplementedError
    elif not all(has_classes):
        raise AssertionError

    assert all(
        isinstance(piece_class, ABCMeta) for piece_class in (
            __main__.Piece,
            __main__.LinealPiece,
            __main__.AxialPiece,
            __main__.DiagonalPiece
        )
    )
    assert issubclass(__main__.LinealPiece, __main__.Piece)
    assert issubclass(__main__.AxialPiece, __main__.LinealPiece)
    assert issubclass(__main__.DiagonalPiece, __main__.LinealPiece)
    assert issubclass(__main__.Pawn, __main__.AxialPiece)
    assert issubclass(__main__.Knight, __main__.Piece)
    assert issubclass(__main__.Bishop, __main__.DiagonalPiece)
    assert issubclass(__main__.Rook, __main__.AxialPiece)
    assert issubclass(__main__.Queen, __main__.AxialPiece) and issubclass(__main__.Queen, __main__.DiagonalPiece)
    assert issubclass(__main__.King, __main__.AxialPiece) and issubclass(__main__.King, __main__.DiagonalPiece)
    assert __main__.Piece.__abstractmethods__ == {'__repr__', 'get_moveset', 'svg'}
    assert __main__.LinealPiece.__abstractmethods__ == {'__repr__', 'get_lineal_moveset', 'get_moveset', 'svg'}
    assert __main__.AxialPiece.__abstractmethods__ == {'__repr__', 'get_moveset', 'svg'}
    assert __main__.DiagonalPiece.__abstractmethods__ == {'__repr__', 'get_moveset', 'svg'}
    assert not __main__.Pawn.__abstractmethods__
    assert not __main__.Knight.__abstractmethods__
    assert not __main__.Bishop.__abstractmethods__
    assert not __main__.Rook.__abstractmethods__
    assert not __main__.Queen.__abstractmethods__
    assert not __main__.King.__abstractmethods__


async def _test_4_2_1(
    pawn: __main__.Pawn,
    knight: __main__.Knight,
    bishop: __main__.Bishop,
    rook: __main__.Rook,
    queen: __main__.Queen,
    king: __main__.King
) -> None:
    pieces = (pawn, knight, bishop, rook, queen, king)

    if not any(hasattr(piece, '_color') for piece in pieces):
        raise NotImplementedError

    try:
        await _test_3_1()
    except (AssertionError, NotImplementedError):
        raise ReferenceError

    for piece in pieces:
        assert isinstance(getattr(piece, '_color', None), __main__.Color)


async def _test_4_2_2(
    pawn: __main__.Pawn,
    knight: __main__.Knight,
    bishop: __main__.Bishop,
    rook: __main__.Rook,
    queen: __main__.Queen,
    king: __main__.King
) -> None:
    pieces = (pawn, knight, bishop, rook, queen, king)

    if not any(hasattr(piece, 'row') for piece in pieces):
        raise NotImplementedError

    for piece in pieces:
        assert isinstance(getattr(piece, 'row', None), int)


async def _test_4_2_3(
    pawn: __main__.Pawn,
    knight: __main__.Knight,
    bishop: __main__.Bishop,
    rook: __main__.Rook,
    queen: __main__.Queen,
    king: __main__.King
) -> None:
    pieces = (pawn, knight, bishop, rook, queen, king)

    if not any(hasattr(piece, 'column') for piece in pieces):
        raise NotImplementedError

    for piece in pieces:
        assert isinstance(getattr(piece, 'column', None), int)


async def _test_4_2_4(
    pawn: __main__.Pawn,
    knight: __main__.Knight,
    bishop: __main__.Bishop,
    rook: __main__.Rook,
    queen: __main__.Queen,
    king: __main__.King
) -> None:
    if not any(hasattr(piece, 'has_moved') for piece in (pawn, knight, bishop, rook, queen, king)):
        raise NotImplementedError

    try:
        await _test_3_1()
        await _test_4_2_1(pawn, knight, bishop, rook, queen, king)
        await _test_4_2_2(pawn, knight, bishop, rook, queen, king)
        await _test_4_2_3(pawn, knight, bishop, rook, queen, king)
    except (AssertionError, NotImplementedError):
        raise ReferenceError

    for piece in (knight, bishop, rook, queen, king):
        assert isinstance(getattr(piece, 'has_moved', None), bool)
        piece_vars = {k: v for k, v in vars(piece).items() if k not in {'_color', 'has_moved'}}
        # noinspection PyProtectedMember
        piece_vars['color'] = piece._color
        assert not type(piece)(**piece_vars).has_moved

    assert not type(piece)(__main__.Color.WHITE, 6, 6).has_moved
    assert not type(piece)(__main__.Color.BLACK, 1, 1).has_moved
    for row, column in itertools.product(range(6), repeat=2):
        assert type(pawn)(__main__.Color.WHITE, row, column).has_moved
    for row, column in itertools.product(range(2, 8), repeat=2):
        assert type(pawn)(__main__.Color.BLACK, row, column).has_moved


async def _test_4_3(
    pawn: __main__.Pawn,
    knight: __main__.Knight,
    bishop: __main__.Bishop,
    rook: __main__.Rook,
    queen: __main__.Queen
) -> None:
    pieces = (pawn, knight, bishop, rook, queen)
    if not any(hasattr(type(piece), 'value') for piece in (pawn, knight, bishop, rook, queen)):
        raise NotImplementedError

    values = (1, 3, 3, 5, 9)
    for piece, value in zip(pieces, values):
        assert isinstance(getattr(type(piece), 'value', None), int)
        assert piece.value == value


async def _test_4_4(
    pawn: __main__.Pawn,
    knight: __main__.Knight,
    bishop: __main__.Bishop,
    rook: __main__.Rook,
    queen: __main__.Queen,
    king: __main__.King
) -> None:
    pieces = (pawn, knight, bishop, rook, queen, king)

    if not any(inspect.ismethod(piece.__eq__) for piece in pieces):
        raise NotImplementedError

    try:
        # noinspection DuplicatedCode
        await _test_3_1()
        await _test_4_2_1(pawn, knight, bishop, rook, queen, king)
        await _test_4_2_2(pawn, knight, bishop, rook, queen, king)
        await _test_4_2_3(pawn, knight, bishop, rook, queen, king)
        await _test_4_2_4(pawn, knight, bishop, rook, queen, king)
    except (AssertionError, NotImplementedError):
        raise ReferenceError

    for piece in pieces:
        piece_1 = copy.copy(piece)
        piece_2 = copy.copy(piece)
        assert piece_1 == piece_2
        piece_1._color = __main__.Color.WHITE
        piece_2._color = __main__.Color.BLACK
        assert piece_1 != piece_2
        piece_2._color = __main__.Color.WHITE
        piece_1.row = 1
        piece_2.row = 2
        assert piece_1 != piece_2
        piece_2.row = 1
        piece_1.column = 1
        piece_2.column = 2
        assert piece_1 != piece_2
        piece_2.column = 1
        piece_1.has_moved = False
        piece_2.has_moved = True
        assert piece_1 != piece_2
        piece_2.has_moved = False
        if hasattr(type(piece_1), 'value'):
            piece_1.value = 1
            piece_2.value = 2
            assert piece_1 != piece_2

        mock_ = _Mock(**vars(piece_1))
        assert piece_1 != mock_
        mock_.row = 2
        assert piece_1 != mock_

    color = __main__.Color.WHITE
    row = 1
    column = 1
    for piece_1, piece_2 in itertools.combinations(pieces, 2):
        assert type(piece_1)(color, row, column) != type(piece_2)(color, row, column)


async def _test_4_5(
    pawn: __main__.Pawn,
    knight: __main__.Knight,
    bishop: __main__.Bishop,
    rook: __main__.Rook,
    queen: __main__.Queen,
    king: __main__.King
) -> None:
    pieces = (pawn, knight, bishop, rook, queen, king)

    if not any(inspect.ismethod(piece.__repr__) for piece in pieces):
        raise NotImplementedError

    try:
        await _test_3_1()
        await _test_4_2_1(pawn, knight, bishop, rook, queen, king)
    except (AssertionError, NotImplementedError):
        raise ReferenceError

    characters = (('♙', '♟'), ('♘', '♞'), ('♗', '♝'), ('♖', '♜'), ('♕', '♛'), ('♔', '♚'))
    for piece, (white_character, black_character) in zip(pieces, characters):
        piece._color = __main__.Color.WHITE
        assert repr(piece) == white_character
        piece._color = __main__.Color.BLACK
        assert repr(piece) == black_character


async def _test_4_6(
    pawn: __main__.Pawn,
    knight: __main__.Knight,
    bishop: __main__.Bishop,
    rook: __main__.Rook,
    queen: __main__.Queen,
    king: __main__.King
) -> None:
    pieces = (pawn, knight, bishop, rook, queen, king)

    if not any(hasattr(type(piece), 'color') for piece in pieces):
        raise NotImplementedError

    try:
        await _test_4_2_1(pawn, knight, bishop, rook, queen, king)
    except (AssertionError, NotImplementedError):
        raise ReferenceError

    for piece in pieces:
        property_ = getattr(type(piece), 'color', None)
        assert isinstance(property_, property) and property_.fget and not property_.fset and not property_.fdel
        # noinspection PyProtectedMember
        assert piece.color == piece._color


async def _test_4_7(
    pawn: __main__.Pawn,
    knight: __main__.Knight,
    bishop: __main__.Bishop,
    rook: __main__.Rook,
    queen: __main__.Queen,
    king: __main__.King,
    board: __main__.Board,
    random_boards: int
) -> None:
    lineal_piece_class_names = ('LinealPiece', 'AxialPiece', 'DiagonalPiece')
    if not all(hasattr(__main__, class_name) for class_name in lineal_piece_class_names):
        raise NotImplementedError

    lineal_piece_classes = tuple(getattr(__main__, class_name) for class_name in lineal_piece_class_names)
    lineal_pieces = (pawn, bishop, rook, queen, king)

    if not any(hasattr(element, 'get_lineal_moveset') for element in lineal_piece_classes):
        raise NotImplementedError

    try:
        await _test_4_2_1(pawn, knight, bishop, rook, queen, king)
        await _test_4_2_2(pawn, knight, bishop, rook, queen, king)
        await _test_4_2_3(pawn, knight, bishop, rook, queen, king)
        await _test_5_1_1(pawn, knight, bishop, rook, queen, king, board, random_boards)
    except (AssertionError, NotImplementedError):
        raise ReferenceError

    for piece_class in lineal_piece_classes:
        assert inspect.isfunction(piece_class.get_lineal_moveset)

    for piece in lineal_pieces:
        assert inspect.ismethod(piece.get_lineal_moveset)

    for object_ in (*lineal_piece_classes, *lineal_pieces):
        parameters = inspect.signature(object_.get_lineal_moveset).parameters
        assert parameters['directions'].default == ()
        assert parameters['limit'].default is None
        assert parameters['can_capture'].default is True

    possible_directions = list(set(itertools.product((-1, 0, 1), repeat=2)) - {(0, 0)})
    for _ in range(random_boards):
        await asyncio.sleep(0)
        board_list = utils.create_random_board_list()
        new_board = type(board)(utils.board_to_fen(board_list))

        for n_directions in range(1, len(possible_directions)):
            directions = possible_directions[:n_directions]

            for limit in (None, *range(len(board_list) + 1)):
                for can_capture in (False, True):
                    for row in board_list:
                        for piece in row:
                            if not piece or isinstance(piece, type(knight)):
                                continue

                            # noinspection PyTypeChecker
                            assert (
                                piece.get_lineal_moveset(new_board, directions, limit, can_capture)
                                ==
                                _get_lineal_moveset(piece, board_list, directions, limit, can_capture)
                            )


async def _test_4_8(
    pawn: __main__.Pawn,
    knight: __main__.Knight,
    bishop: __main__.Bishop,
    rook: __main__.Rook,
    queen: __main__.Queen,
    king: __main__.King,
    board: __main__.Board,
    random_boards: int
) -> None:
    pieces = (pawn, knight, bishop, rook, queen, king)

    if not any(hasattr(piece, 'get_moveset') for piece in pieces):
        raise NotImplementedError

    try:
        await _test_4_2_1(pawn, knight, bishop, rook, queen, king)
        await _test_5_1_1(pawn, knight, bishop, rook, queen, king, board, random_boards)
    except (AssertionError, NotImplementedError):
        raise ReferenceError

    assert all(inspect.ismethod(piece.get_moveset) for piece in pieces)

    for _ in range(random_boards):
        await asyncio.sleep(0)
        board_list = utils.create_random_board_list()
        fen_board = utils.board_to_fen(board_list)
        new_board = type(board)(fen_board)
        chess_board = chess.Board(fen_board)

        for i, row in enumerate(board_list):
            for j, piece in enumerate(row):
                if not piece:
                    continue

                # noinspection PyProtectedMember
                assert (
                    set(piece.get_moveset(new_board))
                    ==
                    _get_moveset_at(chess_board, piece._color, i, j)
                )


async def _test_4_9(
    pawn: __main__.Pawn,
    knight: __main__.Knight,
    bishop: __main__.Bishop,
    rook: __main__.Rook,
    queen: __main__.Queen,
    king: __main__.King,
    board: __main__.Board,
    random_boards: int
) -> None:
    pieces = (pawn, knight, bishop, rook, queen, king)

    if not any(hasattr(piece, 'is_attacking_to') for piece in pieces):
        raise NotImplementedError

    try:
        await _test_4_2_1(pawn, knight, bishop, rook, queen, king)
        await _test_5_1_1(pawn, knight, bishop, rook, queen, king, board, random_boards)
    except (AssertionError, NotImplementedError):
        raise ReferenceError

    assert all(inspect.ismethod(piece.is_attacking_to) for piece in pieces)

    for _ in range(random_boards):
        await asyncio.sleep(0)
        board_list = utils.create_random_board_list()
        fen_board = utils.board_to_fen(board_list)
        new_board = type(board)(fen_board)
        chess_board = chess.Board(fen_board)

        for i, row in enumerate(board_list):
            for j, attacker in enumerate(row):
                attacked_squares = chess_board.attacks(utils.position_to_chess_square(i, j))
                attacked_positions = (
                    utils.chess_square_to_position(attacked_square) for attacked_square in attacked_squares
                )
                for attacked_i, attacked_j in attacked_positions:
                    # noinspection PyProtectedMember
                    if (
                        (attacked := board_list[attacked_i][attacked_j])
                        and
                        attacked._color is not attacker._color
                    ):
                        assert attacker.is_attacking_to(new_board, attacked)


async def _test_4_10(
    pawn: __main__.Pawn,
    knight: __main__.Knight,
    bishop: __main__.Bishop,
    rook: __main__.Rook,
    queen: __main__.Queen,
    king: __main__.King,
    board: __main__.Board,
    random_boards: int
) -> None:
    pieces = (pawn, knight, bishop, rook, queen, king)

    if not any(hasattr(piece, 'move') for piece in pieces):
        raise NotImplementedError

    try:
        await _test_2_1()
        await _test_2_3()
        # noinspection DuplicatedCode
        await _test_3_1()
        await _test_4_2_1(pawn, knight, bishop, rook, queen, king)
        await _test_4_2_2(pawn, knight, bishop, rook, queen, king)
        await _test_4_2_3(pawn, knight, bishop, rook, queen, king)
        await _test_4_2_4(pawn, knight, bishop, rook, queen, king)
        await _test_5_1_1(pawn, knight, bishop, rook, queen, king, board, random_boards)
        await _test_5_4(pawn, knight, bishop, rook, queen, king, board, random_boards)
    except (AssertionError, NotImplementedError):
        raise ReferenceError

    assert all(inspect.ismethod(piece.move) for piece in pieces)

    new_board = type(board)('1p6/Pr1b4/8/1P5k/3p3K/8/p1N1p3/3R2Q1 w HAha - 0 1')

    new_board_copy = copy.deepcopy(new_board)
    try:
        new_board_copy[6][0].move(new_board_copy, -4, -5)
    except __main__.OutOfBoundsError as e:
        assert str(e) == 'position must be within board bounds'
    else:
        raise AssertionError

    new_board_copy = copy.deepcopy(new_board)
    try:
        new_board_copy[1][3].move(new_board_copy, 10, 10)
    except __main__.OutOfBoundsError as e:
        assert str(e) == 'position must be within board bounds'
    else:
        raise AssertionError

    new_board_copy = copy.deepcopy(new_board)
    try:
        new_board_copy[3][1].move(new_board, 3, 1)
    except  __main__.SamePositionError as e:
        assert str(e) == 'the piece is already at the target position'
    else:
        raise AssertionError

    for old_row, old_column, new_row, new_column in (
        (1, 0, 0, 0), (1, 0, 0, 1),
        (6, 4, 7, 4), (6, 4, 7, 3)
    ):
        new_board_copy = copy.deepcopy(new_board)
        piece = new_board_copy[old_row][old_column]
        piece.move(new_board_copy, new_row, new_column)
        assert not new_board_copy[old_row][old_column]
        new_queen = new_board_copy[new_row][new_column]
        assert new_queen.row == new_row and new_queen.column == new_column

    for old_row, old_column, new_row, new_column in (
        (3, 1, 2, 1), (4, 3, 5, 3),
        (1, 1, 2, 1), (1, 1, 3, 1),
        (6, 2, 4, 1), (6, 2, 4, 3),
        (1, 3, 2, 2), (1, 3, 3, 1),
        (7, 6, 6, 7), (7, 6, 4, 3)
    ):
        new_board_copy = copy.deepcopy(new_board)
        piece = new_board_copy[old_row][old_column]
        piece.move(new_board_copy, new_row, new_column)
        assert not new_board_copy[old_row][old_column]
        assert new_board_copy[new_row][new_column] is piece
        assert piece.row == new_row and piece.column == new_column and piece.has_moved

    for _ in range(random_boards):
        await asyncio.sleep(0)
        board_list = utils.create_random_board_list()
        new_board = type(board)(utils.board_to_fen(board_list))

        piece = None
        while not piece:
            row = random.randint(0, len(board_list) - 1)
            column = random.randint(0, len(board_list) - 1)
            piece = new_board[row][column]

        for _ in range(_RANDOM_MOVES):
            old_row = piece.row
            old_column = piece.column
            half_board_length = len(board_list) // 2
            new_row = random.randint(-half_board_length, len(board_list) - 1 + half_board_length)
            new_column = random.randint(-half_board_length, len(board_list) - 1 + half_board_length)

            if not _is_in_bounds(board_list, new_row, new_column):
                try:
                    piece.move(new_board, new_row, new_column)
                except __main__.OutOfBoundsError as e:
                    assert str(e) == 'position must be within board bounds'
                    continue
                else:
                    raise AssertionError

            if new_row == old_row and new_column == old_column:
                try:
                    piece.move(new_board, new_row, new_column)
                except __main__.SamePositionError as e:
                    assert str(e) == 'the piece is already at the target position'
                    continue
                else:
                    raise AssertionError

            piece.move(new_board, new_row, new_column)

            assert not new_board[old_row][old_column]

            # noinspection PyProtectedMember
            if (
                isinstance(piece, __main__.Pawn)
                and
                (
                    piece._color is __main__.Color.WHITE and piece.row == 0
                    or
                    piece._color is __main__.Color.BLACK and piece.row == len(board_list) - 1
                )
            ):
                new_queen = new_board[new_row][new_column]
                assert new_queen.row == new_row and new_queen.column == new_column
            else:
                assert new_board[new_row][new_column] is piece
                # noinspection PyUnresolvedReferences
                assert piece.row == new_row and piece.column == new_column and piece.has_moved


async def _test_4_11(
    pawn: __main__.Pawn,
    knight: __main__.Knight,
    bishop: __main__.Bishop,
    rook: __main__.Rook,
    queen: __main__.Queen,
    king: __main__.King
) -> None:
    pieces = (pawn, knight, bishop, rook, queen, king)

    if not any(hasattr(piece, 'svg') and piece.svg for piece in pieces):
        raise NotImplementedError

    try:
        await _test_3_1()
        await _test_4_2_1(pawn, knight, bishop, rook, queen, king)
    except (AssertionError, NotImplementedError):
        raise ReferenceError

    svgs = (
        (
            'https://upload.wikimedia.org/wikipedia/commons/4/45/Chess_plt45.svg',
            'https://upload.wikimedia.org/wikipedia/commons/c/c7/Chess_pdt45.svg'
        ),
        (
            'https://upload.wikimedia.org/wikipedia/commons/7/70/Chess_nlt45.svg',
            'https://upload.wikimedia.org/wikipedia/commons/e/ef/Chess_ndt45.svg'
        ),
        (
            'https://upload.wikimedia.org/wikipedia/commons/b/b1/Chess_blt45.svg',
            'https://upload.wikimedia.org/wikipedia/commons/9/98/Chess_bdt45.svg'
        ),
        (
            'https://upload.wikimedia.org/wikipedia/commons/7/72/Chess_rlt45.svg',
            'https://upload.wikimedia.org/wikipedia/commons/f/ff/Chess_rdt45.svg'
        ),
        (
            'https://upload.wikimedia.org/wikipedia/commons/1/15/Chess_qlt45.svg',
            'https://upload.wikimedia.org/wikipedia/commons/4/47/Chess_qdt45.svg'
        ),
        (
            'https://upload.wikimedia.org/wikipedia/commons/4/42/Chess_klt45.svg',
            'https://upload.wikimedia.org/wikipedia/commons/f/f0/Chess_kdt45.svg'
        )
    )
    for piece, (white_svg, black_svg) in zip(pieces, svgs):
        property_ = getattr(type(piece), 'svg', None)
        assert isinstance(property_, property) and property_.fget and not property_.fset and not property_.fdel
        piece._color = __main__.Color.WHITE
        assert piece.svg == white_svg
        piece._color = __main__.Color.BLACK
        assert piece.svg == black_svg


async def _test_4_12_1(
    pawn: __main__.Pawn,
    knight: __main__.Knight,
    bishop: __main__.Bishop,
    rook: __main__.Rook,
    queen: __main__.Queen,
    king: __main__.King,
    board: __main__.Board,
    random_boards: int
) -> None:
    if not hasattr(king, 'iter_checkers'):
        raise NotImplementedError

    try:
        await _test_3_1()
        await _test_5_1_1(pawn, knight, bishop, rook, queen, king, board, random_boards)
    except (AssertionError, NotImplementedError):
        raise ReferenceError

    assert inspect.ismethod(king.iter_checkers)

    for _ in range(random_boards):
        await asyncio.sleep(0)
        board_list = utils.create_random_board_list()
        fen_board = utils.board_to_fen(board_list)
        new_board = type(board)(fen_board)
        chess_board = chess.Board(fen_board)

        for color in __main__.Color:
            chess_color = utils.color_to_chess_color(color)
            chess_board.turn = chess_color
            row, column = utils.chess_square_to_position(chess_board.king(chess_color))
            king = board_list[row][column]
            checkers_positions = {utils.chess_square_to_position(square) for square in chess_board.checkers()}
            assert _compare_pieces(
                king.iter_checkers(new_board),
                (board_list[row][column] for row, column in checkers_positions)
            )


async def _test_4_12_2(
    pawn: __main__.Pawn,
    knight: __main__.Knight,
    bishop: __main__.Bishop,
    rook: __main__.Rook,
    queen: __main__.Queen,
    king: __main__.King,
    board: __main__.Board,
    random_boards: int
) -> None:
    if not hasattr(king, 'is_in_check'):
        raise NotImplementedError

    try:
        await _test_3_1()
        await _test_5_1_1(pawn, knight, bishop, rook, queen, king, board, random_boards)
    except (AssertionError, NotImplementedError):
        raise ReferenceError

    assert inspect.ismethod(king.is_in_check)

    for _ in range(random_boards):
        await asyncio.sleep(0)
        board_list = utils.create_random_board_list()
        fen_board = utils.board_to_fen(board_list)
        new_board = type(board)(fen_board)
        chess_board = chess.Board(fen_board)

        for color in __main__.Color:
            chess_color = utils.color_to_chess_color(color)
            chess_board.turn = chess_color
            row, column = utils.chess_square_to_position(chess_board.king(chess_color))
            king = board_list[row][column]
            assert king.is_in_check(new_board) == chess_board.is_check()


# noinspection PyProtectedMember
async def _test_4_12_3(
    pawn: __main__.Pawn,
    knight: __main__.Knight,
    bishop: __main__.Bishop,
    rook: __main__.Rook,
    queen: __main__.Queen,
    king: __main__.King,
    board: __main__.Board,
    random_boards: int
) -> None:
    if not hasattr(king, 'iter_safe_moveset'):
        raise NotImplementedError

    try:
        await _test_3_1()
        await _test_4_2_1(pawn, knight, bishop, rook, queen, king)
        await _test_5_1_1(pawn, knight, bishop, rook, queen, king, board, random_boards)
    except (AssertionError, NotImplementedError):
        raise ReferenceError

    assert inspect.ismethod(king.iter_safe_moveset)

    for _ in range(random_boards):
        await asyncio.sleep(0)
        board_list = utils.create_random_board_list()
        fen_board = utils.board_to_fen(board_list)
        new_board = type(board)(fen_board)
        chess_board = chess.Board(fen_board)

        kings = {}
        row, column = utils.chess_square_to_position(chess_board.king(chess.WHITE))
        kings[__main__.Color.WHITE] = board_list[row][column]
        row, column = utils.chess_square_to_position(chess_board.king(chess.BLACK))
        kings[__main__.Color.BLACK] = board_list[row][column]

        for i, row in enumerate(board_list):
            for j, piece in enumerate(row):
                if not piece:
                    continue

                safe_moveset = set()

                chess_board.turn = utils.color_to_chess_color(piece._color)
                for legal_move in chess_board.legal_moves:
                    current_position = utils.chess_square_to_position(legal_move.from_square)
                    new_position = utils.chess_square_to_position(legal_move.to_square)
                    if current_position == (i, j):
                        safe_moveset.add(new_position)

                assert set(kings[piece._color].iter_safe_moveset(new_board, piece)) == safe_moveset


async def _test_4_12_4(
    pawn: __main__.Pawn,
    knight: __main__.Knight,
    bishop: __main__.Bishop,
    rook: __main__.Rook,
    queen: __main__.Queen,
    king: __main__.King,
    board: __main__.Board,
    random_boards: int
) -> None:
    if not hasattr(king, 'is_in_checkmate'):
        raise NotImplementedError

    try:
        await _test_3_1()
        await _test_5_1_1(pawn, knight, bishop, rook, queen, king, board, random_boards)
    except (AssertionError, NotImplementedError):
        raise ReferenceError

    assert inspect.ismethod(king.is_in_checkmate)

    for _ in range(random_boards):
        await asyncio.sleep(0)
        board_list = utils.create_random_board_list()
        fen_board = utils.board_to_fen(board_list)
        new_board = type(board)(fen_board)
        chess_board = chess.Board(fen_board)

        for color in __main__.Color:
            chess_color = utils.color_to_chess_color(color)
            chess_board.turn = chess_color
            row, column = utils.chess_square_to_position(chess_board.king(chess_color))
            king = board_list[row][column]
            assert king.is_in_checkmate(new_board) == chess_board.is_checkmate()


# noinspection PyProtectedMember
async def _test_5_1_1(
    pawn: __main__.Pawn,
    knight: __main__.Knight,
    bishop: __main__.Bishop,
    rook: __main__.Rook,
    queen: __main__.Queen,
    king: __main__.King,
    board: __main__.Board,
    random_boards: int
) -> None:
    if not hasattr(board, '_board'):
        raise NotImplementedError

    try:
        await _test_4_4(pawn, knight, bishop, rook, queen, king)
    except (AssertionError, NotImplementedError):
        raise ReferenceError

    assert isinstance(board._board, list)
    assert inspect.signature(board.__init__).parameters['fen_board'].default is None
    board_vars = {k: v for k, v in vars(board).items() if k != '_board'}
    assert (
        type(board)(**board_vars)._board
        ==
        [[None for _ in range(len(board._board))] for _ in range(len(board._board))]
    )

    for _ in range(random_boards):
        await asyncio.sleep(0)
        board_list = utils.create_random_board_list()
        fen_board = utils.board_to_fen(board_list)
        board_vars['fen_board'] = fen_board
        assert type(board)(**board_vars)._board == board_list
        board_vars['fen_board'] = fen_board + ' w KQkq - 0 1'
        assert type(board)(**board_vars)._board == board_list


async def _test_5_1_2(
    _pawn: __main__.Pawn,
    _knight: __main__.Knight,
    _bishop: __main__.Bishop,
    _rook: __main__.Rook,
    _queen: __main__.Queen,
    _king: __main__.King,
    board: __main__.Board
) -> None:
    if not hasattr(board, 'human_color'):
        raise NotImplementedError

    try:
        await _test_3_1()
    except (AssertionError, NotImplementedError):
        raise ReferenceError

    assert isinstance(board.human_color, __main__.Color)
    assert inspect.signature(board.__init__).parameters['human_color'].default is __main__.Color.WHITE


# noinspection PyProtectedMember
async def _test_5_2(
    pawn: __main__.Pawn,
    knight: __main__.Knight,
    bishop: __main__.Bishop,
    rook: __main__.Rook,
    queen: __main__.Queen,
    king: __main__.King,
    board: __main__.Board,
    random_boards: int
) -> None:
    if not hasattr(board, 'load_fen'):
        raise NotImplementedError

    try:
        await _test_4_4(pawn, knight, bishop, rook, queen, king)
        await _test_5_1_1(pawn, knight, bishop, rook, queen, king, board, random_boards)
    except (AssertionError, NotImplementedError):
        raise ReferenceError

    assert inspect.ismethod(board.load_fen)

    board_copy = copy.copy(board)
    for _ in range(random_boards):
        await asyncio.sleep(0)
        board_list = utils.create_random_board_list()
        fen_board = utils.board_to_fen(board_list)
        board_copy.load_fen(fen_board)
        assert board_copy._board == board_list
        board_copy.load_fen(fen_board + ' w KQkq - 0 1')
        assert board_copy._board == board_list


async def _test_5_3(
    pawn: __main__.Pawn,
    knight: __main__.Knight,
    bishop: __main__.Bishop,
    rook: __main__.Rook,
    queen: __main__.Queen,
    king: __main__.King,
    board: __main__.Board,
    random_boards: int
) -> None:
    if not hasattr(board, 'load_fen'):
        raise NotImplementedError

    try:
        await _test_5_1_1(pawn, knight, bishop, rook, queen, king, board, random_boards)
        await _test_5_2(pawn, knight, bishop, rook, queen, king, board, random_boards)
    except (AssertionError, NotImplementedError):
        raise ReferenceError

    with mock.patch.object(type(board), 'load_fen') as mock_load_fen:
        type(board)()
        type(board)('rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1')
        type(board)()
        type(board)('r1bq2nr/p3p1pp/3b1p2/2BPK1N1/1pQ1k3/8/P2PP1PP/RN3B1R w HAha - 0 1')
        type(board)()
        type(board)('r1bq2nr/p3p1pp/3b1p2/2BPK1N1/1pQ1k3/8/P2PP1PP/RN3B1R')

    assert mock_load_fen.call_count == 3


# noinspection PyProtectedMember
async def _test_5_4(
    pawn: __main__.Pawn,
    knight: __main__.Knight,
    bishop: __main__.Bishop,
    rook: __main__.Rook,
    queen: __main__.Queen,
    king: __main__.King,
    board: __main__.Board,
    random_boards: int
) -> None:
    if not hasattr(board, '__getitem__'):
        raise NotImplementedError

    try:
        await _test_5_1_1(pawn, knight, bishop, rook, queen, king, board, random_boards)
    except (AssertionError, NotImplementedError):
        raise ReferenceError

    for i in range(-len(board._board), len(board._board)):
        assert type(board)()[i] == [None for _ in range(len(board._board))]
        assert board[i] == board._board[i]

    for _ in range(random_boards):
        await asyncio.sleep(0)
        board_list = utils.create_random_board_list()
        new_board = type(board)(utils.board_to_fen(board_list))

        for i in range(-len(board._board), len(board._board)):
            assert new_board[i] == board_list[i]


# noinspection PyProtectedMember,PyUnresolvedReferences
async def _test_5_5(
    pawn: __main__.Pawn,
    knight: __main__.Knight,
    bishop: __main__.Bishop,
    rook: __main__.Rook,
    queen: __main__.Queen,
    king: __main__.King,
    board: __main__.Board,
    random_boards: int
) -> None:
    if not isinstance(board, Iterable):
        raise NotImplementedError

    try:
        await _test_5_1_1(pawn, knight, bishop, rook, queen, king, board, random_boards)
    except (AssertionError, NotImplementedError):
        raise ReferenceError

    assert isinstance(iter(board), Iterator)
    assert list(type(board)()) == [[None for _ in range(len(board._board))] for _ in range(len(board._board))]
    assert list(board) == board._board

    for _ in range(random_boards):
        await asyncio.sleep(0)
        board_list = utils.create_random_board_list()
        # noinspection PyArgumentList
        new_board = type(board)(utils.board_to_fen(board_list))
        assert tuple(new_board) == tuple(board_list)
        assert list(new_board) == list(board_list)
        del board_list[0]
        assert tuple(new_board) != tuple(board_list)
        assert list(new_board) != list(board_list)


async def _test_5_6(
    pawn: __main__.Pawn,
    knight: __main__.Knight,
    bishop: __main__.Bishop,
    rook: __main__.Rook,
    queen: __main__.Queen,
    king: __main__.King,
    board: __main__.Board,
    random_boards: int
) -> None:
    if not hasattr(board, '__len__'):
        raise NotImplementedError

    try:
        await _test_5_1_1(pawn, knight, bishop, rook, queen, king, board, random_boards)
    except (AssertionError, NotImplementedError):
        raise ReferenceError

    for _ in range(random_boards):
        await asyncio.sleep(0)
        board_list = utils.create_random_board_list()
        new_board = type(board)(utils.board_to_fen(board_list))
        assert len(new_board) == len(board_list)


async def _test_5_7(
    pawn: __main__.Pawn,
    knight: __main__.Knight,
    bishop: __main__.Bishop,
    rook: __main__.Rook,
    queen: __main__.Queen,
    king: __main__.King,
    board: __main__.Board,
    random_boards: int
) -> None:
    if str(board) == object.__repr__(board):
        raise NotImplementedError

    try:
        await _test_4_5(pawn, knight, bishop, rook, queen, king)
        await _test_5_1_1(pawn, knight, bishop, rook, queen, king, board, random_boards)
    except (AssertionError, NotImplementedError):
        raise ReferenceError

    for _ in range(random_boards):
        await asyncio.sleep(0)
        board_list = utils.create_random_board_list()
        new_board = type(board)(utils.board_to_fen(board_list))
        assert str(new_board) == _get_board_str(board_list)


async def _test_5_8(
    pawn: __main__.Pawn,
    knight: __main__.Knight,
    bishop: __main__.Bishop,
    rook: __main__.Rook,
    queen: __main__.Queen,
    king: __main__.King,
    board: __main__.Board,
    random_boards: int
) -> None:
    if not hasattr(board, 'iter_pieces'):
        raise NotImplementedError

    try:
        await _test_3_1()
        await _test_4_2_1(pawn, knight, bishop, rook, queen, king)
        await _test_5_1_1(pawn, knight, bishop, rook, queen, king, board, random_boards)
    except (AssertionError, NotImplementedError):
        raise ReferenceError

    assert inspect.ismethod(board.iter_pieces)
    parameters = inspect.signature(board.iter_pieces).parameters
    assert parameters['color'].default is None
    assert parameters['piece_class'].default is __main__.Piece

    for _ in range(random_boards):
        await asyncio.sleep(0)
        board_list = utils.create_random_board_list()
        new_board = type(board)(utils.board_to_fen(board_list))

        for color in __main__.Color:
            assert _compare_pieces(new_board.iter_pieces(color), _iter_pieces(board_list, color))

            for piece_class in (type(piece) for piece in (pawn, knight, bishop, rook, queen, king, board)):
                assert _compare_pieces(
                    new_board.iter_pieces(color, piece_class),
                    _iter_pieces(board_list, color, piece_class)
                )


async def _test_5_9(
    pawn: __main__.Pawn,
    knight: __main__.Knight,
    bishop: __main__.Bishop,
    rook: __main__.Rook,
    queen: __main__.Queen,
    king: __main__.King,
    board: __main__.Board,
    random_boards: int
) -> None:
    if not hasattr(board, 'get_king'):
        raise NotImplementedError

    try:
        await _test_3_1()
        await _test_4_2_1(pawn, knight, bishop, rook, queen, king)
        await _test_5_1_1(pawn, knight, bishop, rook, queen, king, board, random_boards)
    except (AssertionError, NotImplementedError):
        raise ReferenceError

    assert inspect.ismethod(board.get_king)

    for _ in range(random_boards):
        await asyncio.sleep(0)
        board_list = utils.create_random_board_list()
        new_board = type(board)(utils.board_to_fen(board_list))

        for color in __main__.Color:
            assert new_board.get_king(color) == next(_iter_pieces(board_list, color, type(king)))


async def _test_5_10(
    pawn: __main__.Pawn,
    knight: __main__.Knight,
    bishop: __main__.Bishop,
    rook: __main__.Rook,
    queen: __main__.Queen,
    king: __main__.King,
    board: __main__.Board,
    random_boards: int
) -> None:
    if not hasattr(board, 'get_moveset_at'):
        raise NotImplementedError

    try:
        await _test_2_1()
        await _test_2_2()
        await _test_4_2_1(pawn, knight, bishop, rook, queen, king)
        await _test_5_1_1(pawn, knight, bishop, rook, queen, king, board, random_boards)
    except (AssertionError, NotImplementedError):
        raise ReferenceError

    assert inspect.ismethod(board.get_moveset_at)

    for _ in range(random_boards):
        await asyncio.sleep(0)
        board_list = utils.create_random_board_list()
        fen_board = utils.board_to_fen(board_list)
        new_board = type(board)(fen_board)
        chess_board = chess.Board(fen_board)

        for i in range(-2, len(board_list) + 2):
            for j in range(-2, len(board_list) + 2):
                if not _is_in_bounds(board_list, i, j):
                    try:
                        new_board.get_moveset_at(i, j)
                    except __main__.OutOfBoundsError as e:
                        assert str(e) == 'position must be within board bounds'
                        continue
                    else:
                        raise AssertionError

                if piece := board_list[i][j]:
                    # noinspection PyProtectedMember
                    assert set(new_board.get_moveset_at(i, j)) == _get_moveset_at(chess_board, piece._color, i, j)
                else:
                    try:
                        new_board.get_moveset_at(i, j)
                    except __main__.NoPieceError as e:
                        assert str(e) == f'there is no piece at position ({i}, {j})'
                    else:
                        raise AssertionError


async def _test_5_11(
    pawn: __main__.Pawn,
    knight: __main__.Knight,
    bishop: __main__.Bishop,
    rook: __main__.Rook,
    queen: __main__.Queen,
    king: __main__.King,
    board: __main__.Board,
    random_boards: int
) -> None:
    if not hasattr(board, 'get_score'):
        raise NotImplementedError

    try:
        await _test_3_1()
        await _test_4_2_1(pawn, knight, bishop, rook, queen, king)
        await _test_5_1_1(pawn, knight, bishop, rook, queen, king, board, random_boards)
    except (AssertionError, NotImplementedError):
        raise ReferenceError

    assert inspect.ismethod(board.get_score)

    for _ in range(random_boards):
        await asyncio.sleep(0)
        board_list = utils.create_random_board_list()
        new_board = type(board)(utils.board_to_fen(board_list))

        for color in __main__.Color:
            total = 0
            for row in board_list:
                for piece in row:
                    # noinspection PyProtectedMember
                    if piece and piece._color is color:
                        total += getattr(piece, 'value', 0)

            assert new_board.get_score(color) == total


async def _test_5_12(
    pawn: __main__.Pawn,
    knight: __main__.Knight,
    bishop: __main__.Bishop,
    rook: __main__.Rook,
    queen: __main__.Queen,
    king: __main__.King,
    board: __main__.Board,
    random_boards: int
) -> None:
    if not hasattr(board, 'is_check'):
        raise NotImplementedError

    try:
        await _test_3_1()
        await _test_5_1_1(pawn, knight, bishop, rook, queen, king, board, random_boards)
    except (AssertionError, NotImplementedError):
        raise ReferenceError

    assert inspect.ismethod(board.is_check)

    for _ in range(random_boards):
        await asyncio.sleep(0)
        board_list = utils.create_random_board_list()
        fen_board = utils.board_to_fen(board_list)
        new_board = type(board)(fen_board)
        chess_board = chess.Board(fen_board)

        for color in __main__.Color:
            chess_board.turn = utils.color_to_chess_color(color)
            assert new_board.is_check(color) == chess_board.is_check()


async def _test_5_13(
    pawn: __main__.Pawn,
    knight: __main__.Knight,
    bishop: __main__.Bishop,
    rook: __main__.Rook,
    queen: __main__.Queen,
    king: __main__.King,
    board: __main__.Board,
    random_boards: int
) -> None:
    if not hasattr(board, 'is_checkmate'):
        raise NotImplementedError

    try:
        await _test_3_1()
        await _test_5_1_1(pawn, knight, bishop, rook, queen, king, board, random_boards)
    except (AssertionError, NotImplementedError):
        raise ReferenceError

    assert inspect.ismethod(board.is_check)

    for _ in range(random_boards):
        await asyncio.sleep(0)
        board_list = utils.create_random_board_list()
        fen_board = utils.board_to_fen(board_list)
        new_board = type(board)(fen_board)
        chess_board = chess.Board(fen_board)

        for color in __main__.Color:
            chess_board.turn = utils.color_to_chess_color(color)
            assert new_board.is_checkmate(color) == chess_board.is_checkmate()


async def _test_5_14(
    pawn: __main__.Pawn,
    knight: __main__.Knight,
    bishop: __main__.Bishop,
    rook: __main__.Rook,
    queen: __main__.Queen,
    king: __main__.King,
    board: __main__.Board,
    random_boards: int
) -> None:
    if not hasattr(board, 'is_in_bounds'):
        raise NotImplementedError

    try:
        await _test_5_1_1(pawn, knight, bishop, rook, queen, king, board, random_boards)
    except (AssertionError, NotImplementedError):
        raise ReferenceError

    assert inspect.ismethod(board.is_in_bounds)

    for _ in range(random_boards):
        await asyncio.sleep(0)
        board_list = utils.create_random_board_list()
        new_board = type(board)(utils.board_to_fen(board_list))

        for i in range(-2, len(board_list) + 2):
            for j in range(-2, len(board_list) + 2):
                assert new_board.is_in_bounds(i, j) == _is_in_bounds(board_list, i, j)


async def _test_6(
    pawn: __main__.Pawn,
    knight: __main__.Knight,
    bishop: __main__.Bishop,
    rook: __main__.Rook,
    queen: __main__.Queen,
    king: __main__.King,
    board: __main__.Board
) -> None:
    class_names = (
        'OutOfBoundsError',
        'NoPieceError',
        'SamePositionError',
        'Color',
        'Piece',
        'LinealPiece',
        'AxialPiece',
        'DiagonalPiece'
    )
    lineal_pieces = (pawn, bishop, rook, queen, king)
    if (
        not all(hasattr(__main__, class_name) for class_name in class_names)
        or
        not any(
            hasattr(element, 'get_lineal_moveset') for element in (
                __main__.LinealPiece,
                __main__.AxialPiece,
                __main__.DiagonalPiece,
                *lineal_pieces
            )
        )
        or
        not inspect.ismethod(board.__init__)
        or
        not hasattr(board, 'iter_pieces')
    ):
        raise NotImplementedError

    default_args = defaultdict(int)

    classes = tuple(getattr(__main__, class_name) for class_name in class_names)
    for class_ in (*classes, *(type(object_) for object_ in (pawn, knight, bishop, rook, queen, king, board))):
        for member in vars(class_).values():
            if not inspect.isfunction(member) or isinstance(member, property) and not (member := member.fget):
                continue

            for k, v in inspect.signature(member).parameters.items():
                if v.default is not v.empty:
                    default_args[k] += 1

    assert len(default_args) == 7
    assert default_args.get('directions') == 3
    assert default_args.get('limit') == 3
    assert default_args.get('can_capture') == 3
    assert default_args.get('fen_board') == 1
    assert default_args.get('human_color') == 1
    assert default_args.get('color') == 1
    assert default_args.get('piece_class') == 1


async def _test_7(
    pawn: __main__.Pawn,
    knight: __main__.Knight,
    bishop: __main__.Bishop,
    rook: __main__.Rook,
    queen: __main__.Queen,
    king: __main__.King,
    board: __main__.Board
) -> None:
    if (
        not all(
            hasattr(__main__, class_name) for class_name in (
                'OutOfBoundsError',
                'NoPieceError',
                'SamePositionError',
                'Color',
                'Piece',
                'LinealPiece',
                'AxialPiece',
                'DiagonalPiece'
            )
        )
        or
        not any(hasattr(piece, '_color') for piece in (pawn, knight, bishop, rook, queen, king))
        or
        not hasattr(board, '_board')
    ):
        raise NotImplementedError

    classes_internal_uses = {
        __main__.OutOfBoundsError: {'__init__'},
        __main__.NoPieceError: {'__init__'},
        __main__.SamePositionError: {'__init__'},
        __main__.Color: {
            '__context__',
            '__name__',
            '__qualname__',
            '_boundary_',
            '_member_map_',
            '_missing_',
            '_value2member_map_',
            '_value_'
        },
        __main__.Piece: {'_color'},
        __main__.LinealPiece: set(),
        __main__.AxialPiece: set(),
        __main__.DiagonalPiece: set(),
        __main__.Pawn: {'__init__'},
        __main__.Knight: set(),
        __main__.Bishop: set(),
        __main__.Rook: set(),
        __main__.Queen: set(),
        __main__.King: set(),
        __main__.Board: {'_board'}
    }
    for class_, class_internal_uses in classes_internal_uses.items():
        assert _re_find_internal_uses(class_) == class_internal_uses


async def _test_8(
    pawn: __main__.Pawn,
    knight: __main__.Knight,
    bishop: __main__.Bishop,
    rook: __main__.Rook,
    queen: __main__.Queen,
    king: __main__.King,
    board: __main__.Board
) -> None:
    pieces = (pawn, knight, bishop, rook, queen, king)
    lineal_pieces = (pawn, bishop, rook, queen, king)

    if (
        not all(hasattr(board, attribute_name) for attribute_name in ('_board', 'is_in_bounds'))
        or
        not any(hasattr(piece, 'move') for piece in pieces)
        or
        not all(hasattr(__main__, class_name) for class_name in ('LinealPiece', 'AxialPiece', 'DiagonalPiece'))
        or
        not any(
            hasattr(element, 'get_lineal_moveset') for element in (
                __main__.LinealPiece,
                __main__.AxialPiece,
                __main__.DiagonalPiece,
                *lineal_pieces
            )
        )
        or
        not any(hasattr(piece, 'get_moveset') for piece in pieces)
    ):
        raise NotImplementedError

    try:
        await _test_2_3()
    except (AssertionError, NotImplementedError):
        raise ReferenceError

    board_copy = copy.deepcopy(board)
    with mock.patch.object(board_copy, 'is_in_bounds') as mock_is_in_bounds:
        for piece in pieces:
            try:
                piece.move(board_copy, 0, 0)
            except __main__.SamePositionError:
                pass

            mock_is_in_bounds.assert_called()
            mock_is_in_bounds.reset_mock()

        for piece in lineal_pieces:
            piece.get_lineal_moveset(board_copy)
            mock_is_in_bounds.assert_called()
            mock_is_in_bounds.reset_mock()

        pawn.get_moveset(board_copy)
        mock_is_in_bounds.assert_called()
        mock_is_in_bounds.reset_mock()

        knight.get_moveset(board_copy)
        mock_is_in_bounds.assert_called()
        mock_is_in_bounds.reset_mock()


def test(
    pawn: __main__.Pawn | None = None,
    knight: __main__.Knight | None = None,
    bishop: __main__.Bishop | None = None,
    rook: __main__.Rook | None = None,
    queen: __main__.Queen | None = None,
    king: __main__.King | None = None,
    board: __main__.Board | None = None,
    numbers=False,
    random_boards=10,
    play_game=True
) -> None:
    asyncio.run(_main(pawn, knight, bishop, rook, queen, king, board, numbers, random_boards, play_game))


def test_type_hints() -> None:
    ratio, failed_methods = asyncio.run(_test_1())
    print()
    print(f"Type hints: {'✅ ' if ratio == 1 else ''}{ratio:.0%}")

    if failed_methods:
        print()
        print('Failed:')
        print('-------')
        for failed_method in failed_methods:
            print(failed_method)

    print()
