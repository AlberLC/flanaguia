from enum import Enum, auto


class Gender(Enum):
    MALE = auto()
    FEMALE = auto()


students = [
    {'id': 7, 'name': '小明', 'last_name': '王', 'age': 16, 'gender': Gender.MALE, 'country_id': 3},
    {'id': 18, 'name': 'John', 'last_name': 'Smith', 'age': 22, 'gender': Gender.MALE, 'country_id': 2},
    {'id': 21, 'name': 'Elena', 'last_name': 'Ruiz', 'age': 37, 'gender': Gender.FEMALE, 'country_id': 4},
    {'id': 25, 'name': '太郎', 'last_name': '佐藤', 'age': 25, 'gender': Gender.MALE, 'country_id': 1},
    {'id': 29, 'name': 'Lìlì', 'last_name': 'Lǐ', 'age': 18, 'gender': Gender.FEMALE, 'country_id': 3},
    {'id': 30, 'name': 'Luis', 'last_name': 'López', 'age': 54, 'gender': Gender.MALE, 'country_id': 4},
    {'id': 37, 'name': 'Yumiko', 'last_name': 'Suzuki', 'age': 18, 'gender': Gender.FEMALE, 'country_id': 1},
    {'id': 52, 'name': 'Thomas', 'last_name': 'Mülle', 'age': 67, 'gender': Gender.MALE, 'country_id': 5},
    {'id': 61, 'name': 'Emily', 'last_name': 'Johnson', 'age': 55, 'gender': Gender.FEMALE, 'country_id': 2},
    {'id': 66, 'name': 'Sarah', 'last_name': 'Taylor', 'age': 32, 'gender': Gender.FEMALE, 'country_id': 6},
    {'id': 79, 'name': 'Rahul', 'last_name': 'Sharma', 'age': 17, 'gender': Gender.MALE, 'country_id': 7},
    {'id': 85, 'name': 'Lisa', 'last_name': 'Schmidt', 'age': 29, 'gender': Gender.FEMALE, 'country_id': 5},
    {'id': 103, 'name': 'Priya', 'last_name': 'Patel', 'age': 22, 'gender': Gender.FEMALE, 'country_id': 7},
]

countries = [
    {'id': 1, 'name': 'Japan'},
    {'id': 2, 'name': 'United States'},
    {'id': 3, 'name': 'China'},
    {'id': 4, 'name': 'Spain'},
    {'id': 5, 'name': 'Germany'},
    {'id': 6, 'name': 'United Kingdom'},
    {'id': 7, 'name': 'India'}
]

subjects = [
    {'id': 1, 'name': 'Mathematics'},
    {'id': 2, 'name': 'Literature'},
    {'id': 3, 'name': 'History'},
    {'id': 4, 'name': 'Biology'},
    {'id': 5, 'name': 'Chemistry'},
    {'id': 6, 'name': 'Computer Science'},
]

student_subject_relations = [
    {'student_id': 7, 'subject_id': 1},
    {'student_id': 7, 'subject_id': 2},
    {'student_id': 7, 'subject_id': 5},
    {'student_id': 18, 'subject_id': 2},
    {'student_id': 21, 'subject_id': 2},
    {'student_id': 21, 'subject_id': 4},
    {'student_id': 25, 'subject_id': 6},
    {'student_id': 29, 'subject_id': 1},
    {'student_id': 29, 'subject_id': 6},
    {'student_id': 30, 'subject_id': 1},
    {'student_id': 37, 'subject_id': 2},
    {'student_id': 37, 'subject_id': 3},
    {'student_id': 52, 'subject_id': 4},
    {'student_id': 52, 'subject_id': 5},
    {'student_id': 52, 'subject_id': 6},
    {'student_id': 61, 'subject_id': 2},
    {'student_id': 61, 'subject_id': 4},
    {'student_id': 61, 'subject_id': 5},
    {'student_id': 66, 'subject_id': 1},
    {'student_id': 66, 'subject_id': 2},
    {'student_id': 66, 'subject_id': 3},
    {'student_id': 79, 'subject_id': 1},
    {'student_id': 79, 'subject_id': 2},
    {'student_id': 79, 'subject_id': 3},
    {'student_id': 79, 'subject_id': 4},
    {'student_id': 79, 'subject_id': 5},
    {'student_id': 79, 'subject_id': 6},
    {'student_id': 85, 'subject_id': 3},
    {'student_id': 85, 'subject_id': 5},
    {'student_id': 103, 'subject_id': 4},
    {'student_id': 103, 'subject_id': 5},
    {'student_id': 103, 'subject_id': 6}
]
