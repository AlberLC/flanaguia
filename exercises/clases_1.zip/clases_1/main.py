import random
from abc import ABC, abstractmethod
from collections.abc import Callable, Iterator
from enum import Enum, auto
from typing import Any, Self

from tests import test


class WheelDrive(Enum):
    FRONT = auto()
    REAR = auto()


class Person:
    def __init__(self, name: str, age: int) -> None:
        if age <= 0:
            raise ValueError

        self.name = name.strip().capitalize()
        self.age = age

    def __le__(self, other: Any) -> bool:
        if not isinstance(other, Person):
            return super().__le__(other)

        return self.age <= other.age

    def __lt__(self, other: Any) -> bool:
        if not isinstance(other, Person):
            return super().__lt__(other)

        return self.age < other.age

    def __repr__(self) -> str:
        return f'{self.name} ({self.age})'


class Vehicle(ABC):
    @abstractmethod
    def __init__(self, max_passengers: int, plate: str = None) -> None:
        self.max_passengers = max_passengers
        self.plate = plate if plate else f'{random.randint(0, 9999):0>4}'
        self._passengers = set()

    def __add__(self, other: Any) -> Self:
        new_vehicle = type(self)(**{k: v for k, v in vars(self).items() if k not in ('plate', '_passengers')})
        for passenger in self.empty() | other.empty():
            new_vehicle.add_passenger(passenger)

        return new_vehicle

    def __eq__(self, other: Any) -> bool:
        return isinstance(other, Vehicle) and self.plate == other.plate

    def __iter__(self) -> Iterator[Person]:
        yield from self.passengers

    def __len__(self) -> int:
        return len(self.passengers)

    def __str__(self) -> str:
        return f'{type(self).__name__}_{self.plate}. Passengers: {self.passengers}'

    def add_passenger(self, passenger: Person) -> None:
        if len(self.passengers) >= self.max_passengers:
            raise ValueError('Full vehicle')

        self.passengers.add(passenger)

    def first_passenger(self, condition: Callable[[Person], bool]) -> Person | None:
        return next((passenger for passenger in self if condition(passenger)), None)

    def empty(self) -> set[Person]:
        passengers = self.passengers.copy()
        self.passengers.clear()
        return passengers

    @property
    def passengers(self) -> set[Person]:
        return self._passengers

    def remove_passenger(self, passenger: Person) -> None:
        self.passengers.discard(passenger)

    def remove_passenger_by_name(self, name: str) -> None:
        if passenger := self.first_passenger(lambda passenger_: passenger_.name.lower() == name.lower()):
            self.remove_passenger(passenger)


class Car(Vehicle):
    def __init__(
        self,
        doors: int,
        airbags: int,
        wheel_drive: WheelDrive,
        max_passengers: int,
        plate: str = None
    ) -> None:
        super().__init__(max_passengers, plate)
        self.doors = doors
        self.airbags = airbags
        self.wheel_drive = wheel_drive


class Train(Vehicle):
    def __init__(self, wagons: int, max_passengers: int, plate: str = None) -> None:
        super().__init__(max_passengers, plate)
        self.wagons = wagons


test(Person('_', 1), Car(1, 1, WheelDrive.FRONT, 1), Train(1, 1))
