from __future__ import annotations

import __main__
import copy
import inspect
import itertools
import re
import types
import typing
import unittest.mock
from abc import ABCMeta
from collections import defaultdict
from collections.abc import Callable, Generator, Iterable, Iterator
from typing import Any, Self, TypeVar

_LETTERS_FORMAT_LEFT_MARGIN = 3
_LETTERS_FORMAT_WIDTH = 8
_MAX_TYPE_HINTS_SCORE = 40
_NUMERIC_FORMAT_WIDTH = 6


class _Mock:
    def __init__(self, **kwargs) -> None:
        for k, v in kwargs.items():
            setattr(self, k, v)


class _UniqueList(list):
    def __iadd__(self, other: Iterable) -> Self:
        for element in other:
            if element not in self:
                self.append(element)

        return self


def _assert_methods_type_hints(
    class_: type,
    type_hint_checks: tuple[tuple[tuple[str, dict[str, Any], Any], ...], ...]
) -> tuple[int, list[str]]:
    score = 0
    failed_methods = _UniqueList()
    if not type_hint_checks:
        return score, failed_methods

    for method_alternative_checks in type_hint_checks:
        is_implemented = False
        failed_method_alternatives = []
        for method_name, expected_parameter_types, return_type in method_alternative_checks:
            method = getattr(class_, method_name, None)
            try:
                if isinstance(method, property):
                    assert method.fget
                    method = method.fget
                elif not inspect.isfunction(method):
                    continue

                is_implemented = True
                actual_parameter_types = typing.get_type_hints(method)
                assert 'return' in actual_parameter_types
                assert _compare_types(return_type, actual_parameter_types.pop('return'))
                _assert_parameter_types(expected_parameter_types, actual_parameter_types)
            except AssertionError:
                failed_method_alternatives.append(str(method.__qualname__))
            else:
                break

        if not is_implemented or len(failed_method_alternatives) != len(method_alternative_checks):
            score += 1
        else:
            failed_methods.append(failed_method_alternatives[0])

    return score, failed_methods


def _assert_parameter_types(expected_parameter_types: dict[str, type], actual_parameter_types: dict[str, type]) -> None:
    if any(k.startswith('_') for k in expected_parameter_types):
        expected_types = list(expected_parameter_types.values())
        for actual_type in actual_parameter_types.values():
            for expected_type in expected_types:
                if _compare_types(expected_type, actual_type):
                    expected_types.remove(actual_type)
                    break
            else:
                are_same = False
                break
        else:
            are_same = not expected_types
        assert are_same
    else:
        expected_parameter_type_items = sorted(expected_parameter_types.items())
        actual_parameter_type_items = sorted(actual_parameter_types.items())
        assert len(expected_parameter_type_items) == len(actual_parameter_type_items)

        for (expected_k, expected_v), (actual_k, actual_v) in zip(
            expected_parameter_type_items,
            actual_parameter_type_items
        ):
            assert expected_k == actual_k
            assert _compare_types(expected_v, actual_v)


def _compare_generic_args(expected_args: list, actual_args: list) -> bool:
    if expected_args == actual_args:
        return True

    generics_expected_positions_items = defaultdict(list)
    generics_actual_positions_items = defaultdict(list)

    for i, (expected_arg, actual_arg) in enumerate(itertools.zip_longest(expected_args, actual_args)):
        if not isinstance(expected_arg, TypeVar) or not isinstance(actual_arg, TypeVar):
            return False

        generics_expected_positions_items[expected_arg].append(i)
        generics_actual_positions_items[expected_arg].append(i)

    remained_generic_expected_positions = list(generics_expected_positions_items.values())
    for generic_expected_positions in generics_actual_positions_items.values():
        remained_generic_expected_positions.remove(generic_expected_positions)

    return not remained_generic_expected_positions


def _compare_types(expected: Any, actual: Any) -> bool:
    expected_origin = _get_type_origin(expected)
    actual_origin = _get_type_origin(actual)
    expected_args = _get_type_args(expected)
    actual_args = _get_type_args(actual)

    if _compare_generic_args(expected_args, actual_args):
        actual_args = expected_args

    return (
        expected_origin is actual_origin
        and
        (
            not expected_args
            and
            not actual_args or expected_origin[*expected_args] == actual_origin[*actual_args]
        )
    )


def _format_chapter(function_name: str, numbers=False) -> str:
    numbered_chapter = f"{function_name.replace('_test_', '').replace('_', '.')}"
    if numbers:
        return numbered_chapter

    numbers_ = [int(number) for number in numbered_chapter.split('.')]
    parts = [f'{_number_to_roman(numbers_[0]):>{_LETTERS_FORMAT_LEFT_MARGIN}}']
    for number in numbers_[1:]:
        parts.append(f'.{chr(96 + number)}')

    return ''.join(parts)


def _get_type_args(type_: Any) -> list:
    return [None if arg is type(None) else arg for arg in typing.get_args(type_)]


def _get_type_origin(type_: Any) -> Any:
    if origin := typing.get_origin(type_):
        if origin is types.UnionType:
            return typing.Union

        return origin

    return None if type_ is type(None) else type_


def _get_vehicle_str(vehicle: __main__.Vehicle) -> str:
    # noinspection PyProtectedMember
    return f'{type(vehicle).__name__}_{vehicle.plate}. Passengers: {vehicle._passengers}'


def _number_to_roman(number: int) -> str:
    roman_numbers = {
        1000: "m",
        900: "cm",
        500: "d",
        400: "cd",
        100: "c",
        90: "xc",
        50: "l",
        40: "xl",
        10: "x",
        9: "ix",
        5: "v",
        4: "iv",
        1: "i"
    }

    def roman_generator(number_: int) -> Iterator[str]:
        for roman_value in roman_numbers:
            quotient, _ = divmod(number_, roman_value)
            yield roman_numbers[roman_value] * quotient
            number_ -= roman_value * quotient
            if number_ <= 0:
                break

    return ''.join(roman_generator(number))


def _re_find_internal_uses(class_: type) -> set[str]:
    internal_uses = set()
    for member in vars(class_).values():
        if not inspect.isfunction(member):
            continue

        source = inspect.getsource(member).split('\n', maxsplit=1)[1]
        internal_uses.update(_re_findall_without_comments(r'\.(_\w*)', source))

    return internal_uses


def _re_findall_without_comments(pattern: str, text: str) -> list[str]:
    return re.findall(f'^(?!.*#).*{pattern}', text, re.MULTILINE)


def _test_1() -> tuple[float, list[str]]:
    if not any(hasattr(__main__, class_name) for class_name in ('Person', 'Vehicle', 'Car', 'Train')):
        raise NotImplementedError

    total_score = 0
    all_failed_methods = _UniqueList()

    if isinstance(getattr(__main__, 'Person', None), type):
        score, failed_methods = _assert_methods_type_hints(
            __main__.Person,
            (
                (('__init__', {'name': str, 'age': int}, None),),
                (('__le__', {'_other': Any}, bool),),
                (('__lt__', {'_other': Any}, bool),),
                (('__repr__', {}, str),)
            )
        )
        total_score += score
        all_failed_methods += failed_methods

        if isinstance(getattr(__main__, 'Vehicle', None), type):
            score, failed_methods = _assert_methods_type_hints(
                __main__.Vehicle,
                (
                    (('__init__', {'max_passengers': int, 'plate': str | None}, None),),
                )
            )
            total_score += score
            all_failed_methods += failed_methods
        else:
            total_score += 1

        for class_name in ('Vehicle', 'Car', 'Train'):
            if not isinstance(vehicle_class := getattr(__main__, class_name, None), type):
                total_score += 11
                continue

            score, failed_methods = _assert_methods_type_hints(
                vehicle_class,
                (
                    (('__add__', {'_other': Any}, Self),),
                    (('__eq__', {'_other': Any}, bool),),
                    (
                        ('__iter__', {}, Iterator[__main__.Person]),
                        ('__iter__', {}, Generator[__main__.Person, None, None])
                    ),
                    (('__len__', {}, int),),
                    (('__str__', {}, str), ('__repr__', {}, str)),
                    (('add_passenger', {'_passenger': __main__.Person}, None),),
                    (('first_passenger', {'_condition': Callable[[__main__.Person], bool]}, __main__.Person | None),),
                    (('empty', {}, set[__main__.Person]),),
                    (('passengers', {}, set[__main__.Person]),),
                    (('remove_passenger', {'_passenger': __main__.Person}, None),),
                    (('remove_passenger_by_name', {'_name': str}, None),)
                )
            )
            total_score += score
            all_failed_methods += failed_methods
    else:
        total_score += 4 + 11 * 3

    if all(isinstance(getattr(__main__, class_name, None), type) for class_name in ('Car', 'WheelDrive')):
        score, failed_methods = _assert_methods_type_hints(
            __main__.Car,
            (
                (
                    (
                        '__init__',
                        {
                            'doors': int,
                            'airbags': int,
                            'wheel_drive': __main__.WheelDrive,
                            'max_passengers': int,
                            'plate': str | None
                        },
                        None
                    ),
                ),
            )
        )
        total_score += score
        all_failed_methods += failed_methods
    else:
        total_score += 1

    if isinstance(getattr(__main__, 'Train', None), type):
        score, failed_methods = _assert_methods_type_hints(
            __main__.Train,
            (
                (('__init__', {'wagons': int, 'max_passengers': int, 'plate': str | None}, None),),
            )
        )
        total_score += score
        all_failed_methods += failed_methods
    else:
        total_score += 1

    return total_score / _MAX_TYPE_HINTS_SCORE, all_failed_methods


def _test_2_1(person: __main__.Person) -> None:
    if not hasattr(person, 'name'):
        raise NotImplementedError

    assert isinstance(person.name, str)
    if 'age' in inspect.signature(person.__init__).parameters:
        def constructor(name_: str) -> __main__.Person:
            return type(person)(name=name_, age=10)
    else:
        def constructor(name_: str) -> __main__.Person:
            return type(person)(name=name_)

    assert constructor('juan').name == 'Juan'
    assert constructor('   juan lópez').name == 'Juan lópez'
    assert constructor('juan ').name == 'Juan'
    assert constructor(' JUAN ').name == 'Juan'
    assert constructor(' ju An ').name == 'Ju an'


def _test_2_2(person: __main__.Person) -> None:
    if not hasattr(person, 'age'):
        raise NotImplementedError

    assert isinstance(person.age, int)
    if 'name' in inspect.signature(person.__init__).parameters:
        def constructor(age_: int) -> __main__.Person:
            return type(person)(name='_', age=age_)
    else:
        def constructor(age_: int) -> __main__.Person:
            return type(person)(age=age_)

    for age in (0, -1, -2, -5, -10, -999, float('-inf')):
        try:
            constructor(age)
        except ValueError:
            pass
        else:
            raise AssertionError


def _test_2_3(person: __main__.Person) -> None:
    method_names = ('__lt__', '__le__', '__gt__', '__ge__')
    if not any(inspect.ismethod(getattr(person, method_name, None)) for method_name in method_names):
        raise NotImplementedError

    try:
        _test_2_2(person)
    except (AssertionError, NotImplementedError):
        raise ReferenceError

    person_1 = person
    person_1.age = 10
    person_2 = copy.copy(person)
    person_2.age = 25
    person_3 = copy.copy(person)
    person_3.age = 25
    person_4 = copy.copy(person)
    person_4.age = 30
    try:
        assert person_1 < person_2 <= person_3 < person_4
        assert person_4 > person_3 >= person_2 > person_1
        assert sorted((person_3, person_2, person_1, person_4)) in (
            [person_1, person_2, person_3, person_4],
            [person_1, person_3, person_2, person_4]
        )
    except TypeError as e:
        raise AssertionError(e if 'missing' in str(e) else '')

    mock_ = _Mock(**vars(person_2))
    with unittest.mock.patch('builtins.super') as mock_super:
        for method_name in method_names:
            assert getattr(person_1, method_name)(mock_) is NotImplemented
            assert getattr(person_1, method_name)(1) is NotImplemented
            assert getattr(person_1, method_name)('_') is NotImplemented

    assert mock_super.call_count == 6


def _test_2_4(person: __main__.Person) -> None:
    if not inspect.ismethod(person.__repr__):
        raise NotImplementedError

    try:
        _test_2_1(person)
        _test_2_2(person)
    except (AssertionError, NotImplementedError):
        raise ReferenceError

    assert str(type(person)(name='Juan', age=10)) == 'Juan (10)'
    assert str(type(person)(name='Ana', age=35)) == 'Ana (35)'
    assert str(type(person)(name='Elena lara', age=28)) == 'Elena lara (28)'
    assert str(type(person)(name='María josé romero', age=108)) == 'María josé romero (108)'

    assert str([type(person)(name='Juan', age=10)]) == '[Juan (10)]'
    assert str(
        [
            type(person)(name='Ana', age=35),
            type(person)(name='Elena lara', age=28)
        ]
    ) == '[Ana (35), Elena lara (28)]'
    assert str(
        {
            type(person)(name='María josé romero', age=108),
            type(person)(name='Elena lara', age=28)
        }
    ) in {'{María josé romero (108), Elena lara (28)}', '{Elena lara (28), María josé romero (108)}'}


def _test_3_1() -> None:
    has_classes = [hasattr(__main__, class_name) for class_name in ('Vehicle', 'Car', 'Train')]
    if not any(has_classes):
        raise NotImplementedError
    elif not all(has_classes):
        raise AssertionError

    assert isinstance(__main__.Vehicle, ABCMeta)
    assert issubclass(__main__.Car, __main__.Vehicle)
    assert issubclass(__main__.Train, __main__.Vehicle)
    assert __main__.Vehicle.__abstractmethods__
    assert not __main__.Car.__abstractmethods__
    assert not __main__.Train.__abstractmethods__


def _test_3_2_1(car: __main__.Car, train: __main__.Train) -> None:
    if not any(hasattr(vehicle, 'max_passengers') for vehicle in (car, train)):
        raise NotImplementedError

    for vehicle in (car, train):
        assert isinstance(getattr(vehicle, 'max_passengers', None), int)


def _test_3_2_2(car: __main__.Car, train: __main__.Train) -> None:
    if not any(hasattr(vehicle, 'plate') for vehicle in (car, train)):
        raise NotImplementedError

    for vehicle in (car, train):
        assert isinstance(getattr(vehicle, 'plate', None), str)
        assert inspect.signature(vehicle.__init__).parameters['plate'].default is None
        vehicle_vars = {k: v for k, v in vars(vehicle).items() if k not in {'plate', '_passengers'}}
        for _ in range(1000):
            new_plate = getattr(type(vehicle)(**vehicle_vars), 'plate', None)
            assert isinstance(new_plate, str)
            assert len(new_plate) == 4
            assert 0 <= int(new_plate) <= 9999


# noinspection PyProtectedMember
def _test_3_2_3(person: __main__.Person, car: __main__.Car, train: __main__.Train) -> None:
    if not any(hasattr(vehicle, '_passengers') for vehicle in (car, train)):
        raise NotImplementedError

    for vehicle in (car, train):
        assert isinstance(getattr(vehicle, '_passengers', None), set)
        vehicle._passengers.add(person)
        vehicle = type(vehicle)(**{k: v for k, v in vars(vehicle).items() if k != '_passengers'})
        assert not vehicle._passengers


def _test_3_3_1(car: __main__.Car) -> None:
    if not hasattr(car, 'doors'):
        raise NotImplementedError

    assert isinstance(car.doors, int)


def _test_3_3_2(car: __main__.Car) -> None:
    if not hasattr(car, 'airbags'):
        raise NotImplementedError

    assert isinstance(car.airbags, int)


def _test_3_3_3(car: __main__.Car) -> None:
    if not hasattr(car, 'wheel_drive'):
        raise NotImplementedError

    assert isinstance(car.wheel_drive, __main__.WheelDrive)
    assert {member.name for member in __main__.WheelDrive} == {'FRONT', 'REAR'}


def _test_3_4(train: __main__.Train) -> None:
    if not hasattr(train, 'wagons'):
        raise NotImplementedError

    assert isinstance(train.wagons, int)


def _test_3_5(person: __main__.Person, car: __main__.Car, train: __main__.Train) -> None:
    if not isinstance(getattr(__main__, 'Vehicle', None), type):
        raise NotImplementedError

    default_args = defaultdict(int)

    for class_ in (type(person), __main__.Vehicle, type(car), type(train)):
        for member in vars(class_).values():
            if not inspect.isfunction(member) or isinstance(member, property) and not (member := member.fget):
                continue

            for k, v in inspect.signature(member).parameters.items():
                if v.default is not v.empty:
                    default_args[k] += 1

    assert len(default_args) == 1
    assert default_args.get('plate') == 3


def _test_3_6(person: __main__.Person, car: __main__.Car, train: __main__.Train) -> None:
    if (
        not all(hasattr(__main__, class_name) for class_name in ('Vehicle', 'Person', 'Car', 'Train'))
        or
        not any(hasattr(vehicle, '_passengers') for vehicle in (car, train))
    ):
        raise NotImplementedError

    classes_internal_uses = {
        __main__.Vehicle: {'__name__', '_passengers'},
        type(person): {'__le__', '__lt__'},
        type(car): {'__init__'},
        type(train): {'__init__'}
    }
    for class_, class_internal_uses in classes_internal_uses.items():
        assert _re_find_internal_uses(class_) == class_internal_uses


def _test_3_7(person: __main__.Person, car: __main__.Car, train: __main__.Train) -> None:
    if not any(hasattr(type(vehicle), 'passengers') for vehicle in (car, train)):
        raise NotImplementedError

    try:
        _test_3_2_3(person, car, train)
    except (AssertionError, NotImplementedError):
        raise ReferenceError

    for vehicle in (car, train):
        property_ = getattr(type(vehicle), 'passengers', None)
        assert property_.fget and not property_.fset and not property_.fdel
        vehicle.passengers.clear()
        assert vehicle.passengers == set()
        # noinspection PyProtectedMember
        vehicle._passengers.add(person)
        assert vehicle.passengers == {person}


def _test_3_8(car: __main__.Car, train: __main__.Train) -> None:
    if not any(inspect.ismethod(vehicle.__eq__) for vehicle in (car, train)):
        raise NotImplementedError

    for vehicle in (car, train):
        vehicle_2 = copy.deepcopy(vehicle)
        assert vehicle == vehicle_2
        vehicle.plate = '1234'
        vehicle_2.plate = '1230'
        assert vehicle != vehicle_2

        mock_ = _Mock(**vars(vehicle))
        assert vehicle != mock_
        mock_.plate = '1230'
        assert vehicle != mock_


# noinspection PyProtectedMember
def _test_3_9(person: __main__.Person, car: __main__.Car, train: __main__.Train) -> None:
    if not any(isinstance(vehicle, Iterable) for vehicle in (car, train)):
        raise NotImplementedError

    try:
        _test_3_2_3(person, car, train)
    except (AssertionError, NotImplementedError):
        raise ReferenceError

    for vehicle in (car, train):
        vehicle._passengers.clear()
        passengers = set()
        assert isinstance(iter(vehicle), Iterator)
        assert set(vehicle) == passengers
        vehicle._passengers.add(person)
        passengers.add(person)
        assert set(vehicle) == passengers
        person = copy.copy(person)
        vehicle._passengers.add(person)
        passengers.add(person)
        assert set(vehicle) == passengers
        person = copy.copy(person)
        vehicle._passengers.add(person)
        passengers.add(person)
        assert set(vehicle) == passengers


# noinspection PyProtectedMember
def _test_3_10(person: __main__.Person, car: __main__.Car, train: __main__.Train) -> None:
    if not any(hasattr(vehicle, '__len__') for vehicle in (car, train)):
        raise NotImplementedError

    try:
        _test_3_2_3(person, car, train)
    except (AssertionError, NotImplementedError):
        raise ReferenceError

    for vehicle in (car, train):
        vehicle._passengers.clear()
        assert len(vehicle) == 0
        vehicle._passengers.add(person)
        assert len(vehicle) == 1
        vehicle._passengers.add(copy.copy(person))
        assert len(vehicle) == 2
        vehicle._passengers.add(copy.copy(person))
        assert len(vehicle) == 3


# noinspection PyProtectedMember
def _test_3_11(person: __main__.Person, car: __main__.Car, train: __main__.Train) -> None:
    if all(str(vehicle) == object.__repr__(vehicle) for vehicle in (car, train)):
        raise NotImplementedError

    try:
        _test_2_1(person)
        _test_2_2(person)
        _test_3_2_2(car, train)
        _test_3_2_3(person, car, train)
    except (AssertionError, NotImplementedError):
        raise ReferenceError

    passengers = (
        type(person)(name='Juan', age=10),
        type(person)(name='Ana', age=20),
        type(person)(name='Elena', age=35)
    )
    for vehicle in (car, train):
        vehicle._passengers.clear()
        assert str(vehicle) == _get_vehicle_str(vehicle)
        for passenger in passengers:
            vehicle._passengers.add(passenger)
            assert str(vehicle) == _get_vehicle_str(vehicle)


def _test_3_12(person: __main__.Person, car: __main__.Car, train: __main__.Train) -> None:
    if not any(hasattr(vehicle, 'add_passenger') for vehicle in (car, train)):
        raise NotImplementedError

    try:
        _test_3_2_1(car, train)
        _test_3_2_3(person, car, train)
    except (AssertionError, NotImplementedError):
        raise ReferenceError

    for vehicle in (car, train):
        assert inspect.ismethod(getattr(vehicle, 'add_passenger', None))
        # noinspection PyProtectedMember
        vehicle._passengers.clear()
        vehicle.max_passengers = 0
        try:
            vehicle.add_passenger(person)
        except ValueError as e:
            assert str(e) == 'full vehicle'
        else:
            raise AssertionError
        vehicle.max_passengers = 1
        try:
            vehicle.add_passenger(person)
        except ValueError:
            raise AssertionError
        try:
            vehicle.add_passenger(person)
        except ValueError as e:
            assert str(e) == 'full vehicle'
        else:
            raise AssertionError


def _test_3_13(person: __main__.Person, car: __main__.Car, train: __main__.Train) -> None:
    if not any(hasattr(vehicle, 'first_passenger') for vehicle in (car, train)):
        raise NotImplementedError

    try:
        _test_2_1(person)
        _test_2_2(person)
        _test_3_2_3(person, car, train)
    except (AssertionError, NotImplementedError):
        raise ReferenceError

    person_1 = type(person)(name='Juan', age=10)
    person_2 = type(person)(name='Ana', age=20)
    person_3 = type(person)(name='Elena', age=35)
    for vehicle in (car, train):
        assert inspect.ismethod(getattr(vehicle, 'first_passenger', None))
        vehicle._passengers = {person_1, person_2, person_3}
        assert vehicle.first_passenger(lambda person_: person_.name == 'Juan') == person_1
        assert vehicle.first_passenger(lambda person_: person_.age == 10) == person_1
        assert vehicle.first_passenger(lambda person_: person_.name == 'Ana') == person_2
        assert vehicle.first_passenger(lambda person_: person_.age == 20) == person_2
        assert vehicle.first_passenger(lambda person_: person_.name == 'Elena') == person_3
        assert vehicle.first_passenger(lambda person_: person_.age == 35) == person_3
        assert vehicle.first_passenger(lambda person_: person_.age == 999) is None


# noinspection PyProtectedMember
def _test_3_14(person: __main__.Person, car: __main__.Car, train: __main__.Train) -> None:
    if not any(hasattr(vehicle, 'empty') for vehicle in (car, train)):
        raise NotImplementedError

    try:
        _test_3_2_3(person, car, train)
    except (AssertionError, NotImplementedError):
        raise ReferenceError

    person_1 = person
    person_2 = copy.copy(person)
    person_3 = copy.copy(person)
    for vehicle in (car, train):
        assert inspect.ismethod(getattr(vehicle, 'empty', None))

        passengers = {person_1}
        vehicle._passengers = passengers.copy()
        assert vehicle.empty() == passengers
        assert not vehicle._passengers

        passengers = {person_1, person_2}
        vehicle._passengers = passengers.copy()
        assert vehicle.empty() == passengers
        assert not vehicle._passengers

        passengers = {person_1, person_2, person_3}
        vehicle._passengers = passengers.copy()
        assert vehicle.empty() == passengers
        assert not vehicle._passengers


# noinspection PyProtectedMember
def _test_3_15(person: __main__.Person, car: __main__.Car, train: __main__.Train) -> None:
    if not any(hasattr(vehicle, 'remove_passenger') for vehicle in (car, train)):
        raise NotImplementedError

    try:
        _test_3_2_3(person, car, train)
    except (AssertionError, NotImplementedError):
        raise ReferenceError

    person_1 = person
    person_2 = copy.copy(person)
    person_3 = copy.copy(person)
    for vehicle in (car, train):
        assert inspect.ismethod(getattr(vehicle, 'remove_passenger', None))

        passengers = {person_1}
        vehicle._passengers = passengers.copy()
        vehicle.remove_passenger(person_2)
        assert vehicle._passengers == passengers
        vehicle.remove_passenger(person_1)
        assert vehicle._passengers == set()

        passengers = {person_1, person_2}
        vehicle._passengers = passengers.copy()
        vehicle.remove_passenger(person_3)
        assert vehicle._passengers == passengers
        vehicle.remove_passenger(person_1)
        assert vehicle._passengers == {person_2}
        vehicle.remove_passenger(person_2)
        assert vehicle._passengers == set()


# noinspection PyProtectedMember
def _test_3_16(person: __main__.Person, car: __main__.Car, train: __main__.Train) -> None:
    if not any(hasattr(vehicle, 'remove_passenger_by_name') for vehicle in (car, train)):
        raise NotImplementedError

    try:
        _test_2_1(person)
        _test_3_2_3(person, car, train)
    except (AssertionError, NotImplementedError):
        raise ReferenceError

    person_1 = copy.copy(person)
    person_1.name = 'Juan'
    person_2 = copy.copy(person)
    person_2.name = 'Ana'
    person_3 = copy.copy(person)
    person_3.name = 'Elena'
    for vehicle in (car, train):
        assert inspect.ismethod(getattr(vehicle, 'remove_passenger_by_name', None))

        passengers = {person_1}
        vehicle._passengers = passengers.copy()
        vehicle.remove_passenger_by_name(person_2.name)
        assert vehicle._passengers == passengers
        vehicle.remove_passenger_by_name(person_1.name)
        assert vehicle._passengers == set()

        passengers = {person_1, person_2}
        vehicle._passengers = passengers.copy()
        vehicle.remove_passenger_by_name(person_3.name)
        assert vehicle._passengers == passengers
        vehicle.remove_passenger_by_name(person_2.name)
        assert vehicle._passengers == {person_1}
        vehicle.remove_passenger_by_name(person_1.name)
        assert vehicle._passengers == set()


# noinspection PyProtectedMember
def _test_3_17(person: __main__.Person, car: __main__.Car, train: __main__.Train) -> None:
    if not any(inspect.ismethod(getattr(vehicle, '__add__', None)) for vehicle in (car, train)):
        raise NotImplementedError

    try:
        _test_3_2_1(car, train)
        _test_3_2_2(car, train)
        _test_3_2_3(person, car, train)
    except (AssertionError, NotImplementedError):
        raise ReferenceError

    person_1 = person
    person_2 = copy.copy(person)
    person_3 = copy.copy(person)
    person_4 = copy.copy(person)

    car.max_passengers = 0
    car._passengers = {person_1}
    train._passengers = {person_2}
    try:
        car + train
    except ValueError:
        pass
    else:
        raise AssertionError

    train.max_passengers = 1
    car._passengers = {person_1}
    train._passengers = {person_2}
    try:
        train + car
    except ValueError:
        pass
    else:
        raise AssertionError

    car._passengers = set()
    train._passengers = set()
    passengers = car._passengers | train._passengers
    new_car = car + train
    assert car._passengers == set()
    assert train._passengers == set()
    assert type(new_car) is type(car)
    assert new_car.plate != car.plate and new_car._passengers == passengers
    new_train = train + car
    assert car._passengers == set()
    assert train._passengers == set()
    assert type(new_train) is type(train)
    assert new_train.plate != train.plate and new_train._passengers == passengers

    car.max_passengers = 2
    train.max_passengers = 2
    car._passengers = {person_1}
    train._passengers = {person_2}
    passengers = car._passengers | train._passengers
    new_car = car + train
    assert car._passengers == set()
    assert train._passengers == set()
    assert type(new_car) is type(car)
    assert new_car.plate != car.plate and new_car._passengers == passengers
    car._passengers = {person_1}
    train._passengers = {person_2}
    new_train = train + car
    assert car._passengers == set()
    assert train._passengers == set()
    assert type(new_train) is type(train)
    assert new_train.plate != train.plate and new_train._passengers == passengers

    car.max_passengers = 9
    train.max_passengers = 9
    car._passengers = {person_1, person_2}
    train._passengers = {person_2, person_3, person_4}
    passengers = car._passengers | train._passengers
    new_car = car + train
    assert car._passengers == set()
    assert train._passengers == set()
    assert type(new_car) is type(car)
    assert new_car.plate != car.plate and new_car._passengers == passengers
    car._passengers = {person_1, person_2}
    train._passengers = {person_2, person_3, person_4}
    new_train = train + car
    assert car._passengers == set()
    assert train._passengers == set()
    assert type(new_train) is type(train)
    assert new_train.plate != train.plate and new_train._passengers == passengers


def test(
    person: __main__.Person | None = None,
    car: __main__.Car | None = None,
    train: __main__.Train | None = None,
    numbers=False
) -> None:
    def add_args(class_name_: str, piece_: Any) -> None:
        if class_name_.lower() in (
            parameter_name.strip('_') for parameter_name in inspect.signature(function).parameters
        ):
            if not (piece_class := getattr(__main__, class_name_, None)) or not isinstance(piece_, piece_class):
                raise NotImplementedError

            args.append(copy.copy(piece_))

    for function_name, function in globals().items():
        if not function_name.startswith('_test_'):
            continue

        args = []
        format_width = _NUMERIC_FORMAT_WIDTH if numbers else _LETTERS_FORMAT_WIDTH
        result_prefix = f'{_format_chapter(function_name, numbers):{format_width}}'

        class_names = ('Person', 'Car', 'Train')
        objects = (person, car, train)

        try:
            for class_name, piece in zip(class_names, objects):
                add_args(class_name, piece)

            result = function(*args)
        except NotImplementedError:
            result_message = '...'
        except ReferenceError as e:
            cause_function_name = e.__context__.__traceback__.tb_next.tb_frame.f_code.co_name
            failed_required_chapter = f' <- {_format_chapter(cause_function_name, numbers)}'
            result_message = f'❌{failed_required_chapter}'
        except AssertionError as e:
            result_message = f"❌{f' {e}' if str(e) else ''}"
        except Exception as e:
            traceback = e.__traceback__
            while traceback.tb_next:
                traceback = traceback.tb_next
            if (f_code := traceback.tb_frame.f_code).co_filename.endswith('main.py'):
                message = f'{e} ➡️ in {f_code.co_qualname}'
            else:
                message = str(e)
            result_message = f"❌{' ' if str(e) else ''}{message}"
        else:
            if function_name == '_test_1':
                ratio, _ = result
                result_message = f"{'✅' if ratio == 1 else '❌'} {ratio:.0%}"
            else:
                result_message = '✅'

        print(f'{result_prefix}{result_message}')


def test_type_hints() -> None:
    ratio, failed_methods = _test_1()
    print()
    print(f"Type hints: {'✅ ' if ratio == 1 else ''}{ratio:.0%}")

    if failed_methods:
        print()
        print('Failed:')
        print('-------')
        for failed_method in failed_methods:
            print(failed_method)

    print()
