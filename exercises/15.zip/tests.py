import inspect
import sys
from io import StringIO
from typing import Callable

from data import Gender, countries, students, subjects

FUNCTION_NAMES = (
    'find_name_by_id',
    'find_id_by_name',
    'select_student',
    'find_students_by_age',
    'find_student_country',
    'students_by_subject_and_gender_count',
    'join',
    'function_1',
    'function_2',
    'function_3',
    'function_4',
    'function_5',
    'function_6',
    'function_7',
    'function_8',
    'function_9'
)

is_tested = False


def _is_implemented(function: Callable) -> bool:
    if not function:
        return False

    lines = inspect.getsource(function).splitlines()
    return len(lines) != 2 or lines[1].strip() != '...'


def _test_students(expected: list[dict], actual: list[dict]) -> None:
    assert len(expected) == len(actual)

    for item in actual:
        for key, value in item.items():
            if isinstance(value, list):
                value = set(value)
            item[key] = value

    for item in expected:
        for key, value in item.items():
            if isinstance(value, list):
                value = set(value)
            item[key] = value

        if item in actual:
            actual.remove(item)
        else:
            raise AssertionError


def _test_find_name_by_id(find_name_by_id: Callable[[list[dict], int], str | None]) -> None:
    assert find_name_by_id(students, 7) == '小明'
    assert find_name_by_id(students, 21) == 'Elena'
    assert find_name_by_id(countries, 3) == 'China'
    assert find_name_by_id(subjects, 5) == 'Chemistry'
    assert find_name_by_id(students, 1) is None


def _test_find_id_by_name(find_id_by_name: Callable[[list[dict], str], int | None]) -> None:
    assert find_id_by_name(students, '小明') == 7
    assert find_id_by_name(students, 'Lìlì') == 29
    assert find_id_by_name(countries, 'Germany') == 5
    assert find_id_by_name(subjects, 'History') == 3
    assert find_id_by_name(students, 'Alberto') is None


def _test_select_student(select_student: Callable[[dict, list[str]], dict]) -> None:
    assert select_student(
        {'id': 7, 'name': '小明', 'last_name': '王', 'age': 16, 'gender': Gender.MALE, 'country': 'China', 'subjects': ['Mathematics', 'Literature', 'Chemistry']},
        ['id', 'name', 'last_name', 'age', 'gender', 'country', 'subjects']
    ) == {'id': 7, 'name': '小明', 'last_name': '王', 'age': 16, 'gender': Gender.MALE, 'country': 'China', 'subjects': ['Mathematics', 'Literature', 'Chemistry']}
    assert select_student(
        {'id': 29, 'name': 'Lìlì', 'last_name': 'Lǐ', 'age': 18, 'gender': Gender.FEMALE, 'country': 'China', 'subjects': ['Mathematics', 'Computer Science']},
        ['name', 'last_name', 'gender']
    ) == {'name': 'Lìlì', 'last_name': 'Lǐ', 'gender': Gender.FEMALE}
    assert select_student(
        {'id': 52, 'name': 'Thomas', 'last_name': 'Mülle'},
        ['id', 'last_name']
    ) == {'id': 52, 'last_name': 'Mülle'}
    assert select_student(
        {'last_name': 'Taylor', 'age': 32, 'gender': Gender.FEMALE, 'country': 'United Kingdom'},
        ['age', 'country']
    ) == {'age': 32, 'country': 'United Kingdom'}
    assert select_student(
        {'last_name': 'Taylor', 'age': 32, 'gender': Gender.FEMALE, 'country': 'United Kingdom'},
        []
    ) == {}
    assert select_student(
        {'last_name': 'Taylor', 'age': 32, 'gender': Gender.FEMALE, 'country': 'United Kingdom'},
        ['_']
    ) == {}


def _test_find_students_by_age(find_students_by_age: Callable[[int, int], list[dict]]) -> None:
    _test_students(
        find_students_by_age(1, 99),
        [
            {'name': '小明', 'last_name': '王'},
            {'name': 'John', 'last_name': 'Smith'},
            {'name': 'Elena', 'last_name': 'Ruiz'},
            {'name': '太郎', 'last_name': '佐藤'},
            {'name': 'Lìlì', 'last_name': 'Lǐ'},
            {'name': 'Luis', 'last_name': 'López'},
            {'name': 'Yumiko', 'last_name': 'Suzuki'},
            {'name': 'Thomas', 'last_name': 'Mülle'},
            {'name': 'Emily', 'last_name': 'Johnson'},
            {'name': 'Sarah', 'last_name': 'Taylor'},
            {'name': 'Rahul', 'last_name': 'Sharma'},
            {'name': 'Lisa', 'last_name': 'Schmidt'},
            {'name': 'Priya', 'last_name': 'Patel'}
        ]
    )
    _test_students(find_students_by_age(19, 20), [])
    _test_students(
        find_students_by_age(18, 25),
        [
            {'name': 'John', 'last_name': 'Smith'},
            {'name': '太郎', 'last_name': '佐藤'},
            {'name': 'Lìlì', 'last_name': 'Lǐ'},
            {'name': 'Yumiko', 'last_name': 'Suzuki'},
            {'name': 'Priya', 'last_name': 'Patel'}
        ]
    )
    _test_students(
        find_students_by_age(30, 40),
        [
            {'name': 'Elena', 'last_name': 'Ruiz'},
            {'name': 'Sarah', 'last_name': 'Taylor'}
        ]
    )
    _test_students(
        find_students_by_age(20, 50),
        [
            {'name': 'John', 'last_name': 'Smith'},
            {'name': 'Elena', 'last_name': 'Ruiz'},
            {'name': '太郎', 'last_name': '佐藤'},
            {'name': 'Sarah', 'last_name': 'Taylor'},
            {'name': 'Lisa', 'last_name': 'Schmidt'},
            {'name': 'Priya', 'last_name': 'Patel'}
        ]
    )
    _test_students(
        find_students_by_age(50, 90),
        [
            {'name': 'Luis', 'last_name': 'López'},
            {'name': 'Thomas', 'last_name': 'Mülle'},
            {'name': 'Emily', 'last_name': 'Johnson'}
        ]
    )


def _test_find_student_country(find_student_country: Callable[[int], str | None]) -> None:
    assert find_student_country(7) == 'China'
    assert find_student_country(8) is None
    assert find_student_country(30) == 'Spain'
    assert find_student_country(52) == 'Germany'
    assert find_student_country(103) == 'India'


def _test_students_by_subject_and_gender_count(
    students_by_subject_and_gender_count: Callable[[str, Gender], int]
) -> None:
    assert students_by_subject_and_gender_count('Mathematics', Gender.FEMALE) == 2
    assert students_by_subject_and_gender_count('History', Gender.MALE) == 1
    assert students_by_subject_and_gender_count('Literature', Gender.FEMALE) == 4
    assert students_by_subject_and_gender_count('Biology', Gender.MALE) == 2
    assert students_by_subject_and_gender_count('Chemistry', Gender.FEMALE) == 3


def _test_join(join: Callable[[list[dict]], list[dict]]) -> None:
    _test_students(join([]), [])
    _test_students(
        join([{'id': 25, 'name': '太郎', 'last_name': '佐藤', 'age': 25, 'gender': Gender.MALE, 'country_id': 1}]),
        [{'id': 25, 'name': '太郎', 'last_name': '佐藤', 'age': 25, 'gender': Gender.MALE, 'country': 'Japan', 'subjects': ['Computer Science']}]
    )
    _test_students(join(students), [
        {'id': 7, 'name': '小明', 'last_name': '王', 'age': 16, 'gender': Gender.MALE, 'country': 'China', 'subjects': ['Mathematics', 'Literature', 'Chemistry']},
        {'id': 18, 'name': 'John', 'last_name': 'Smith', 'age': 22, 'gender': Gender.MALE, 'country': 'United States', 'subjects': ['Literature']},
        {'id': 21, 'name': 'Elena', 'last_name': 'Ruiz', 'age': 37, 'gender': Gender.FEMALE, 'country': 'Spain', 'subjects': ['Literature', 'Biology']},
        {'id': 25, 'name': '太郎', 'last_name': '佐藤', 'age': 25, 'gender': Gender.MALE, 'country': 'Japan', 'subjects': ['Computer Science']},
        {'id': 29, 'name': 'Lìlì', 'last_name': 'Lǐ', 'age': 18, 'gender': Gender.FEMALE, 'country': 'China', 'subjects': ['Mathematics', 'Computer Science']},
        {'id': 30, 'name': 'Luis', 'last_name': 'López', 'age': 54, 'gender': Gender.MALE, 'country': 'Spain', 'subjects': ['Mathematics']},
        {'id': 37, 'name': 'Yumiko', 'last_name': 'Suzuki', 'age': 18, 'gender': Gender.FEMALE, 'country': 'Japan', 'subjects': ['Literature', 'History']},
        {'id': 52, 'name': 'Thomas', 'last_name': 'Mülle', 'age': 67, 'gender': Gender.MALE, 'country': 'Germany', 'subjects': ['Biology', 'Chemistry', 'Computer Science']},
        {'id': 61, 'name': 'Emily', 'last_name': 'Johnson', 'age': 55, 'gender': Gender.FEMALE, 'country': 'United States', 'subjects': ['Literature', 'Biology', 'Chemistry']},
        {'id': 66, 'name': 'Sarah', 'last_name': 'Taylor', 'age': 32, 'gender': Gender.FEMALE, 'country': 'United Kingdom', 'subjects': ['Mathematics', 'Literature', 'History']},
        {'id': 79, 'name': 'Rahul', 'last_name': 'Sharma', 'age': 17, 'gender': Gender.MALE, 'country': 'India', 'subjects': ['Mathematics', 'Literature', 'History', 'Biology', 'Chemistry', 'Computer Science']},
        {'id': 85, 'name': 'Lisa', 'last_name': 'Schmidt', 'age': 29, 'gender': Gender.FEMALE, 'country': 'Germany', 'subjects': ['History', 'Chemistry']},
        {'id': 103, 'name': 'Priya', 'last_name': 'Patel', 'age': 22, 'gender': Gender.FEMALE, 'country': 'India', 'subjects': ['Biology', 'Chemistry', 'Computer Science']}
    ])


def _test_function_1(function_1: Callable[[list[str]], list[dict]]) -> None:
    _test_students(
        function_1(['Literature']),
        [
            {'id': 7, 'name': '小明', 'age': 16},
            {'id': 18, 'name': 'John', 'age': 22},
            {'id': 79, 'name': 'Rahul', 'age': 17}
        ]
    )
    _test_students(
        function_1(['Literature', 'Mathematics']),
        [
            {'id': 7, 'name': '小明', 'age': 16},
            {'id': 18, 'name': 'John', 'age': 22},
            {'id': 79, 'name': 'Rahul', 'age': 17},
            {'id': 30, 'name': 'Luis', 'age': 54}
        ]
    )
    _test_students(
        function_1(['Biology', 'Chemistry']),
        [
            {'id': 7, 'name': '小明', 'age': 16},
            {'id': 52, 'name': 'Thomas', 'age': 67},
            {'id': 79, 'name': 'Rahul', 'age': 17},
        ]
    )
    _test_students(
        function_1(['Biology', 'Chemistry']),
        [
            {'id': 7, 'name': '小明', 'age': 16},
            {'id': 52, 'name': 'Thomas', 'age': 67},
            {'id': 79, 'name': 'Rahul', 'age': 17},
        ]
    )
    _test_students(function_1([]), [])


def _test_function_2(function_2: Callable[[list[str]], list[dict]]) -> None:
    _test_students(
        function_2(['Literature']),
        [
            {'name': 'John', 'last_name': 'Smith'},
            {'name': 'Elena', 'last_name': 'Ruiz'},
            {'name': 'Yumiko', 'last_name': 'Suzuki'},
            {'name': 'Emily', 'last_name': 'Johnson'},
            {'name': 'Sarah', 'last_name': 'Taylor'}
        ]
    )
    _test_students(
        function_2(['Mathematics', 'Computer Science']),
        [
            {'name': 'Lìlì', 'last_name': 'Lǐ'}
        ]
    )
    _test_students(
        function_2(['History', 'Literature']),
        [
            {'name': 'Yumiko', 'last_name': 'Suzuki'},
            {'name': 'Sarah', 'last_name': 'Taylor'}
        ]
    )
    _test_students(
        function_2(['Biology', 'Chemistry', 'Literature']),
        [
            {'name': 'Emily', 'last_name': 'Johnson'}
        ]
    )
    _test_students(
        function_2(['Mathematics', 'Chemistry', 'History', 'Biology', 'Computer Science', 'Literature']),
        []
    )
    _test_students(
        function_2([]),
        [
            {'name': 'John', 'last_name': 'Smith'},
            {'name': 'Elena', 'last_name': 'Ruiz'},
            {'name': '太郎', 'last_name': '佐藤'},
            {'name': 'Lìlì', 'last_name': 'Lǐ'},
            {'name': 'Luis', 'last_name': 'López'},
            {'name': 'Yumiko', 'last_name': 'Suzuki'},
            {'name': 'Thomas', 'last_name': 'Mülle'},
            {'name': 'Emily', 'last_name': 'Johnson'},
            {'name': 'Sarah', 'last_name': 'Taylor'},
            {'name': 'Lisa', 'last_name': 'Schmidt'},
            {'name': 'Priya', 'last_name': 'Patel'}
        ]
    )


def _test_function_3(function_3: Callable[[], list[str]]) -> None:
    assert set(function_3()) == {'Lìlì', 'Yumiko', 'Priya'}


def _test_function_4(function_4: Callable[[int], int | None]) -> None:
    assert function_4(0) is None
    assert function_4(1) == 30
    assert function_4(2) == 85
    assert function_4(3) == 103
    assert function_4(4) is None
    assert function_4(5) is None
    assert function_4(6) == 79
    assert function_4(7) is None


def _test_function_5(function_5: Callable[[str, list[str]], int]) -> None:
    assert function_5('Biology', ['Spain', 'Germany', 'United Kingdom']) == 2
    assert function_5('Literature', ['Spain', 'India', 'United Kingdom']) == 3
    assert function_5('_', ['Spain', 'India', 'United Kingdom']) == 0
    assert function_5('Literature', ['_', '_']) == 0
    assert function_5('History', ['Japan']) == 1
    assert function_5('Computer Science', ['India']) == 2
    assert function_5('Computer Science', ['India', 'Japan']) == 3
    assert function_5('Computer Science', ['India', 'Japan', 'Germany']) == 4


def _test_function_6(function_6: Callable[[], int]) -> None:
    assert function_6() == 3


def _test_function_7(function_7: Callable[[], float]) -> None:
    assert function_7() == sum((25, 67, 17)) / 3


def _test_function_8(function_8: Callable[[], list[str]]) -> None:
    assert function_8() == ['王', 'Lǐ', 'Mülle', 'Schmidt', 'Sharma', 'Patel', '佐藤', 'Suzuki', 'Ruiz', 'López',
                            'Taylor', 'Smith', 'Johnson']


def _test_function_9(function_9: Callable[[], None]) -> None:
    buffer = StringIO()
    stdout = sys.stdout
    sys.stdout = buffer
    function_9()
    sys.stdout = stdout
    content = buffer.getvalue()
    print(content, end='')

    assert content.strip() == '\n'.join(
        (
            'Mathematics',
            '-----------',
            'Male: 60%',
            'Female: 40%',
            '',
            'Literature',
            '----------',
            'Male: 43%',
            'Female: 57%',
            '',
            'History',
            '-------',
            'Male: 25%',
            'Female: 75%',
            '',
            'Biology',
            '-------',
            'Male: 40%',
            'Female: 60%',
            '',
            'Chemistry',
            '---------',
            'Male: 50%',
            'Female: 50%',
            '',
            'Computer Science',
            '----------------',
            'Male: 60%',
            'Female: 40%'
        )
    )


def test() -> None:
    global is_tested

    import main

    if is_tested:
        return

    is_tested = True

    for i, function_name in enumerate(FUNCTION_NAMES, start=1):
        function = getattr(main, function_name, None)
        result_prefix = f'{i:>2}: '
        if not _is_implemented(function):
            print(f'{result_prefix}...')
            continue

        try:
            globals()[f'_test_{function_name}'](function)
        except AssertionError:
            print(f'{result_prefix}❌')
        else:
            print(f'{result_prefix}✅')
