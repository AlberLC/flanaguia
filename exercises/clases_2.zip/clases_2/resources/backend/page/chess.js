const BOARD_LENGTH = 8
const CELL_PX_LENGTH = 70

function aiMove() {
    if (!isGameEnded) {
        sendJson("move_ai")
    }
}

function applySelectable() {
    document.querySelectorAll(".cell").forEach(cell => {
        if (!isGameEnded && isHumanTurn && cell.classList.contains("human-piece")) {
            cell.classList.add("selectable")
        } else {
            cell.classList.remove("selectable")
        }
    })
}

function deselectCells() {
    if (!lastSelectedCell) {
        return
    }

    lastSelectedCell.classList.remove("selected")
    document.querySelectorAll(".cell").forEach(cell => {
        cell.classList.remove("valid-move", "hover-float-cell")
        applySelectable()

        if (!isCheckedPosition(cell)) {
            cell.classList.remove("capturable")
        }
    })
}

function doMoveTransition(oldRow, oldColumn, newRow, newColumn) {
    const img = board[oldRow][oldColumn].querySelector("img")
    const deltaRows = newRow - oldRow
    const deltaColumns = newColumn - oldColumn
    img.style.zIndex = 1
    img.style.transform = `translate(${deltaColumns * CELL_PX_LENGTH}px, ${deltaRows * CELL_PX_LENGTH}px)`
}

function highlightCapturable() {
    checkedPositions.forEach(([row, column]) => {
        const capturableCell = board[row][column]
        capturableCell.classList.add("capturable")
    })
}

async function highlightMoveset(cell) {
    const row = Number(cell.getAttribute("row"))
    const column = Number(cell.getAttribute("column"))
    sendJson("get_human_moveset", [row, column])
}

function isCheckedPosition(cell) {
    const row = cell.getAttribute("row")
    const column = cell.getAttribute("column")
    return checkedPositions.some((position) => position[0] == row && position[1] == column)
}


function loadNextBoard(newBoardData, checkState, newCheckedPositions, whiteScore, blackScore) {
    checkedPositions = newCheckedPositions
    isHumanTurn = !isHumanTurn
    updateCheckState(checkState)

    board_element.innerHTML = ""

    for (let i = 0; i < board.length; i++) {
        for (let j = 0; j < board.length; j++) {
            const cell = document.createElement("div")

            cell.setAttribute("row", i.toString())
            cell.setAttribute("column", j.toString())

            cell.className = "cell"
            if ((i + j) % 2 === 0) {
                cell.classList.add("bg-white")
            } else {
                cell.classList.add("bg-black")
            }

            let cellData = newBoardData[i][j]
            if (cellData) {
                const [color, svgUrl] = cellData

                const img = document.createElement("img")
                img.src = svgUrl
                img.className = "mouse-transparent"
                cell.appendChild(img)

                if (color === humanColor) {
                    cell.classList.add("human-piece")
                } else {
                    cell.classList.add("ai-piece")
                }
            }

            cell.addEventListener("click", onCellClick)

            board_element.appendChild(cell)
            board[i][j] = cell
        }
    }

    updateScore(whiteScore, blackScore)
    highlightCapturable()
    applySelectable()
}

function moveWithTransition(
    newBoardData,
    checkState,
    newCheckedPositions,
    whiteScore,
    blackScore,
    oldRow,
    oldColumn,
    newRow,
    newColumn,
    callback
) {
    board[oldRow][oldColumn].addEventListener("transitionend", async () => {
        loadNextBoard(newBoardData, checkState, newCheckedPositions, whiteScore, blackScore)

        if (callback) {
            await callback()
        }
    })

    doMoveTransition(oldRow, oldColumn, newRow, newColumn)
}


async function onCellClick(event) {
    const cell = event.target
    if (!cell.classList.contains("selectable")) {
        deselectCells()
        lastSelectedCell = null
        return
    }

    if (cell.classList.contains("human-piece")) {
        deselectCells()

        if (cell === lastSelectedCell) {
            lastSelectedCell = null
        } else {
            await selectCell(cell)
        }
    } else if (lastSelectedCell) {
        const currentRow = Number(lastSelectedCell.getAttribute("row"))
        const currentColumn = Number(lastSelectedCell.getAttribute("column"))
        const newRow = Number(cell.getAttribute("row"))
        const newColumn = Number(cell.getAttribute("column"))
        sendJson("move_human", [[currentRow, currentColumn], [newRow, newColumn]])
    }
}

async function selectCell(cell) {
    cell.classList.add("selected")
    lastSelectedCell = cell

    await highlightMoveset(cell)
}

function sendJson(type, data) {
    socket.send(JSON.stringify([type, data]))
}

function updateCheckState(checkState) {
    const state = document.getElementById("state")
    switch (checkState) {
        case 0:
            state.textContent = ""
            break
        case 1:
            state.textContent = "⚠️ JAQUE"
            break
        case 2:
            state.textContent = "👀 JAQUE"
            break
        case 3:
            state.textContent = "💀 JAQUE MATE"
            isGameEnded = true
            break
        case 4:
            state.textContent = "🎉 JAQUE MATE"
            isGameEnded = true
            break
        case 5:
            document.getElementById("state").style.fontSize = "2.5rem"
            state.innerText = "⚰️ Te has pasado las normas\npor el forro y has matado al rey"
            isGameEnded = true
            break
    }
}

function updateScore(whiteScore, blackScore) {
    document.querySelector("#white-container .score-counter").textContent = whiteScore
    document.querySelector("#black-container .score-counter").textContent = blackScore
}

const board_element = document.getElementById("chessboard")
const board = Array.from({length: BOARD_LENGTH}, () => Array(BOARD_LENGTH).fill(null))
let checkedPositions
let humanColor
let isHumanTurn
let isGameEnded = false
let lastSelectedCell

const socket = new WebSocket(`ws://localhost:${window.location.port}/ws`)

socket.onopen = async () => {
    sendJson("board")
}

socket.onmessage = (event) => {
    const [type, ...data] = JSON.parse(event.data)
    switch (type) {
        case "board":
            let newData
            [humanColor, ...newData] = data
            isHumanTurn = humanColor !== "white"
            lastSelectedCell = null

            loadNextBoard(...newData)
            if (!isHumanTurn) {
                aiMove()
            }
            break
        case "get_human_moveset":
            data.forEach(([row, column]) => {
                const moveCell = board[row][column]
                moveCell.classList.add("selectable", "hover-float-cell")
                if (moveCell.classList.contains("ai-piece")) {
                    moveCell.classList.add("capturable")
                } else {
                    moveCell.classList.add("valid-move")
                }
            })
            break
        case "move_ai":
            moveWithTransition(...Object.values(data))
            break
        case "move_human":
            lastSelectedCell = null
            moveWithTransition(...Object.values(data), aiMove)
            break
    }
}



