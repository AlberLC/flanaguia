import inspect
import time
import types
import typing
from collections.abc import Callable, Generator, Iterable, Iterator
from typing import Any, Self

_LEFT_MARGIN_SPACES = 24
_MAX_SHOWED_TESTS = 7
_TAB_SIZE = 4
_TESTS_NUMBER_DIGITS = 3


class _UniqueList(list):
    def __iadd__(self, other: Iterable) -> Self:
        for element in other:
            if element not in self:
                self.append(element)

        return self


def _assert_methods_type_hints(
    vehicle_class: type,
    type_hint_checks: tuple[tuple[tuple[str, dict[str, Any], Any], ...], ...]
) -> tuple[int, list[str]]:
    score = 0
    failed_methods = _UniqueList()
    if not type_hint_checks:
        return score, failed_methods

    for method_alternative_checks in type_hint_checks:
        is_implemented = False
        failed_method_alternatives = []
        for method_name, parameter_hints, return_hint in method_alternative_checks:
            method = getattr(vehicle_class, method_name, None)
            try:
                if isinstance(method, property):
                    assert method.fget
                    method = method.fget
                elif not inspect.isfunction(method):
                    continue

                is_implemented = True
                type_hints = typing.get_type_hints(method)
                assert 'return' in type_hints
                assert _compare_types(return_hint, type_hints.pop('return'))
                _assert_parameters_type_hints(parameter_hints, type_hints)
            except AssertionError:
                failed_method_alternatives.append(str(method.__qualname__))
            else:
                break

        if not is_implemented or len(failed_method_alternatives) != len(method_alternative_checks):
            score += 1
        else:
            failed_methods.append(failed_method_alternatives[0])

    return score, failed_methods


def _assert_parameters_type_hints(
    expected_parameter_hints: dict[str, type],
    actual_type_hints: dict[str, type]
) -> None:
    if any(k.startswith('_') for k in expected_parameter_hints):
        matches = 0
        actual_types = list(actual_type_hints.values())
        for expected_type in expected_parameter_hints.values():
            for actual_type in actual_types:
                if _compare_types(expected_type, actual_type):
                    matches += 1
                    actual_types.remove(actual_type)
                    break
            else:
                break
        assert matches == len(expected_parameter_hints) and not actual_types
    else:
        expected_parameters_hints_items = sorted(expected_parameter_hints.items())
        actual_type_hints_items = sorted(
            (k, v) for k, v in actual_type_hints.items() if k in expected_parameter_hints
        )
        assert len(expected_parameters_hints_items) == len(actual_type_hints_items)

        for (expected_k, expected_v), (actual_k, actual_v) in zip(
            expected_parameters_hints_items,
            actual_type_hints_items
        ):
            assert expected_k == actual_k
            assert _compare_types(expected_v, actual_v)


def _compare_types(expected: Any, actual: Any) -> bool:
    expected_origin = _get_type_origin(expected)
    actual_origin = _get_type_origin(actual)
    expected_args = _get_type_args(expected)
    actual_args = _get_type_args(actual)

    return (
        expected_origin is actual_origin
        and
        (
            not expected_args and not actual_args
            or
            expected_origin[*expected_args] == actual_origin[*actual_args]
        )
    )


def _get_type_args(type_: Any) -> list:
    return [None if arg is type(None) else arg for arg in typing.get_args(type_)]


def _get_type_origin(type_: Any) -> Any:
    if origin := typing.get_origin(type_):
        if origin is types.UnionType:
            return typing.Union

        return origin

    return None if type_ is type(None) else type_


def _linked_list_str(elements: list) -> str:
    return f'<{str(elements)[1:-1]}>'


def _test_general() -> tuple[str, str]:
    import __main__

    result_prefix = 'Test general: '
    if not isinstance(getattr(__main__, 'LinkedList', None), type):
        return result_prefix, '...'

    last_tests = []
    try:
        _test_general_(__main__.LinkedList, last_tests)
    except AssertionError:
        first_lines = ['']

        for i, test_ in enumerate(last_tests[:-1]):
            last_tests[i] = f'{i + 1:{_TESTS_NUMBER_DIGITS}} ⬇️ {test_}'
        last_tests[-1] = f'{len(last_tests):{_TESTS_NUMBER_DIGITS}} ❌ {last_tests[-1]}'

        if len(last_tests) > _MAX_SHOWED_TESTS:
            first_lines.append(f"{' ' * _TESTS_NUMBER_DIGITS} ⬇️ ...")
            last_tests = last_tests[-_MAX_SHOWED_TESTS:]

        result_message = '\n'.join(f"{' ' * _TAB_SIZE}{test_}" for test_ in (*first_lines, *last_tests))
    else:
        result_message = '✅'

    return result_prefix, result_message


def _test_general_(LinkedList: type, last_tests: list) -> None:
    def add(element: Any) -> None:
        message_prefix = f'linked_list.add({repr(element)})'
        not_raise_error(lambda: linked_list.add(element), message_prefix)
        elements.append(element)

    def clear() -> None:
        message_prefix = 'linked_list.clear()'
        not_raise_error(lambda: linked_list.clear(), message_prefix)
        elements.clear()

    def del_(index: int, raise_=False) -> None:
        message_prefix = f'del linked_list[{index}]'
        raise_error(
            lambda: del_element(index),
            message_prefix,
            IndexError('list index out of range') if raise_ else None
        )

        if not raise_:
            del elements[index]

    def del_element(index: int) -> None:
        del linked_list[index]

    def get(index: int, raise_=False) -> None:
        if raise_:
            message_prefix_getitem = f'linked_list[{index}]'
            message_prefix_get = f'linked_list.get({index})'
        else:
            message_prefix_getitem = f'linked_list[{index}] == {repr(elements[index])}'
            message_prefix_get = f'linked_list.get({index}) == {repr(elements[index])}'

        exception = IndexError('list index out of range')

        result = raise_error(lambda: linked_list[index], message_prefix_getitem, exception if raise_ else None)
        assert isinstance(result, IndexError) if raise_ else result == elements[index]

        result = raise_error(lambda: linked_list.get(index), message_prefix_get, exception if raise_ else None)
        assert isinstance(result, IndexError) if raise_ else result == elements[index]

    def in_(element: Any, not_=False) -> None:
        message_prefix = f'{repr(element)} in linked_list'
        assert not_raise_error(lambda: element not in linked_list if not_ else element in linked_list, message_prefix)

    def insert(index: int, element: Any) -> None:
        message_prefix = f'linked_list.insert({index}, {repr(element)})'
        not_raise_error(lambda: linked_list.insert(index, element), message_prefix)
        elements.insert(index, element)

    def len_() -> None:
        message_prefix = f'len(linked_list) == {len(elements)}'
        assert not_raise_error(lambda: len(linked_list) == len(elements), message_prefix)

    def list_() -> None:
        message_prefix = f'list(linked_list) == {elements}'
        assert not_raise_error(lambda: list(linked_list) == elements, message_prefix)

    def not_raise_error(function: Callable[[], Any], message_prefix: str) -> Any:
        try:
            result = function()
        except Exception as e:
            last_tests.append(f'{message_prefix} <- {e}')
            raise AssertionError

        last_tests.append(message_prefix)
        return result

    def raise_error(function: Callable[[], Any], message_prefix: str, exception: Exception | None = None) -> Any:
        try:
            result = function()
        except Exception as e:
            if isinstance(e, type(exception)):
                if str(e) == str(exception):
                    last_tests.append(f'{message_prefix} <- {e}')
                    return e
                else:
                    last_tests.append(f'{message_prefix} <- Mensaje de error incorrecto')
            else:
                last_tests.append(f'{message_prefix} <- {e}')

            raise AssertionError
        else:
            if exception:
                last_tests.append(f'{message_prefix} <- No lanza una excepción')
                raise AssertionError

            last_tests.append(message_prefix)
            return result

    def remove(element: Any, raise_=False) -> None:
        message_prefix = f'linked_list.remove({repr(element)})'
        raise_error(
            lambda: linked_list.remove(element),
            message_prefix,
            ValueError(f'{repr(element)} not in list') if raise_ else None
        )

        if not raise_:
            elements.remove(element)

    def set_(index: int, element: Any, raise_=False) -> None:
        exception = IndexError('list index out of range')

        message_prefix = f'linked_list[{index}] = {repr(element)}'
        raise_error(lambda: setitem_function(index, element), message_prefix, exception if raise_ else None)

        message_prefix = f'linked_list.set({index}, {repr(element)}) = {repr(element)}'
        raise_error(lambda: set_function(index, element), message_prefix, exception if raise_ else None)

        if not raise_:
            elements[index] = element

    def set_function(index: int, element: Any) -> None:
        linked_list.set(index, element)

    def setitem_function(index: int, element: Any) -> None:
        linked_list[index] = element

    def str_() -> None:
        elements_str = _linked_list_str(elements)
        message_prefix = f'str(linked_list) == {elements_str}'
        assert not_raise_error(lambda: str(linked_list) == elements_str, message_prefix)

    elements = []
    linked_list = LinkedList()

    str_()
    len_()

    add(1)
    in_(1)
    list_()
    len_()
    str_()
    add('b')
    in_('b')
    list_()
    str_()
    len_()
    add(None)
    in_(None)
    list_()
    str_()
    len_()
    add(False)
    in_(False)
    list_()
    len_()
    str_()
    in_(2, not_=True)
    str_()
    len_()
    in_('c', not_=True)
    len_()
    str_()

    get(0)
    get(1)
    get(2)
    get(3)
    list_()
    str_()
    len_()
    get(-4)
    get(-3)
    get(-2)
    get(-1)
    get(-0)
    len_()
    str_()
    get(4, raise_=True)
    get(5, raise_=True)
    get(999, raise_=True)
    str_()
    len_()
    get(-5, raise_=True)
    get(-6, raise_=True)
    get(-999, raise_=True)
    list_()
    len_()
    str_()

    del_(4, raise_=True)
    len_()
    str_()
    del_(999, raise_=True)
    str_()
    len_()
    del_(-5, raise_=True)
    list_()
    len_()
    str_()
    del_(-999, raise_=True)
    str_()
    len_()
    del_(3)
    len_()
    str_()
    add(1)
    str_()
    len_()
    del_(-1)
    list_()
    len_()
    str_()
    add(1)
    del_(-4)
    str_()
    len_()
    del_(1)
    del_(0)
    del_(0)
    len_()
    str_()
    del_(0, raise_=True)
    str_()
    len_()
    del_(1, raise_=True)
    del_(-1, raise_=True)
    list_()
    len_()
    str_()

    get(0, raise_=True)
    get(1, raise_=True)
    get(-1, raise_=True)
    list_()
    str_()
    len_()
    set_(0, 0, raise_=True)
    set_(1, 1, raise_=True)
    set_(-1, -1, raise_=True)
    list_()
    str_()
    len_()

    clear()
    str_()
    len_()
    add('flana')
    list_()
    len_()
    str_()
    clear()
    str_()
    len_()
    add('flana')
    add({'lorem': {1, 2, 3}, (1, 2): [8.5, False]})
    clear()
    list_()
    str_()
    len_()
    add(('5', 5))
    str_()
    len_()
    del_(0)
    str_()
    len_()
    clear()
    str_()
    len_()
    clear()
    len_()
    str_()
    for _ in range(3):
        add(5)
    list_()
    str_()
    len_()
    clear()
    clear()
    clear()
    str_()
    len_()

    insert(-1, 'a')
    list_()
    str_()
    len_()
    clear()
    len_()
    str_()
    insert(999, 'b')
    str_()
    len_()
    clear()
    insert(0, 'c')
    len_()
    str_()
    insert(0, linked_list)
    list_()
    str_()
    len_()
    insert(-1, 0j)
    len_()
    str_()
    insert(3, 'zZzZzZz')
    str_()
    len_()
    insert(-4, -4)
    insert(-6, '-6')
    insert(-999, 'False')
    list_()
    len_()
    str_()
    del_(0)
    insert(999, 'y')
    str_()
    len_()
    del_(1)
    insert(0, 'z')
    len_()
    str_()
    add(1)
    add(2)
    add(3)
    insert(2, 'bye')
    str_()
    len_()
    insert(len(linked_list), 'last')
    insert(len(linked_list) - 1, 'penultimate ')
    insert(len(linked_list) - 2, 'antepenultimate')
    list_()
    len_()
    str_()
    insert(4, None)
    str_()
    len_()
    insert(1, range(5))
    list_()
    len_()
    str_()

    set_(0, 0.0)
    list_()
    str_()
    len_()
    set_(1, '1.11')
    list_()
    len_()
    str_()
    set_(15, 15.15)
    len_()
    str_()
    set_(-0, '-0')
    len_()
    str_()
    set_(-1, -1j)
    len_()
    str_()
    set_(-16, -16 + 16j)
    len_()
    str_()
    set_(999, '999', raise_=True)
    list_()
    str_()
    len_()
    set_(-999, '999', raise_=True)
    len_()
    str_()
    del_(10)
    str_()
    len_()
    set_(15, -15, raise_=True)
    set_(-16, -16, raise_=True)
    len_()
    str_()
    clear()
    str_()
    len_()
    set_(0, '0', raise_=True)
    set_(1, '0', raise_=True)
    set_(999, '0', raise_=True)
    list_()
    len_()
    str_()
    set_(-0, '0', raise_=True)
    set_(-1, '0', raise_=True)
    set_(-999, '0', raise_=True)
    str_()
    len_()

    add(1)
    add(2.5)
    add('3')
    add(2)
    add((1, '2', 'c'))
    add([[], True, False])
    add(3)
    add(None)
    add(1)
    list_()
    len_()
    str_()
    remove(999, raise_=True)
    list_()
    str_()
    len_()
    remove(1)
    len_()
    str_()
    remove(2)
    str_()
    len_()
    remove(3)
    len_()
    str_()
    remove((1, '2', 'c'))
    remove(None)
    list_()
    str_()
    len_()
    remove(1)
    remove([[], True, False])
    remove(2.5)
    remove('3')
    len_()
    str_()
    for _ in range(5):
        add(1)
        remove(1)
    list_()
    str_()
    len_()
    for _ in range(5):
        add(1)
    len_()
    str_()
    for _ in range(5):
        remove(1)
    list_()
    str_()
    len_()


def _test_internal_use(method_name: str) -> tuple[str, str]:
    import __main__

    result_prefix = f'Reusabilidad en {method_name}: '
    if (
        not isinstance(getattr(__main__, 'LinkedList', None), type)
        or
        not inspect.isfunction(function := getattr(__main__.LinkedList, method_name, None))
    ):
        return result_prefix, '...'

    # noinspection PyUnboundLocalVariable
    method_lines = [line for line in inspect.getsource(function).splitlines() if not line.strip().startswith('#')]
    if len(method_lines) == 2 and 'self[' in method_lines[1] and '_' not in method_lines[1]:
        result_message = '✅'
    else:
        result_message = '❌'

    return result_prefix, result_message


def _test_performance(method_name: str, *args: Any, alias: str | None = None) -> tuple[str, str]:
    import __main__

    result_prefix = f'Rendimiento de {alias or method_name}: '
    if (
        not isinstance(getattr(__main__, 'LinkedList', None), type)
        or
        not inspect.isfunction(getattr(__main__.LinkedList, method_name, None))
    ):
        return result_prefix, '...'

    linked_list = __main__.LinkedList()
    method = getattr(linked_list, method_name)

    try:
        times = []
        for _ in range(100):
            t = time.perf_counter()
            method(*args)
            times.append(time.perf_counter() - t)
        expected_time = sum(times) / len(times)

        for _ in range(1000):
            linked_list.add(1)

        times = []
        for _ in range(100):
            t = time.perf_counter()
            method(*args)
            times.append(time.perf_counter() - t)
        actual_time = sum(times) / len(times)

        performance = actual_time / expected_time
        if performance <= 2:
            result_message = '✅'
        else:
            result_message = f'❌ Ha tardado {round(performance)} veces más que lo esperado'
    except Exception as e:
        result_message = f'❌ <- {e}'

    return result_prefix, result_message


def _test_type_hints() -> tuple[str, str]:
    import __main__

    result_prefix = 'Type hints:'
    if not isinstance(getattr(__main__, 'LinkedList', None), type):
        return result_prefix, '...'

    max_score = 13
    score, failed_methods = _assert_methods_type_hints(
        __main__.LinkedList,
        (
            (('__init__', {}, None),),
            (('__getitem__', {'_index': int}, Any),),
            (('__setitem__', {'_index': int, '_element': Any}, None),),
            (('__delitem__', {'_index': int}, None),),
            (
                ('__iter__', {}, Iterator),
                ('__iter__', {}, Iterator[Any]),
                ('__iter__', {}, Generator),
                ('__iter__', {}, Generator[Any, None, None])
            ),
            (('__len__', {}, int),),
            (('__str__', {}, str), ('__repr__', {}, str)),
            (('add', {'_element': Any}, None),),
            (('clear', {}, None),),
            (('get', {'_index': int}, Any),),
            (('insert', {'_index': int, '_element': Any}, None),),
            (('remove', {'_element': Any}, None),),
            (('set', {'_index': int, '_element': Any}, None),)
        )
    )
    ratio = score / max_score

    result_message_lines = [f"{'✅' if ratio == 1 else '❌'} {ratio:.0%}"]
    for failed_method in failed_methods:
        result_message_lines.append(f"{' ' * _TAB_SIZE}{failed_method}")
    return result_prefix, '\n'.join(result_message_lines)


def test() -> None:
    global _is_test_executed

    if _is_test_executed:
        return

    _is_test_executed = True

    for result_prefix, result_message in (
        _test_general(),
        _test_performance('__len__'),
        _test_performance('add', 1),
        _test_internal_use('get'),
        _test_internal_use('set'),
        _test_type_hints()
    ):
        print(f'{result_prefix:{_LEFT_MARGIN_SPACES}}{result_message}')


_is_test_executed = False
