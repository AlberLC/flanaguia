from __future__ import annotations

import __main__
import contextlib
import os
import webbrowser

import chess.engine
import uvicorn
from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

from resources import utils
from resources.backend.exceptions import CheckMateError

_DASHES = '-' * 70
_ERROR_BORDER = f'{_DASHES}\n{_DASHES}'
_ERROR_TEMPLATE = f'{_ERROR_BORDER}\n❌ {{}}\n{_ERROR_BORDER}\n'
_REQUIRED_COMPONENTS_LEFT_MARGIN = 4
_STOCKFISH_PATH = 'resources/stockfish/stockfish-windows-x86-64-avx2.exe'
_STOCKFISH_TIME_LIMIT = 1


class _Move(BaseModel):
    current_position: tuple[int, int]
    new_position: tuple[int, int]


def _get_board() -> tuple[str, list[list[tuple[str, str] | None]], int, list[tuple[int, int]], int | str, int | str]:
    # noinspection PyTypeChecker
    return _app.state.board.human_color.name.lower(), *_get_board_response()


def _get_board_response() -> tuple[
    list[list[tuple[str, str] | None]],
    int,
    list[tuple[int, int]],
    int | str,
    int | str
]:
    if hasattr(_app.state.board, 'get_score'):
        scores = _app.state.board.get_score(__main__.Color.WHITE), _app.state.board.get_score(__main__.Color.BLACK)
    else:
        scores = '', ''

    # noinspection PyTypeChecker,PyProtectedMember
    return utils.board_to_svg_board(_app.state.board._board), *utils.get_check_data(_app.state), *scores


def _get_human_moveset(row: int, column: int) -> list[tuple[int, int]]:
    return list(
        utils.iter_safe_moveset(
            _app.state.board,
            _app.state.board.get_king(_app.state.board.human_color),
            _app.state.board[row][column]
        )
    )


def _move_ai() -> tuple[
    list[list[tuple[str, str] | None]],
    int,
    list[tuple[int, int]],
    int | str,
    int | str,
    int,
    int,
    int,
    int
]:
    _, is_ai_checkmate, _, is_human_checkmate = utils.get_all_checks(_app.state.board)
    if is_ai_checkmate or is_human_checkmate:
        raise CheckMateError

    # noinspection PyProtectedMember
    chess_board = chess.Board(utils.board_to_fen(_app.state.board._board))
    chess_board.turn = not utils.color_to_chess_color(_app.state.board.human_color)
    with (
        chess.engine.SimpleEngine.popen_uci(_STOCKFISH_PATH) as engine,
        open(os.devnull, 'w') as null_file,
        contextlib.redirect_stderr(null_file)
    ):
        try:
            ai_move = engine.play(chess_board, chess.engine.Limit(time=_STOCKFISH_TIME_LIMIT)).move
        except chess.engine.EngineTerminatedError:
            _app.state.server.should_exit = True

    if not ai_move:
        _app.state.server.should_exit = True

    current_row, current_column = utils.chess_square_to_position(ai_move.from_square)
    new_row, new_column = utils.chess_square_to_position(ai_move.to_square)
    _app.state.board[current_row][current_column].move(_app.state.board, new_row, new_column)

    # noinspection PyTypeChecker
    return *_get_board_response(), current_row, current_column, new_row, new_column


def _move_human(
    current_position: tuple[int, int],
    new_position: tuple[int, int]
) -> tuple[
    list[list[tuple[str, str] | None]],
    int,
    list[tuple[int, int]],
    int | str,
    int | str,
    int,
    int,
    int,
    int
]:
    _, is_ai_checkmate, _, is_human_checkmate = utils.get_all_checks(_app.state.board)
    if is_ai_checkmate or is_human_checkmate:
        raise CheckMateError

    current_row = current_position[0]
    current_column = current_position[1]
    new_row = new_position[0]
    new_column = new_position[1]
    _app.state.board[current_row][current_column].move(_app.state.board, new_row, new_column)

    # noinspection PyTypeChecker
    return *_get_board_response(), current_row, current_column, new_row, new_column


_app = FastAPI()

_app.mount('/static', StaticFiles(directory='resources/backend/page'))


@_app.websocket("/ws")
async def _websocket_endpoint(websocket: WebSocket):
    await websocket.accept()
    try:
        while True:
            type_, data = await websocket.receive_json()
            match type_:
                case 'board':
                    return_data = _get_board()
                case 'get_human_moveset':
                    return_data = _get_human_moveset(*data)
                case 'move_ai':
                    return_data = _move_ai()
                case 'move_human':
                    return_data = _move_human(*data)
                case _:
                    continue

            await websocket.send_json((type_, *return_data))
    except WebSocketDisconnect:
        pass


async def run_server(
    pawn: __main__.Pawn | None = None,
    knight: __main__.Knight | None = None,
    bishop: __main__.Bishop | None = None,
    rook: __main__.Rook | None = None,
    queen: __main__.Queen | None = None,
    king: __main__.King | None = None,
    board: __main__.Board | None = None
) -> None:
    formated_required_messages = []
    for object_name in ('pawn', 'knight', 'bishop', 'rook', 'queen', 'king', 'board'):
        if not locals().get(object_name):
            formated_required_messages.append(f"Pass a '{object_name.title()}' class object to the 'test()' function")

    if hasattr(__main__, 'Color'):
        if not hasattr(__main__.Color, 'opposite'):
            formated_required_messages.append("'Color.opposite' property is not defined")
    else:
        formated_required_messages.append("'Color' enumeration is not defined")

    if hasattr(__main__, 'Piece'):
        for attribute_name in ('_color', 'row', 'column'):
            for piece in (pawn, knight, bishop, rook, queen, king):
                if not hasattr(piece, attribute_name):
                    formated_required_messages.append(f"'Piece.{attribute_name}' attribute is not defined")

        if not hasattr(__main__.Piece, 'color'):
            formated_required_messages.append("'Piece.color' property is not defined")

        for method_name in ('get_moveset', 'move'):
            if not hasattr(__main__.Piece, method_name):
                formated_required_messages.append(f"'Piece.{method_name}()' method is not defined")

        if hasattr(__main__, 'King'):
            if not hasattr(__main__.King, 'is_in_check'):
                formated_required_messages.append("'King.is_in_check()' method is not defined")
        else:
            formated_required_messages.append("'King' class is not defined")
    else:
        formated_required_messages.append("'Piece' class is not defined")

    if hasattr(__main__, 'Board'):
        for attribute_name in ('_board', 'human_color'):
            if not hasattr(board, attribute_name):
                formated_required_messages.append(f"'Piece.{attribute_name}' attribute is not defined")

        for method_name in ('__getitem__', 'iter_pieces', 'get_king', 'is_check', 'is_checkmate'):
            if not hasattr(__main__.Board, method_name):
                formated_required_messages.append(f"'Board.{method_name}()' method is not defined")
    else:
        formated_required_messages.append("'Board' class is not defined")

    if formated_required_messages:
        formated_required_messages = (
            f'{' ' * _REQUIRED_COMPONENTS_LEFT_MARGIN}- {message}' for message in formated_required_messages
        )
        print(
            _ERROR_TEMPLATE.format(
                f'Missing requirements to run the game:\n{'\n'.join(formated_required_messages)}'
            )
        )
        return

    if (
        len(list(board.iter_pieces(__main__.Color.WHITE, __main__.King))) != 1
        or
        len(list(board.iter_pieces(__main__.Color.BLACK, __main__.King))) != 1
    ):
        print(_ERROR_TEMPLATE.format('The board must contain exactly one white king and one black king'))
        return

    is_ai_check, is_ai_checkmate, is_human_check, is_human_checkmate = utils.get_all_checks(board)
    if (
        board.human_color is __main__.Color.WHITE and (is_ai_check or is_human_checkmate)
        or
        board.human_color is __main__.Color.BLACK and (is_human_check or is_ai_checkmate)
    ):
        print(_ERROR_TEMPLATE.format('The board cannot start with white in checkmate or black in check'))
        return

    config = uvicorn.Config(_app, log_level='critical')
    server = uvicorn.Server(config)
    socket = config.bind_socket()
    port = socket.getsockname()[1]

    _app.state.server = server
    _app.state.board = board

    webbrowser.open(f'http://localhost:{port}/static/chess.html')

    await server.serve([socket])
