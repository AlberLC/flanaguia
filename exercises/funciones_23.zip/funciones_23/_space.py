import random
import sys
import time
from contextlib import contextmanager
from dataclasses import dataclass
from enum import Enum, auto

_MAX_ASTEROIDS_ON_COLLISION_COURSE = 15
_NUMBER_OF_ASTEROIDS = 100
DANGEROUS_ASTEROID_ARRIVAL_TIME_MONTHS = 4 * 12
GTC_DELAY = 1
NEOWISE_DELAY = 2
REGION_SIZE = 5


class _AsteroidComposition(Enum):
    CARBONACEOUS = auto()
    COMETARY = auto()
    METALLIC = auto()
    RUBBLE_PILE = auto()
    STONY = auto()


def _generate_rounded_random_uniform(a: float, b: float) -> float:
    return round(random.uniform(a, b), 4)


_ABSORPTION_SPECTRA = {
    _AsteroidComposition.METALLIC: [(400, 0.2), (600, 0.15), (800, 0.1)],
    _AsteroidComposition.STONY: [(400, 0.6), (500, 0.7), (700, 0.5)],
    _AsteroidComposition.CARBONACEOUS: [(400, 0.8), (600, 0.75), (1000, 0.85), (1500, 0.9)],
    _AsteroidComposition.COMETARY: [(300, 0.5), (400, 0.7), (1000, 0.4)],
    _AsteroidComposition.RUBBLE_PILE: [(400, 0.7), (600, 0.65), (800, 0.5)]
}
_ALBEDO_VALUES = {
    _AsteroidComposition.METALLIC: _generate_rounded_random_uniform(0.3, 0.6),
    _AsteroidComposition.STONY: _generate_rounded_random_uniform(0.1, 0.3),
    _AsteroidComposition.CARBONACEOUS: _generate_rounded_random_uniform(0.05, 0.1),
    _AsteroidComposition.COMETARY: _generate_rounded_random_uniform(0.2, 0.4),
    _AsteroidComposition.RUBBLE_PILE: _generate_rounded_random_uniform(0.2, 0.4)
}
_TEMPERATURE_VALUES = {
    _AsteroidComposition.METALLIC: _generate_rounded_random_uniform(200, 350),
    _AsteroidComposition.STONY: _generate_rounded_random_uniform(250, 450),
    _AsteroidComposition.CARBONACEOUS: _generate_rounded_random_uniform(200, 400),
    _AsteroidComposition.COMETARY: _generate_rounded_random_uniform(150, 300),
    _AsteroidComposition.RUBBLE_PILE: _generate_rounded_random_uniform(200, 400)
}


@dataclass
class Asteroid:
    id: int
    x: float
    y: float
    distance_au: float
    diameter_km: float
    velocity_kms: float
    arrival_time_years: float
    composition: _AsteroidComposition
    albedo: float
    temperature: float
    absorption_spectrum: list[tuple[int, float]]
    on_collision_course: bool
    is_dangerous: bool


def _generate_asteroids(number: int = _NUMBER_OF_ASTEROIDS) -> dict[int, Asteroid]:
    asteroids_on_collision_course = 0

    id = random.randint(20_000, 70_000)

    velocity_kms = _generate_rounded_random_uniform(10, 30)
    arrival_time_years = DANGEROUS_ASTEROID_ARRIVAL_TIME_MONTHS
    distance_au = arrival_time_years * _km_per_s_to_au_per_year(velocity_kms)

    diameter_km = _generate_rounded_random_uniform(500, 2000)
    composition = random.choice([_AsteroidComposition.METALLIC, _AsteroidComposition.STONY])
    on_collision_course = True
    asteroids_on_collision_course += 1

    asteroids_ = {
        id: Asteroid(
            id=id,
            x=_generate_rounded_random_uniform(0, 1000),
            y=_generate_rounded_random_uniform(0, 1000),
            distance_au=distance_au,
            diameter_km=diameter_km,
            velocity_kms=velocity_kms,
            arrival_time_years=arrival_time_years,
            composition=composition,
            albedo=_ALBEDO_VALUES[composition],
            temperature=_TEMPERATURE_VALUES[composition],
            absorption_spectrum=_ABSORPTION_SPECTRA[composition],
            on_collision_course=on_collision_course,
            is_dangerous=True
        )
    }

    for _ in range(number - 1):
        velocity_kms = _generate_rounded_random_uniform(0.1, 50)
        arrival_time_years = random.randint(1, 1000)
        distance_au = arrival_time_years * _km_per_s_to_au_per_year(velocity_kms)

        diameter_km = _generate_rounded_random_uniform(0.1, 1000)
        composition = random.choice(
            (_AsteroidComposition.CARBONACEOUS, _AsteroidComposition.COMETARY, _AsteroidComposition.RUBBLE_PILE)
        )

        if asteroids_on_collision_course < _MAX_ASTEROIDS_ON_COLLISION_COURSE:
            on_collision_course = True
            asteroids_on_collision_course += 1
        else:
            on_collision_course = False

        asteroids_[id] = Asteroid(
            id=(id := id + 1),
            x=_generate_rounded_random_uniform(0, 1000),
            y=_generate_rounded_random_uniform(0, 1000),
            distance_au=distance_au,
            diameter_km=diameter_km,
            velocity_kms=velocity_kms,
            arrival_time_years=arrival_time_years,
            composition=composition,
            albedo=_ALBEDO_VALUES[composition],
            temperature=_TEMPERATURE_VALUES[composition],
            absorption_spectrum=_ABSORPTION_SPECTRA[composition],
            on_collision_course=on_collision_course,
            is_dangerous=False
        )

    return asteroids_


def _increment_one_month() -> None:
    global elapsed_months

    if not _is_time_enabled:
        return

    time.sleep(1)

    elapsed_months += 1

    if elapsed_months == 1:
        months_part = f'Ha pasado {elapsed_months} mes'
    else:
        months_part = f'Han pasado {elapsed_months} meses'

    if elapsed_months == 12:
        years_part = f'({elapsed_months / 12:.2f} año)'
    else:
        years_part = f'({elapsed_months / 12:.2f} años)'

    print(f'{months_part} {years_part}.')

    if elapsed_months == DANGEROUS_ASTEROID_ARRIVAL_TIME_MONTHS:
        print('💀 La Tierra ha sido destruida.')
        sys.exit()


def _km_per_s_to_au_per_year(velocity_kms: float) -> float:
    return velocity_kms * (365.25 * 24 * 3600) / 149597870.7


@contextmanager
def disable_time():
    global _is_time_enabled

    _is_time_enabled = False
    try:
        yield
    finally:
        _is_time_enabled = True


def increment_months(number_of_months: int) -> None:
    for _ in range(number_of_months):
        _increment_one_month()


_is_time_enabled = True
asteroids = _generate_asteroids()
elapsed_months = 0
