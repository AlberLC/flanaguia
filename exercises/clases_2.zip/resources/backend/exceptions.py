class CheckMateError(ValueError):
    def __init__(self):
        super().__init__('the board cannot be in checkmate')


class InitialCheckError(ValueError):
    def __init__(self):
        super().__init__('the board cannot start with white in checkmate or black in check')


class KingsNumberError(ValueError):
    def __init__(self):
        super().__init__('the board must contain exactly 1 white king and 1 black king')
