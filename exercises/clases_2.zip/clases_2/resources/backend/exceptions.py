class CheckMateError(ValueError):
    def __init__(self):
        super().__init__('the board cannot be in checkmate')
