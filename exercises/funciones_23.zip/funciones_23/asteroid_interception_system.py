import __main__
import inspect
import re
import sys
import time
from collections.abc import Iterator
from enum import Enum, auto

import _space
import gtc
import laboratory
import neowise


class InterceptionError(Exception):
    pass


class _LaunchState(Enum):
    AWAITING_TARGET = auto()
    TRAJECTORY_CALCULATED = auto()
    WEAPON_LOADED = auto()
    WEAPON_FIRED = auto()
    ASTEROID_DESTROYED = auto()
    WRONG_TARGET = auto()


def _check_solution() -> None:
    print('\nComprobaciones finales de la solución:')

    if len([function for function in vars(__main__).values() if inspect.isfunction(function)]) == 2:
        print('✅ Se han definido dos funciones como máximo en la solución.')
    else:
        print('❌ Se han definido más dos funciones en la solución.')

    if all(
        isinstance(function(), Iterator)
        for function in (laboratory.asteroid_position_data_getter_, laboratory.asteroid_radiation_data_getter_)
    ):
        print('✅ Las funciones definidas en la solución devuelven iteradores en vez de secuencias completas de datos de asteroides.')
    else:
        print('❌ Las funciones definidas en la solución devuelven secuencias completas en vez de iteradores de datos de asteroides.')

    for function in (
            neowise.scan_subregion,
            gtc.observe_asteroid,
            laboratory.add_asteroid_position_data_getter,
            laboratory.add_asteroid_radiation_data_getter,
            laboratory.calculate_diameter,
            laboratory.determine_asteroid_composition,
            calculate_trajectory,
            load_weapon,
            fire_weapon
    ):
        if len(_re_findall_without_comments(fr'{function.__name__}\(', inspect.getsource(__main__))) > 1:
            print(f'❌ {function.__module__}.{function.__name__} solo puede aparecer una vez en la solución.')
            break
    else:
        print('✅ Las funciones de los módulos solo aparecen una vez en la solución.')


def _re_findall_without_comments(pattern: str, text: str) -> list[str]:
    return re.findall(f'^(?!.*#).*{pattern}', text, re.MULTILINE)


def calculate_trajectory(id: int, x: float, y: float, distance_au: float, velocity_kms: float) -> None:
    global _id
    global _launch_state

    if _launch_state not in {_LaunchState.AWAITING_TARGET, _LaunchState.TRAJECTORY_CALCULATED}:
        raise InterceptionError('❌ Error: ya no se puede cambiar la trayectoria del sistema de intercepción.')

    time.sleep(0.5)
    print('Coordenadas recibidas...')
    time.sleep(1)
    print('Calculando trayectoria de interceptación...')
    time.sleep(2)
    _id = id
    _launch_state = _LaunchState.TRAJECTORY_CALCULATED
    print('Trayectoria optimizada.')


def fire_weapon() -> None:
    global _launch_state

    if _launch_state is not _LaunchState.WEAPON_LOADED:
        raise InterceptionError('❌ Error: arma no cargada.')

    time.sleep(2)
    print('Inicializando lanzamiento...')
    time.sleep(4)
    _launch_state = _LaunchState.WEAPON_FIRED
    print('Lanzamiento efectuado.')
    time.sleep(2)
    print('Esperando a periodo de evaluación...')
    time.sleep(4)
    print('Evaluando estado...')
    time.sleep(3)
    print('Trayectoria nominal. Todos los sistemas respondiendo con normalidad.')
    time.sleep(3)
    print('Esperando a entrar en rango...')
    time.sleep(1)
    _space.increment_months(int((_space.DANGEROUS_ASTEROID_ARRIVAL_TIME_MONTHS - _space.elapsed_months) / 8))
    time.sleep(1)
    print('Objetivo en rango. Desacoplando bombas...')
    time.sleep(2)
    print('Activando bombas...')
    time.sleep(2)
    print('Arma detonada con éxito.')
    time.sleep(1)

    if _id in _space.asteroids and _space.asteroids[_id].is_dangerous:
        _launch_state = _LaunchState.ASTEROID_DESTROYED
        print('✅ Asteroide destruido. La Tierra se ha salvado.')
        time.sleep(2)
        _check_solution()
        sys.exit()
    else:
        _launch_state = _LaunchState.WRONG_TARGET
        print('❌ Objetivo erróneo.')


def load_weapon() -> None:
    global _launch_state

    if _launch_state is _LaunchState.AWAITING_TARGET:
        raise InterceptionError('❌ Error: trayectoria de intercepción no calculada.')

    if _launch_state is _LaunchState.WEAPON_LOADED:
        raise InterceptionError('❌ Error: arma ya cargada.')

    if _launch_state is _LaunchState.WEAPON_FIRED:
        raise InterceptionError('❌ Error: arma lanzada.')

    time.sleep(1)
    print('Ensamblando bombas H...')
    time.sleep(3)
    print('Inicializando sistemas de vuelo...')
    time.sleep(2)
    print('Cargando bombas H...')
    time.sleep(2)
    _launch_state = _LaunchState.WEAPON_LOADED
    print('Sistemas cargados y bombas listas para lanzamiento.')


_launch_state = _LaunchState.AWAITING_TARGET
_id: int | None = None
