from __future__ import annotations

import __main__
import random
from collections.abc import Iterator

import chess
from fastapi.datastructures import State

BOARD_LENGTH = 8
# 'https://upload.wikimedia.org/wikipedia/commons/archive/d/d9/20110302085513%21Icon-round-Question_mark.svg'
DEFAULT_SVG = 'https://upload.wikimedia.org/wikipedia/commons/archive/a/af/20050613051527%21Question_mark.png'


def _is_in_checkmate(board: __main__.Board, king: __main__.Piece) -> bool:
    if not king.is_in_check(board):
        return False

    if any(iter_safe_moveset(board, king, king)):
        return False

    for ally in board.iter_pieces(king.color):
        if any(iter_safe_moveset(board, king, ally)):
            return False

    return True


def _piece_to_fen_character(piece: __main__.Piece) -> str | None:
    import __main__

    match piece:
        case __main__.Pawn():
            fen_character = 'p'
        case __main__.Knight():
            fen_character = 'n'
        case __main__.Bishop():
            fen_character = 'b'
        case __main__.Rook():
            fen_character = 'r'
        case __main__.Queen():
            fen_character = 'q'
        case __main__.King():
            fen_character = 'k'
        case _:
            return None

    return fen_character.upper() if piece.color is __main__.Color.WHITE else fen_character


def board_to_fen(board: list[list[__main__.Piece | None]]) -> str:
    fen_rows = []

    for row in board:
        empty_count = 0
        fen_row_characters = []

        for piece in row:
            fen_character = _piece_to_fen_character(piece)

            if fen_character:
                if empty_count > 0:
                    fen_row_characters.append(str(empty_count))
                    empty_count = 0
                fen_row_characters.append(fen_character)
            else:
                empty_count += 1

        if empty_count > 0:
            fen_row_characters.append(str(empty_count))

        fen_rows.append(''.join(fen_row_characters))

    return '/'.join(fen_rows)


def board_to_svg_board(board: list[list[__main__.Piece | None]]) -> list[list[tuple[str, str] | None]]:
    svg_board: list[list[tuple[str, str] | None]] = []

    for row in board:
        row = row.copy()
        for piece in row:
            if piece:
                row[piece.column] = (piece.color.name.lower(), getattr(piece, 'svg', DEFAULT_SVG))

        svg_board.append(row)

    return svg_board


def chess_square_to_position(chess_square: int) -> tuple[int, int]:
    row, column = divmod(chess_square, BOARD_LENGTH)
    row = BOARD_LENGTH - 1 - row
    return row, column


def color_to_chess_color(color: __main__.Color) -> chess.Color:
    import __main__

    return chess.WHITE if color is __main__.Color.WHITE else chess.BLACK


def create_random_board_list() -> list[list[__main__.Piece | None]]:
    import __main__

    board_list = [[None for _ in range(BOARD_LENGTH)] for _ in range(BOARD_LENGTH)]
    random_column_range = (0, BOARD_LENGTH - 1)

    for piece_class, amount in (
        (__main__.Pawn, 8),
        (__main__.Knight, 2),
        (__main__.Bishop, 2),
        (__main__.Rook, 2),
        (__main__.Queen, 1)
    ):
        for color in __main__.Color:
            if issubclass(piece_class, __main__.Pawn):
                if color is __main__.Color.WHITE:
                    random_row_range = (0, BOARD_LENGTH - 2)
                else:
                    random_row_range = (1, BOARD_LENGTH - 1)
            else:
                random_row_range = random_column_range

            for _ in range(amount):
                row = random.randint(*random_row_range)
                column = random.randint(*random_column_range)
                board_list[row][column] = piece_class(color, row, column)

    row = random.randint(*random_column_range)
    column = random.randint(*random_column_range)
    board_list[row][column] = __main__.King(__main__.Color.WHITE, row, column)

    while True:
        row = random.randint(*random_column_range)
        column = random.randint(*random_column_range)
        if not isinstance(board_list[row][column], __main__.King):
            break

    board_list[row][column] = __main__.King(__main__.Color.BLACK, row, column)

    return board_list


def get_all_checks(board: __main__.Board) -> tuple[bool, bool, bool, bool]:
    ai_color = board.human_color.opposite

    is_ai_check = board.is_check(ai_color)
    is_ai_checkmate = _is_in_checkmate(board, board.get_king(ai_color))

    # noinspection PyProtectedMember
    chess_board = chess.Board(board_to_fen(board._board))
    chess_board.turn = color_to_chess_color(board.human_color)
    is_human_check = chess_board.is_check()
    is_human_checkmate = _is_in_checkmate(board, board.get_king(board.human_color))

    return is_ai_check, is_ai_checkmate, is_human_check, is_human_checkmate


def get_check_data(state: State) -> tuple[int, list[tuple[int, int]]]:
    try:
        is_ai_check, is_ai_checkmate, is_human_check, is_human_checkmate = get_all_checks(state.board)
    except StopIteration:
        state.server.should_exit = True
        return 5, []

    if is_ai_checkmate:
        check_state = 4
        state.server.should_exit = True
    elif is_human_checkmate:
        check_state = 3
        state.server.should_exit = True
    elif is_ai_check:
        check_state = 2
    elif is_human_check:
        check_state = 1
    else:
        return 0, []

    check_positions = []

    if is_ai_check or is_ai_checkmate:
        ai_king = state.board.get_king(state.board.human_color.opposite)
        check_positions.append((ai_king.row, ai_king.column))

    if is_human_check or is_human_checkmate:
        human_king = state.board.get_king(state.board.human_color)
        check_positions.append((human_king.row, human_king.column))

    return check_state, check_positions


# noinspection PyProtectedMember
def iter_safe_moveset(board: __main__.Board, king: __main__.Piece, piece: __main__.Piece) -> Iterator[tuple[int, int]]:
    if king.color is board.human_color:
        def get_moveset() -> list[tuple[int, int]]:
            return piece.get_moveset(board)

        def is_in_check() -> bool:
            return chess_board.is_check()
    else:
        def get_moveset() -> list[tuple[int, int]]:
            return [
                chess_square_to_position(square)
                for square in chess_board.attacks(position_to_chess_square(piece.row, piece.column))
            ]

        def is_in_check() -> bool:
            return king.is_in_check(board)

    old_position = (piece.row, piece.column)
    has_moved = piece.has_moved

    chess_board = chess.Board(board_to_fen(board._board))
    chess_board.turn = color_to_chess_color(king.color)
    for new_position in get_moveset():
        target_piece = board[new_position[0]][new_position[1]]
        piece.move(board, new_position[0], new_position[1])

        chess_board = chess.Board(board_to_fen(board._board))
        chess_board.turn = color_to_chess_color(king.color)
        is_in_check_result = is_in_check()

        piece.move(board, old_position[0], old_position[1])
        piece.has_moved = has_moved
        board[new_position[0]][new_position[1]] = target_piece

        if not is_in_check_result:
            yield new_position


def position_to_chess_square(row: int, column: int) -> chess.Square:
    return (BOARD_LENGTH - 1 - row) * BOARD_LENGTH + column
