from collections.abc import Callable, Iterable
from typing import Any
from unittest import mock

import _space
import gtc
import neowise

asteroid_position_data_getter_: Callable[[], Iterable[dict[str, Any]]] | None = None
asteroid_radiation_data_getter_: Callable[[], Iterable[dict[str, Any]]] | None = None


def add_asteroid_position_data_getter(asteroid_position_data_getter: Callable[[], Iterable[dict[str, Any]]]) -> None:
    global asteroid_position_data_getter_

    asteroid_position_data_getter_ = asteroid_position_data_getter

    with (
        mock.patch('neowise.scan_subregion', wraps=neowise.scan_subregion) as mock_scan_subregion,
        _space.disable_time()
    ):
        actual_asteroids_data = set(
            frozenset(actual_asteroid_data.items()) for actual_asteroid_data in asteroid_position_data_getter_()
        )
        expected_asteroids_data = {
            frozenset(
                {
                    'id': asteroid.id,
                    'x': asteroid.x,
                    'y': asteroid.y,
                    'distance_au': asteroid.distance_au,
                    'velocity_kms': asteroid.velocity_kms
                }.items()
            )
            for asteroid in _space.asteroids.values()
            if asteroid.on_collision_course
        }

    assert actual_asteroids_data == expected_asteroids_data
    assert mock_scan_subregion.call_count == _space.REGION_SIZE ** 2

    print('Laboratory: ✅ position data')


def add_asteroid_radiation_data_getter(asteroid_radiation_data_getter: Callable[[], Iterable[dict[str, Any]]]) -> None:
    global asteroid_radiation_data_getter_

    asteroid_radiation_data_getter_ = asteroid_radiation_data_getter

    with (
        mock.patch('gtc.observe_asteroid', wraps=gtc.observe_asteroid) as mock_observe_asteroid,
        _space.disable_time()
    ):
        actual_asteroids_data = set()

        for actual_asteroid_data in asteroid_radiation_data_getter_():
            hasheable_actual_asteroid_data = {}

            for k, v in actual_asteroid_data.items():
                if isinstance(v, list):
                    hasheable_elements = []

                    for element in v:
                        if isinstance(element, list):
                            element = tuple(element)
                        hasheable_elements.append(element)

                    v = frozenset(hasheable_elements)

                hasheable_actual_asteroid_data[k] = v

            actual_asteroids_data.add(frozenset(hasheable_actual_asteroid_data.items()))

        expected_asteroids_data = {
            frozenset(
                {
                    'id': asteroid.id,
                    'x': asteroid.x,
                    'y': asteroid.y,
                    'distance_au': asteroid.distance_au,
                    'velocity_kms': asteroid.velocity_kms,
                    'albedo': asteroid.albedo,
                    'temperature': asteroid.temperature,
                    'absorption_spectrum': frozenset(asteroid.absorption_spectrum)
                }.items()
            )
            for asteroid in _space.asteroids.values()
            if asteroid.on_collision_course
        }

    assert actual_asteroids_data == expected_asteroids_data
    assert mock_observe_asteroid.call_count == len(expected_asteroids_data)

    print('Laboratory: ✅ radiation data')


def calculate_diameter(id: int, albedo: float) -> str:
    integer_part, decimal_part = str(_space.asteroids[id].diameter_km).split('.')
    return f'{int(integer_part):x}.{decimal_part}'


def determine_asteroid_composition(id: int, temperature: float, absorption_spectrum: list[tuple[int, float]]) -> str:
    return str(f'{_space.asteroids[id].composition.value:b}')
