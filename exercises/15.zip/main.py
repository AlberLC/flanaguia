from data import Gender
from tests import test


def find_name_by_id(elements: list[dict], id_: int) -> str | None:
    ...


def find_id_by_name(elements: list[dict], name: str) -> int | None:
    ...


def select_student(student: dict, keys: list[str]) -> dict:
    ...


def find_students_by_age(min_age: int, max_age: int) -> list[dict]:
    ...


def find_student_country(student_id: int) -> str | None:
    ...


def students_by_subject_and_gender_count(subject: str, gender: Gender) -> int:
    ...


def join(students_: list[dict]) -> list[dict]:
    ...


def function_1(subjects_: list[str]) -> list[dict]:
    ...


def function_2(subjects_: list[str]) -> list[dict]:
    ...


def function_3() -> list[str]:
    ...


def function_4(subjects_number: int) -> int | None:
    ...


def function_5(subject: str, countries_: list[str]) -> int:
    ...


def function_6() -> int:
    ...


def function_7() -> float:
    ...


def function_8() -> list[str]:
    ...


def function_9() -> None:
    ...


test()
