from __future__ import annotations

import inspect
import re
import types
import typing
import unittest.mock
from abc import ABCMeta
from collections.abc import Callable, Generator, Iterable, Iterator
from copy import copy, deepcopy
from enum import Enum
from typing import Any


class _Mock:
    pass


class _UniqueList(list):
    def __iadd__(self, other: Iterable) -> _UniqueList:
        for element in other:
            if element not in self:
                self.append(element)

        return self


def _assert_function_type_hints(
    class_: type,
    type_hint_checks: tuple[tuple[str, dict[str, type], type | types.UnionType | None], ...]
) -> tuple[int, list[str]]:
    score = 0
    failed_functions = []
    for method_name, parameter_hints, return_hint in type_hint_checks:
        method = getattr(class_, method_name)
        if isinstance(method, property):
            assert method.fget
            method = method.fget
        type_hints = typing.get_type_hints(method)
        try:
            assert 'return' in type_hints
            _assert_type_hint(return_hint, type_hints.pop('return'))
            _assert_parameter_type_hints(parameter_hints, type_hints)
        except (AssertionError, TypeError):
            failed_functions.append(f'{class_}.{method_name}')
            continue
        score += 1

    return score, failed_functions


def _assert_parameter_type_hints(expected_parameter_hints: dict[str, type], actual_type_hints: dict[str, type]) -> None:
    expected_parameter_hints_items = sorted(expected_parameter_hints.items())
    if '_' in expected_parameter_hints:
        actual_type_hints_items = sorted(actual_type_hints.items())
    else:
        actual_type_hints_items = sorted(
            (k, v) for k, v in actual_type_hints.items() if k in expected_parameter_hints
        )
    assert len(expected_parameter_hints_items) == len(actual_type_hints_items)

    for (expected_k, expected_v), (actual_k, actual_v) in zip(expected_parameter_hints_items, actual_type_hints_items):
        if not expected_k.startswith('_'):
            assert expected_k == actual_k
        _assert_type_hint(expected_v, actual_v)


def _assert_type_hint(expected: Any, actual: Any) -> None:
    if isinstance(expected, types.UnionType):
        assert expected == actual
        return

    if expected_origin := typing.get_origin(expected):
        actual_origin = typing.get_origin(actual)
        expected_args = typing.get_args(expected)
        if expected_args:
            if not (actual_args := [None if type_ is type(None) else type_ for type_ in typing.get_args(actual)]):
                raise AssertionError

            assert (
                expected_origin[*expected_args] == actual_origin[*actual_args]
                or
                (
                    expected_origin is Iterator
                    and
                    Generator[*expected_args, None, None] == actual_origin[*actual_args]
                )
            )
        else:
            assert (
                expected_origin is actual_origin
                or
                (
                    expected_origin is Iterator
                    and
                    Generator is actual_origin
                )
            )
    else:
        assert issubclass(type(expected) if expected is None else expected, actual)


# noinspection PyProtectedMember
def _assert_vehicle_str(vehicle: main.Vehicle) -> None:
    assert str(vehicle) == f'{type(vehicle).__name__}_{vehicle.plate}. Passengers: {vehicle._passengers}'


def _re_findall_without_comments(pattern: str, text: str) -> list[str]:
    return re.findall(f'^(?!.*#).*{pattern}', text, re.MULTILINE)


def _roman(number: int) -> str:
    roman = {
        1000: "m",
        900: "cm",
        500: "d",
        400: "cd",
        100: "c",
        90: "xc",
        50: "l",
        40: "xl",
        10: "x",
        9: "ix",
        5: "v",
        4: "iv",
        1: "i"
    }

    def roman_generator(number_: int) -> Iterator[str]:
        for r in roman:
            x, y = divmod(number_, r)
            yield roman[r] * x
            number_ -= (r * x)
            if number_ <= 0:
                break

    return ''.join([a for a in roman_generator(number)])


def _transform_chapter_format(function_name: str, roman=True) -> str:
    numbered_chapter = f"{'' * function_name.count('_')}{function_name.replace('_test_', '').replace('_', '.')}"
    if not roman:
        return numbered_chapter

    numbers = [int(number) for number in numbered_chapter.split('.')]
    parts = [f'{_roman(numbers[0]):>3}']
    for number in numbers[1:]:
        parts.append(f'.{chr(96 + number)}')

    return ''.join(parts)


# noinspection PyUnresolvedReferences
def _test_1() -> tuple[float, list[str]]:
    total_score = 0
    max_score = 42
    all_failed_functions = _UniqueList()

    try:
        from main import Person
    except ImportError:
        pass
    else:
        score, failed_functions = _assert_function_type_hints(
            Person,
            (
                ('__init__', {'name': str, 'age': int}, type(None)),
                ('__le__', {'_': Any}, bool),
                ('__lt__', {'_': Any}, bool),
                ('__repr__', {}, str)
            )
        )
        total_score += score
        all_failed_functions += failed_functions

    try:
        from main import WheelDrive, Person, Vehicle, Car, Train
    except ImportError:
        pass
    else:
        for VehicleClass in (Vehicle, Car, Train):
            score, failed_functions = _assert_function_type_hints(
                VehicleClass,
                (
                    ('__init__', {'max_passengers': int, 'plate': str}, None),
                    ('__add__', {'_': Any}, Vehicle),
                    ('__eq__', {'_': Any}, bool),
                    ('__iter__', {}, Iterator[Person]),
                    ('__len__', {}, int),
                    ('__str__', {}, str),
                    ('add_passenger', {'passenger': Person}, None),
                    ('first_passenger', {'condition': Callable[[Person], bool]}, Person | None),
                    ('empty', {}, set[Person]),
                    ('passengers', {}, set[Person]),
                    ('remove_passenger', {'passenger': Person}, None),
                    ('remove_passenger_by_name', {'name': str}, None),
                )
            )
            total_score += score
            all_failed_functions += failed_functions

        score, failed_functions = _assert_function_type_hints(
            Car,
            (
                (
                    '__init__',
                    {'doors': int, 'airbags': int, 'wheel_drive': WheelDrive, 'max_passengers': int, 'plate': str},
                    None
                ),
            )
        )
        total_score += score
        all_failed_functions += failed_functions

        score, failed_functions = _assert_function_type_hints(
            Train,
            (
                ('__init__', {'wagons': int, 'max_passengers': int, 'plate': str}, None),
            )
        )
        total_score += score
        all_failed_functions += failed_functions

    return total_score / max_score, all_failed_functions


def _test_2_1(person: main.Person) -> None:
    if not hasattr(person, 'name'):
        raise NotImplementedError

    assert isinstance(person.name, str)
    if 'age' in inspect.signature(person.__init__).parameters:
        def constructor(name_: str) -> main.Person:
            # noinspection PyArgumentList
            return type(person)(name_, 10)
    else:
        def constructor(name_: str) -> main.Person:
            # noinspection PyArgumentList
            return type(person)(name_)

    assert constructor('juan').name == 'Juan'
    assert constructor('   juan lópez').name == 'Juan lópez'
    assert constructor('juan ').name == 'Juan'
    assert constructor(' JUAN ').name == 'Juan'
    assert constructor(' ju An ').name == 'Ju an'


def _test_2_2(person: main.Person) -> None:
    if not hasattr(person, 'age'):
        raise NotImplementedError

    assert isinstance(person.age, int)
    if 'name' in inspect.signature(person.__init__).parameters:
        def constructor(age_: int) -> main.Person:
            # noinspection PyArgumentList
            return type(person)('_', age_)
    else:
        def constructor(age_: int) -> main.Person:
            # noinspection PyArgumentList
            return type(person)(age_)

    for age in (0, -1, -2, -5, -10, -999, float('-inf')):
        try:
            constructor(age)
        except ValueError:
            pass
        else:
            raise AssertionError


def _test_2_3(person: main.Person) -> None:
    method_names = ('__lt__', '__le__', '__gt__', '__ge__')
    if not any(inspect.ismethod(getattr(person, method_name)) for method_name in method_names):
        raise NotImplementedError

    try:
        _test_2_2(person)
    except (AssertionError, NotImplementedError):
        raise ReferenceError

    person_1 = person
    person_1.age = 10
    person_2 = copy(person)
    person_2.age = 25
    person_3 = copy(person)
    person_3.age = 25
    person_4 = copy(person)
    person_4.age = 30
    try:
        assert person_1 < person_2 <= person_3 < person_4
        assert person_4 > person_3 >= person_2 > person_1
        assert sorted((person_3, person_2, person_1, person_4)) in (
            [person_1, person_2, person_3, person_4],
            [person_1, person_3, person_2, person_4]
        )
    except TypeError as e:
        raise AssertionError(e if 'missing' in str(e) else '')

    _mock.age = 25
    with unittest.mock.patch('builtins.super') as super_mock:
        for method_name in method_names:
            assert getattr(person_1, method_name)(_mock) is NotImplemented
            assert getattr(person_1, method_name)(1) is NotImplemented
            assert getattr(person_1, method_name)('_') is NotImplemented
    assert super_mock.call_count == 6


def _test_2_4(person: main.Person) -> None:
    try:
        if repr(person) == object.__repr__(person):
            raise NotImplementedError
    except TypeError as e:
        if '__repr__ returned non-string' in str(e):
            raise AssertionError(e)
        else:
            raise

    try:
        _test_2_1(person)
        _test_2_2(person)
    except (AssertionError, NotImplementedError):
        raise ReferenceError

    assert str(type(person)('Juan', 10)) == 'Juan (10)'
    assert str(type(person)('Ana', 35)) == 'Ana (35)'
    assert str(type(person)('Elena lara', 28)) == 'Elena lara (28)'
    assert str(type(person)('María josé romero', 108)) == 'María josé romero (108)'

    assert str([type(person)('Juan', 10)]) == '[Juan (10)]'
    assert str([type(person)('Ana', 35), type(person)('Elena lara', 28)]) == '[Ana (35), Elena lara (28)]'
    assert str({type(person)('María josé romero', 108), type(person)('Elena lara', 28)}) in {
        '{María josé romero (108), Elena lara (28)}',
        '{Elena lara (28), María josé romero (108)}'
    }


# noinspection PyUnresolvedReferences
def _test_3_1() -> None:
    import main

    has_classes = [hasattr(main, class_name) for class_name in ('Car', 'Train', 'Vehicle')]
    if not any(has_classes):
        raise NotImplementedError
    elif not all(has_classes):
        raise AssertionError

    assert isinstance(main.Vehicle, ABCMeta)
    assert issubclass(main.Car, main.Vehicle)
    assert issubclass(main.Train, main.Vehicle)
    assert main.Vehicle.__abstractmethods__
    assert not main.Car.__abstractmethods__
    assert not main.Train.__abstractmethods__


def _test_3_2_1(car: main.Car, train: main.Train) -> None:
    if not any(hasattr(vehicle, 'max_passengers') for vehicle in (car, train)):
        raise NotImplementedError

    for vehicle in (car, train):
        assert isinstance(getattr(vehicle, 'max_passengers', None), int)


def _test_3_2_2(person: main.Person, car: main.Car, train: main.Train) -> None:
    if not any(hasattr(vehicle, 'plate') for vehicle in (car, train)):
        raise NotImplementedError

    try:
        _test_3_2_1(car, train)
    except (AssertionError, NotImplementedError):
        raise ReferenceError

    try:
        from main import Vehicle
    except ImportError:
        raise AssertionError

    for vehicle in (car, train):
        assert isinstance(getattr(vehicle, 'plate', None), str)
        assert inspect.signature(vehicle.__init__).parameters['plate'].default is None
        vehicle_vars = {k: v for k, v in vars(vehicle).items() if k not in {'plate', '_passengers'}}
        for _ in range(1000):
            new_plate = getattr(type(vehicle)(**vehicle_vars), 'plate', None)
            assert isinstance(new_plate, str)
            assert len(new_plate) == 4
            assert 0 <= int(new_plate) <= 9999

    default_args = []
    for class_ in (type(person), Vehicle, type(car), type(train)):
        for _, member in inspect.getmembers(class_):
            if inspect.isfunction(member):
                pass
            elif isinstance(member, property):
                member = member.fget
                if not member:
                    continue
            else:
                continue

            default_args += [k for k, v in inspect.signature(member).parameters.items() if v.default is not v.empty]

    assert default_args == ['plate'] * 3


# noinspection PyProtectedMember
def _test_3_2_3(person: main.Person, car: main.Car, train: main.Train) -> None:
    if not any(hasattr(vehicle, '_passengers') for vehicle in (car, train)):
        raise NotImplementedError

    try:
        _test_3_2_1(car, train)
    except (AssertionError, NotImplementedError):
        raise ReferenceError

    for vehicle in (car, train):
        assert isinstance(getattr(vehicle, '_passengers', None), set)
        vehicle._passengers.add(person)
        vehicle = type(vehicle)(**{k: v for k, v in vars(vehicle).items() if k != '_passengers'})
        assert not vehicle._passengers


def _test_3_2_4(person: main.Person, car: main.Car, train: main.Train) -> None:
    import main

    if not any(hasattr(vehicle, '_passengers') for vehicle in (car, train)):
        raise NotImplementedError

    try:
        _test_3_2_3(person, car, train)
    except (AssertionError, NotImplementedError):
        raise ReferenceError

    assert not _re_findall_without_comments(r'(?<!self)\._passengers', inspect.getsource(main))


def _test_3_3_1(car: main.Car) -> None:
    if not hasattr(car, 'doors'):
        raise NotImplementedError

    assert isinstance(car.doors, int)


def _test_3_3_2(car: main.Car) -> None:
    if not hasattr(car, 'airbags'):
        raise NotImplementedError

    assert isinstance(car.airbags, int)


def _test_3_3_3(car: main.Car) -> None:
    if not hasattr(car, 'wheel_drive'):
        raise NotImplementedError

    assert isinstance(car.wheel_drive, Enum) and type(car.wheel_drive).__name__ == 'WheelDrive'
    assert {member.name for member in type(car.wheel_drive)} == {'FRONT', 'REAR'}


def _test_3_4(train: main.Train) -> None:
    if not hasattr(train, 'wagons'):
        raise NotImplementedError

    assert isinstance(train.wagons, int)


# noinspection PyProtectedMember
def _test_3_5(person: main.Person, car: main.Car, train: main.Train) -> None:
    for vehicle in (car, train):
        properties = inspect.getmembers(type(vehicle), lambda o: isinstance(o, property))
        if hasattr(vehicle, 'passengers') or properties and properties[0][0] == 'passengers':
            break
    else:
        raise NotImplementedError

    try:
        _test_3_2_3(person, car, train)
    except (AssertionError, NotImplementedError):
        raise ReferenceError

    for vehicle in (car, train):
        properties = inspect.getmembers(type(vehicle), lambda o: isinstance(o, property))
        assert properties
        property_ = properties[0][1]
        assert properties[0][0] == 'passengers' and property_.fget and not property_.fset and not property_.fdel
        vehicle.passengers.clear()
        assert vehicle.passengers == set()
        vehicle._passengers.add(person)
        assert vehicle.passengers == {person}


def _test_3_6(car: main.Car, train: main.Train) -> None:
    if not any(inspect.ismethod(vehicle.__eq__) for vehicle in (car, train)):
        raise NotImplementedError

    for vehicle in (car, train):
        vehicle_2 = deepcopy(vehicle)
        vehicle.plate = '1234'
        vehicle_2.plate = '1234'
        assert vehicle == vehicle_2
        vehicle.plate = '1230'
        assert vehicle != vehicle_2

        _mock.plate = '1234'
        assert vehicle != _mock
        _mock.plate = '1230'
        assert vehicle != _mock


# noinspection PyProtectedMember
def _test_3_7(person: main.Person, car: main.Car, train: main.Train) -> None:
    if not any(hasattr(vehicle, '__len__') for vehicle in (car, train)):
        raise NotImplementedError

    try:
        _test_3_2_3(person, car, train)
    except (AssertionError, NotImplementedError):
        raise ReferenceError

    for vehicle in (car, train):
        vehicle._passengers.clear()
        assert len(vehicle) == 0
        vehicle._passengers.add(person)
        assert len(vehicle) == 1
        vehicle._passengers.add(copy(person))
        assert len(vehicle) == 2
        vehicle._passengers.add(copy(person))
        assert len(vehicle) == 3


# noinspection PyProtectedMember
def _test_3_8(person: main.Person, car: main.Car, train: main.Train) -> None:
    if not any(isinstance(vehicle, Iterable) for vehicle in (car, train)):
        raise NotImplementedError

    try:
        _test_3_2_3(person, car, train)
    except (AssertionError, NotImplementedError):
        raise ReferenceError

    for vehicle in (car, train):
        vehicle._passengers.clear()
        passengers = set()
        assert isinstance(iter(vehicle), Iterator)
        assert set(vehicle) == passengers
        vehicle._passengers.add(person)
        passengers.add(person)
        assert set(vehicle) == passengers
        person = copy(person)
        vehicle._passengers.add(person)
        passengers.add(person)
        assert set(vehicle) == passengers
        person = copy(person)
        vehicle._passengers.add(person)
        passengers.add(person)
        assert set(vehicle) == passengers


# noinspection PyProtectedMember
def _test_3_9(person: main.Person, car: main.Car, train: main.Train) -> None:
    try:
        if all(str(vehicle) == object.__repr__(vehicle) for vehicle in (car, train)):
            raise NotImplementedError
    except TypeError as e:
        if '__str__ returned non-string' in str(e):
            raise AssertionError(e)
        else:
            raise

    try:
        _test_2_1(person)
        _test_2_2(person)
        _test_3_2_2(person, car, train)
        _test_3_2_3(person, car, train)
    except (AssertionError, NotImplementedError):
        raise ReferenceError

    passengers = (type(person)('Juan', 10), type(person)('Ana', 20), type(person)('Elena', 35))
    for vehicle in (car, train):
        vehicle._passengers.clear()
        _assert_vehicle_str(vehicle)
        for passenger in passengers:
            vehicle._passengers.add(passenger)
            _assert_vehicle_str(vehicle)


# noinspection PyProtectedMember
def _test_3_10(person: main.Person, car: main.Car, train: main.Train) -> None:
    if not any(hasattr(vehicle, 'add_passenger') for vehicle in (car, train)):
        raise NotImplementedError

    try:
        _test_3_2_1(car, train)
        _test_3_2_3(person, car, train)
    except (AssertionError, NotImplementedError):
        raise ReferenceError

    for vehicle in (car, train):
        assert inspect.ismethod(getattr(vehicle, 'add_passenger', None))
        vehicle._passengers.clear()
        vehicle.max_passengers = 0
        try:
            vehicle.add_passenger(person)
        except ValueError as e:
            assert str(e) == 'Full vehicle'
        else:
            raise AssertionError
        vehicle.max_passengers = 1
        try:
            vehicle.add_passenger(person)
        except ValueError:
            raise AssertionError
        try:
            vehicle.add_passenger(person)
        except ValueError as e:
            assert str(e) == 'Full vehicle'
        else:
            raise AssertionError


def _test_3_11(person: main.Person, car: main.Car, train: main.Train) -> None:
    if not any(hasattr(vehicle, 'first_passenger') for vehicle in (car, train)):
        raise NotImplementedError

    try:
        _test_2_1(person)
        _test_2_2(person)
        _test_3_2_3(person, car, train)
    except (AssertionError, NotImplementedError):
        raise ReferenceError

    person_1 = type(person)('Juan', 10)
    person_2 = type(person)('Ana', 20)
    person_3 = type(person)('Elena', 35)
    for vehicle in (car, train):
        assert inspect.ismethod(getattr(vehicle, 'first_passenger', None))
        vehicle._passengers = {person_1, person_2, person_3}
        assert vehicle.first_passenger(lambda person_: person_.name == 'Juan') == person_1
        assert vehicle.first_passenger(lambda person_: person_.age == 10) == person_1
        assert vehicle.first_passenger(lambda person_: person_.name == 'Ana') == person_2
        assert vehicle.first_passenger(lambda person_: person_.age == 20) == person_2
        assert vehicle.first_passenger(lambda person_: person_.name == 'Elena') == person_3
        assert vehicle.first_passenger(lambda person_: person_.age == 35) == person_3
        assert vehicle.first_passenger(lambda person_: person_.age == 999) is None


# noinspection PyProtectedMember
def _test_3_12(person: main.Person, car: main.Car, train: main.Train) -> None:
    if not any(hasattr(vehicle, 'empty') for vehicle in (car, train)):
        raise NotImplementedError

    try:
        _test_3_2_3(person, car, train)
    except (AssertionError, NotImplementedError):
        raise ReferenceError

    person_1 = person
    person_2 = copy(person)
    person_3 = copy(person)
    for vehicle in (car, train):
        assert inspect.ismethod(getattr(vehicle, 'empty', None))

        passengers = {person_1}
        vehicle._passengers = passengers.copy()
        assert vehicle.empty() == passengers
        assert not vehicle._passengers

        passengers = {person_1, person_2}
        vehicle._passengers = passengers.copy()
        assert vehicle.empty() == passengers
        assert not vehicle._passengers

        passengers = {person_1, person_2, person_3}
        vehicle._passengers = passengers.copy()
        assert vehicle.empty() == passengers
        assert not vehicle._passengers


# noinspection PyProtectedMember
def _test_3_13(person: main.Person, car: main.Car, train: main.Train) -> None:
    if not any(hasattr(vehicle, 'remove_passenger') for vehicle in (car, train)):
        raise NotImplementedError

    try:
        _test_3_2_3(person, car, train)
    except (AssertionError, NotImplementedError):
        raise ReferenceError

    person_1 = person
    person_2 = copy(person)
    person_3 = copy(person)
    for vehicle in (car, train):
        assert inspect.ismethod(getattr(vehicle, 'remove_passenger', None))

        passengers = {person_1}
        vehicle._passengers = passengers.copy()
        vehicle.remove_passenger(person_2)
        assert vehicle._passengers == passengers
        vehicle.remove_passenger(person_1)
        assert vehicle._passengers == set()

        passengers = {person_1, person_2}
        vehicle._passengers = passengers.copy()
        vehicle.remove_passenger(person_3)
        assert vehicle._passengers == passengers
        vehicle.remove_passenger(person_1)
        assert vehicle._passengers == {person_2}
        vehicle.remove_passenger(person_2)
        assert vehicle._passengers == set()


# noinspection PyProtectedMember
def _test_3_14(person: main.Person, car: main.Car, train: main.Train) -> None:
    if not any(hasattr(vehicle, 'remove_passenger_by_name') for vehicle in (car, train)):
        raise NotImplementedError

    try:
        _test_2_1(person)
        _test_3_2_3(person, car, train)
    except (AssertionError, NotImplementedError):
        raise ReferenceError

    person_1 = copy(person)
    person_1.name = 'Juan'
    person_2 = copy(person)
    person_2.name = 'Ana'
    person_3 = copy(person)
    person_3.name = 'Elena'
    for vehicle in (car, train):
        assert inspect.ismethod(getattr(vehicle, 'remove_passenger_by_name', None))

        passengers = {person_1}
        vehicle._passengers = passengers.copy()
        vehicle.remove_passenger_by_name(person_2.name)
        assert vehicle._passengers == passengers
        vehicle.remove_passenger_by_name(person_1.name)
        assert vehicle._passengers == set()

        passengers = {person_1, person_2}
        vehicle._passengers = passengers.copy()
        vehicle.remove_passenger_by_name(person_3.name)
        assert vehicle._passengers == passengers
        vehicle.remove_passenger_by_name(person_2.name)
        assert vehicle._passengers == {person_1}
        vehicle.remove_passenger_by_name(person_1.name)
        assert vehicle._passengers == set()


# noinspection PyProtectedMember
def _test_3_15(person: main.Person, car: main.Car, train: main.Train) -> None:
    if not any(inspect.ismethod(vehicle.__add__) for vehicle in (car, train)):
        raise NotImplementedError

    try:
        _test_3_2_1(car, train)
        _test_3_2_3(person, car, train)
    except (AssertionError, NotImplementedError):
        raise ReferenceError

    person_1 = person
    person_2 = copy(person)
    person_3 = copy(person)
    person_4 = copy(person)

    car.max_passengers = 0
    car._passengers = {person_1}
    train._passengers = {person_2}
    try:
        car + train
    except ValueError:
        pass
    else:
        raise AssertionError

    train.max_passengers = 1
    car._passengers = {person_1}
    train._passengers = {person_2}
    try:
        train + car
    except ValueError:
        pass
    else:
        raise AssertionError

    car._passengers = set()
    train._passengers = set()
    passengers = car._passengers | train._passengers
    new_car = car + train
    assert car._passengers == set()
    assert train._passengers == set()
    assert type(car) is type(new_car)
    assert new_car._passengers == passengers
    new_train = train + car
    assert type(train) is type(new_train)
    assert new_train._passengers == passengers

    car.max_passengers = 2
    train.max_passengers = 2
    car._passengers = {person_1}
    train._passengers = {person_2}
    passengers = car._passengers | train._passengers
    new_car = car + train
    assert car._passengers == set()
    assert train._passengers == set()
    assert type(car) is type(new_car)
    assert new_car._passengers == passengers
    car._passengers = {person_1}
    train._passengers = {person_2}
    new_train = train + car
    assert type(train) is type(new_train)
    assert new_train._passengers == passengers

    car.max_passengers = 9
    train.max_passengers = 9
    car._passengers = {person_1, person_2}
    train._passengers = {person_2, person_3, person_4}
    passengers = car._passengers | train._passengers
    new_car = car + train
    assert car._passengers == set()
    assert train._passengers == set()
    assert type(car) is type(new_car)
    assert new_car._passengers == passengers
    car._passengers = {person_1, person_2}
    train._passengers = {person_2, person_3, person_4}
    new_train = train + car
    assert type(train) is type(new_train)
    assert new_train._passengers == passengers


def test(person: main.Person = None, car: main.Car = None, train: main.Train = None, roman=True) -> None:
    global _is_test_executed

    import main

    if _is_test_executed:
        return

    _is_test_executed = True

    for function_name in globals().copy():
        if function_name.startswith('_test_'):
            function = globals()[function_name]
            args = []
            result_prefix = f"{_transform_chapter_format(function_name, roman):<{'8' if roman else '6'}}"

            try:
                if 'person' in inspect.signature(function).parameters:
                    if not hasattr(main, 'Person') or not isinstance(person, main.Person):
                        raise NotImplementedError
                    args.append(copy(person))

                if 'car' in inspect.signature(function).parameters:
                    if not hasattr(main, 'Car') or not isinstance(car, main.Car):
                        raise NotImplementedError
                    args.append(copy(car))

                if 'train' in inspect.signature(function).parameters:
                    if not hasattr(main, 'Train') or not isinstance(train, main.Train):
                        raise NotImplementedError
                    args.append(copy(train))

                result = function(*args)
            except NotImplementedError:
                print(f'{result_prefix}...')
            except ReferenceError as e:
                cause_function_name = e.__context__.__traceback__.tb_next.tb_frame.f_code.co_name
                failed_required_chapter = f' <- {_transform_chapter_format(cause_function_name, roman)}'
                print(f'{result_prefix}❌{failed_required_chapter}')
            except AssertionError as e:
                print(f"{result_prefix}❌{f' {e}' if str(e) else ''}")
            except Exception as e:
                if e.__traceback__.tb_next.tb_next and (f_code := e.__traceback__.tb_next.tb_next.tb_frame.f_code).co_filename.endswith('main.py'):
                    message = f'{e} ➡️ in {f_code.co_qualname}, line {f_code.co_firstlineno}'
                else:
                    message = str(e)
                print(f"{result_prefix}❌{f' ' if str(e) else ''}{message}")
            else:
                if function_name == '_test_1':
                    ratio, _ = result
                    print(f"{result_prefix}{'✅ ' if ratio == 1 else ''}{ratio:.0%}")
                else:
                    print(f'{result_prefix}✅')


def test_type_hints() -> None:
    global _is_test_type_hints_executed

    if _is_test_type_hints_executed:
        return

    _is_test_type_hints_executed = True

    ratio, failed_functions = _test_1()
    print()
    print(f"Type hints: {'✅ ' if ratio == 1 else ''}{ratio:.0%}")

    if failed_functions:
        print()
        print('Failed:')
        print('-------')
        for failed_function in failed_functions:
            print(failed_function)

    print()


_mock = _Mock()
_is_test_executed = False
_is_test_type_hints_executed = False

import main
