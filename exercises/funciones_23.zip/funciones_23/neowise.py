import base64
import random

import _space

_DANGEROUS_ASTEROID_MAX_INDEX = 2
REGION_SIZE = _space.REGION_SIZE


def _generate_regions(regions_size: int = REGION_SIZE) -> list[list[list[_space.Asteroid]]]:
    max_index = regions_size - 1
    regions = [[[] for _ in range(regions_size)] for _ in range(regions_size)]
    asteroids = tuple(_space.asteroids.values())

    row = random.randint(0, _DANGEROUS_ASTEROID_MAX_INDEX)
    column = random.randint(0, max_index)
    regions[row][column].append(asteroids[0])

    for asteroid in asteroids[1:]:
        row = random.randint(0, max_index)
        column = random.randint(0, max_index)
        regions[row][column].insert(random.randint(0, len(regions[row][column])), asteroid)

    return regions


def scan_subregion(region: tuple[int, int]) -> bytes:
    _space.increment_months(_space.NEOWISE_DELAY)

    asteroids_data_parts = []
    for asteroid in _regions[region[0]][region[1]]:
        asteroid_data = (
            asteroid.id,
            asteroid.x,
            asteroid.y,
            asteroid.distance_au,
            asteroid.velocity_kms,
            asteroid.on_collision_course
        )
        asteroids_data_parts.append(f'#{';'.join(str(value) for value in asteroid_data)}&')

    return base64.b64encode(''.join(asteroids_data_parts).encode())


_regions = _generate_regions()
