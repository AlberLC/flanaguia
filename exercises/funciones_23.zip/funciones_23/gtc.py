import json

import _space


def observe_asteroid(id: int, x: float, y: float) -> str:
    _space.increment_months(_space.GTC_DELAY)

    asteroid = _space.asteroids[id]
    return json.dumps(
        {
            'id': id,
            'albedo': asteroid.albedo,
            'temperature': asteroid.temperature,
            'absorption_spectrum': asteroid.absorption_spectrum
        }
    )
