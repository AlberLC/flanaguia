import inspect
import time
import types
import typing
from collections import deque
from collections.abc import Callable, Iterable, Iterator
from typing import Any, Self

_CALLS_LENGTH = 7
_LEFT_MARGIN_SPACES = 24
_TAB_SIZE = 4


class _UniqueList(list):
    def __iadd__(self, other: Iterable) -> Self:
        for element in other:
            if element not in self:
                self.append(element)

        return self


def _assert_methods_type_hints(
    vehicle_class: type,
    type_hint_checks: tuple[tuple[tuple[str, dict[str, Any], Any], ...], ...]
) -> tuple[int, list[str]]:
    score = 0
    failed_methods = _UniqueList()
    if not type_hint_checks:
        return score, failed_methods

    for type_hint_check in type_hint_checks:
        is_implemented = False
        failed_method = None
        for method_name, parameter_hints, return_hint in type_hint_check:
            method = getattr(vehicle_class, method_name, None)
            try:
                if isinstance(method, property):
                    assert method.fget
                    method = method.fget
                elif not inspect.isfunction(method):
                    continue

                is_implemented = True
                type_hints = typing.get_type_hints(method)
                assert 'return' in type_hints
                assert _compare_types(return_hint, type_hints.pop('return'))
                _assert_parameters_type_hints(parameter_hints, type_hints)
            except AssertionError:
                if not failed_method:
                    failed_method = str(method.__qualname__)
            else:
                break

        if not is_implemented or not failed_method:
            score += 1
        else:
            failed_methods.append(failed_method)

    return score, failed_methods


def _assert_parameters_type_hints(
    expected_parameter_hints: dict[str, type],
    actual_type_hints: dict[str, type]
) -> None:
    if any(k.startswith('_') for k in expected_parameter_hints):
        matches = 0
        actual_types = list(actual_type_hints.values())
        for expected_type in expected_parameter_hints.values():
            for actual_type in actual_types:
                if _compare_types(expected_type, actual_type):
                    matches += 1
                    actual_types.remove(actual_type)
                    break
            else:
                break
        assert matches == len(expected_parameter_hints) and not actual_types
    else:
        expected_parameters_hints_items = sorted(expected_parameter_hints.items())
        actual_type_hints_items = sorted(
            (k, v) for k, v in actual_type_hints.items() if k in expected_parameter_hints
        )
        assert len(expected_parameters_hints_items) == len(actual_type_hints_items)

        for (expected_k, expected_v), (actual_k, actual_v) in zip(
            expected_parameters_hints_items,
            actual_type_hints_items
        ):
            assert expected_k == actual_k
            assert _compare_types(expected_v, actual_v)


def _compare_types(expected: Any, actual: Any) -> bool:
    expected_origin = _get_type_origin(expected)
    actual_origin = _get_type_origin(actual)
    expected_args = _get_type_args(expected)
    actual_args = _get_type_args(actual)

    return (
        expected_origin is actual_origin
        and
        (
            not expected_args and expected_args != [Any]
            or
            expected_origin[*expected_args] == actual_origin[*actual_args]
        )
    )


def _get_type_args(type_: Any) -> list:
    return [None if arg is type(None) else arg for arg in typing.get_args(type_)]


def _get_type_origin(type_: Any) -> Any:
    if origin := typing.get_origin(type_):
        if origin is types.UnionType:
            return typing.Union

        return origin

    return None if type_ is type(None) else type_


def _linked_list_str(elements: list) -> str:
    return f'<{str(elements)[1:-1]}>'


def _test_general() -> tuple[str, str]:
    import main

    result_prefix = 'Test general: '
    if not isinstance(getattr(main, 'LinkedList', None), type):
        return result_prefix, '...'

    last_calls = deque(maxlen=_CALLS_LENGTH)
    try:
        _test_general_(main.LinkedList, last_calls)
    except AssertionError:
        last_calls = list(last_calls)
        last_calls = ['', *(f'⬇️ {call}' for call in last_calls[:-1]), f'❌ {last_calls[-1]}']
        if len(last_calls) > _CALLS_LENGTH:
            last_calls.insert(1, '⬇️ ...')
        result_message = '\n'.join(f"{' ' * _TAB_SIZE}{call}" for call in last_calls)
    else:
        result_message = '✅'

    return result_prefix, result_message


def _test_general_(LinkedList: type, last_calls: deque) -> None:
    def add(element: Any) -> None:
        message_prefix = f'linked_list.add({repr(element)})'
        not_raise_error(lambda: linked_list.add(element), message_prefix)
        elements.append(element)

    def clear() -> None:
        message_prefix = 'linked_list.clear()'
        not_raise_error(lambda: linked_list.clear(), message_prefix)
        elements.clear()

    def del_(index: int, raise_=False) -> None:
        def del_element() -> None:
            del linked_list[index]

        message_prefix = f'del linked_list[{index}]'
        raise_error(del_element, message_prefix, IndexError('list index out of range') if raise_ else None)
        if not raise_:
            del elements[index]

    def get(index: int, raise_=False) -> None:
        if raise_:
            message_prefix_getitem = f'linked_list[{index}]'
            message_prefix_get = f'linked_list.get({index})'
        else:
            message_prefix_getitem = f'linked_list[{index}] == {repr(elements[index])}'
            message_prefix_get = f'linked_list.get({index}) == {repr(elements[index])}'

        exception = IndexError('list index out of range')

        result = raise_error(lambda: linked_list[index], message_prefix_getitem, exception if raise_ else None)
        assert isinstance(result, IndexError) if raise_ else result == elements[index]

        result = raise_error(lambda: linked_list.get(index), message_prefix_get, exception if raise_ else None)
        assert isinstance(result, IndexError) if raise_ else result == elements[index]

    def in_(element: Any, not_=False) -> None:
        message_prefix = f'{repr(element)} in linked_list'
        assert not_raise_error(lambda: element not in linked_list if not_ else element in linked_list, message_prefix)

    def insert(index: int, element: Any) -> None:
        message_prefix = f'linked_list.insert({index}, {repr(element)})'
        not_raise_error(lambda: linked_list.insert(index, element), message_prefix)
        elements.insert(index, element)

    def len_() -> None:
        message_prefix = f'len(linked_list) == {len(elements)}'
        assert not_raise_error(lambda: len(linked_list) == len(elements), message_prefix)

    def not_raise_error(function: Callable[[], Any], message_prefix: str) -> Any:
        try:
            result = function()
        except Exception as e:
            last_calls.append(f'{message_prefix} <- {e}')
            raise AssertionError

        last_calls.append(message_prefix)
        return result

    def raise_error(function: Callable[[], Any], message_prefix: str, exception: Exception | None = None) -> Any:
        try:
            result = function()
        except Exception as e:
            if isinstance(e, type(exception)):
                if str(e) == str(exception):
                    last_calls.append(f'{message_prefix} <- {e}')
                    return e
                else:
                    last_calls.append(f'{message_prefix} <- Mensaje de error incorrecto')
            else:
                last_calls.append(f'{message_prefix} <- {e}')

            raise AssertionError
        else:
            if exception:
                last_calls.append(f'{message_prefix} <- No lanza una excepción')
                raise AssertionError

            last_calls.append(message_prefix)
            return result

    def remove(element: Any, raise_=False) -> None:
        message_prefix = f'linked_list.remove({repr(element)})'
        raise_error(
            lambda: linked_list.remove(element), message_prefix, ValueError(f'{repr(element)} not in list') if raise_ else None
        )

        if not raise_:
            elements.remove(element)

    def set_(index: int, element: Any, raise_=False) -> None:
        def setitem_function() -> None:
            linked_list[index] = element

        def set_function() -> None:
            linked_list.set(index, element)

        exception = IndexError('list index out of range')

        message_prefix = f'linked_list[{index}] = {repr(element)}'
        raise_error(setitem_function, message_prefix, exception if raise_ else None)

        message_prefix = f'linked_list.set({index}, {repr(element)}) = {repr(element)}'
        raise_error(set_function, message_prefix, exception if raise_ else None)

        if not raise_:
            elements[index] = element

    def str_() -> None:
        elements_str = _linked_list_str(elements)
        message_prefix = f'str(linked_list) == {elements_str}'
        assert not_raise_error(lambda: str(linked_list) == elements_str, message_prefix)

    elements = []
    linked_list = LinkedList()

    str_()
    len_()

    add(1)
    len_()
    str_()
    add('b')
    str_()
    len_()
    add(None)
    str_()
    len_()
    add(False)
    len_()
    str_()

    in_(1)
    in_('b')
    in_(None)
    in_(2, not_=True)
    str_()
    len_()
    in_('c', not_=True)
    len_()
    str_()

    get(0)
    get(1)
    get(2)
    get(3)
    str_()
    len_()
    get(-4)
    get(-3)
    get(-2)
    get(-1)
    get(-0)
    len_()
    str_()
    get(4, raise_=True)
    get(5, raise_=True)
    get(999, raise_=True)
    str_()
    len_()
    get(-5, raise_=True)
    get(-6, raise_=True)
    get(-999, raise_=True)
    len_()
    str_()

    del_(4, raise_=True)
    len_()
    str_()
    del_(999, raise_=True)
    str_()
    len_()
    del_(-5, raise_=True)
    len_()
    str_()
    del_(-999, raise_=True)
    str_()
    len_()
    del_(3)
    len_()
    str_()
    add(1)
    del_(-1)
    str_()
    len_()
    add(1)
    del_(-4)
    len_()
    str_()
    del_(1)
    del_(0)
    del_(0)
    str_()
    len_()
    del_(0, raise_=True)
    len_()
    str_()
    del_(1, raise_=True)
    del_(-1, raise_=True)
    str_()
    len_()

    get(0, raise_=True)
    get(1, raise_=True)
    get(-1, raise_=True)
    str_()
    len_()
    set_(0, 0, raise_=True)
    set_(1, 1, raise_=True)
    set_(-1, -1, raise_=True)
    str_()
    len_()

    clear()
    str_()
    len_()
    add('flana')
    len_()
    str_()
    clear()
    str_()
    len_()
    add('flana')
    add({'lorem': {1, 2, 3}, (1, 2): [8.5, False]})
    clear()
    str_()
    len_()
    add(('5', 5))
    str_()
    len_()
    del_(0)
    str_()
    len_()
    clear()
    str_()
    len_()
    clear()
    len_()
    str_()
    add(5)
    add(5)
    add(5)
    str_()
    len_()
    clear()
    clear()
    clear()
    str_()
    len_()

    insert(-1, 'a')
    str_()
    len_()
    clear()
    len_()
    insert(999, 'b')
    str_()
    len_()
    clear()
    insert(0, 'c')
    str_()
    len_()
    insert(0, 'hola')
    insert(1, 'adios')
    len_()
    str_()
    insert(3, 'zZzZzZz')
    len_()
    str_()
    insert(-4, -4)
    insert(-6, '-6')
    insert(-999, 'False')
    str_()
    len_()
    del_(0)
    insert(24, 'y')
    str_()
    len_()
    del_(1)
    insert(0, 'z')
    str_()
    len_()
    add(1)
    add(2)
    add(3)
    insert(2, 'adios')
    str_()
    len_()
    insert(len(linked_list), 'ultimo')
    insert(len(linked_list) - 1, 'penultimo')
    insert(len(linked_list) - 2, 'antepenultimo')
    str_()
    len_()
    insert(4, None)
    str_()
    len_()
    insert(1, range(5))
    str_()
    len_()

    set_(0, 0.0)
    str_()
    len_()
    set_(1, '1.11')
    len_()
    str_()
    set_(15, 15.15)
    len_()
    str_()
    set_(-0, '-0')
    len_()
    str_()
    set_(-1, -1j)
    len_()
    str_()
    set_(-16, -16 + 16j)
    len_()
    str_()
    set_(999, '999', raise_=True)
    str_()
    len_()
    set_(-999, '999', raise_=True)
    len_()
    str_()
    del_(10)
    str_()
    len_()
    set_(15, -15, raise_=True)
    set_(-16, -16, raise_=True)
    len_()
    str_()
    clear()
    str_()
    len_()
    set_(0, '0', raise_=True)
    set_(1, '0', raise_=True)
    set_(999, '0', raise_=True)
    len_()
    str_()
    set_(-0, '0', raise_=True)
    set_(-1, '0', raise_=True)
    set_(-999, '0', raise_=True)
    str_()
    len_()

    add(1)
    add(2.5)
    add('3')
    add(2)
    add((1, '2', 'c'))
    add([[], True, False])
    add(3)
    add(None)
    add(1)
    len_()
    str_()
    remove(999, raise_=True)
    str_()
    len_()
    remove(1)
    len_()
    str_()
    remove(2)
    str_()
    len_()
    remove(3)
    len_()
    str_()
    remove((1, '2', 'c'))
    remove(None)
    str_()
    len_()
    remove(1)
    remove([[], True, False])
    remove(2.5)
    remove('3')
    len_()
    str_()


def _test_internal_use(method_name: str) -> tuple[str, str]:
    import main

    result_prefix = f'Reusabilidad en {method_name}: '
    if (
        not isinstance(getattr(main, 'LinkedList', None), type)
        or
        not inspect.isfunction(function := getattr(main.LinkedList, method_name, None))
    ):
        return result_prefix, '...'

    # noinspection PyUnboundLocalVariable
    method_lines = [line for line in inspect.getsource(function).splitlines() if not line.strip().startswith('#')]
    if len(method_lines) == 2 and 'self[' in method_lines[1] and '_' not in method_lines[1]:
        result_message = '✅'
    else:
        result_message = '❌'

    return result_prefix, result_message


def _test_performance(method_name: str, *args: Any, alias: str | None = None) -> tuple[str, str]:
    import main

    result_prefix = f'Rendimiento de {alias or method_name}: '
    if (
        not isinstance(getattr(main, 'LinkedList', None), type)
        or
        not inspect.isfunction(getattr(main.LinkedList, method_name, None))
    ):
        return result_prefix, '...'

    linked_list = main.LinkedList()
    method = getattr(linked_list, method_name)

    try:
        times = []
        for _ in range(100):
            t = time.perf_counter()
            method(*args)
            times.append(time.perf_counter() - t)
        expected_time = sum(times) / len(times)

        for _ in range(1000):
            linked_list.add(1)

        times = []
        for _ in range(100):
            t = time.perf_counter()
            method(*args)
            times.append(time.perf_counter() - t)
        actual_time = sum(times) / len(times)

        performance = actual_time / expected_time
        if performance <= 2:
            result_message = '✅'
        else:
            result_message = f'❌ Ha tardado {round(performance)} veces más que lo esperado'
    except Exception as e:
        result_message = f'❌ <- {e}'

    return result_prefix, result_message


def _test_type_hints() -> tuple[str, str]:
    import main

    result_prefix = 'Type hints:'
    if not isinstance(getattr(main, 'LinkedList', None), type):
        return result_prefix, '...'

    max_score = 13
    score, failed_methods = _assert_methods_type_hints(
        main.LinkedList,
        (
            (('__init__', {}, None),),
            (('__getitem__', {'_index': int}, Any),),
            (('__setitem__', {'_index': int, '_element': Any}, None),),
            (('__delitem__', {'_index': int}, None),),
            (('__iter__', {}, Iterator),),
            (('__len__', {}, int),),
            (('__str__', {}, str), ('__repr__', {}, str)),
            (('add', {'_element': Any}, None),),
            (('clear', {}, None),),
            (('get', {'_index': int}, Any),),
            (('insert', {'_index': int, '_element': Any}, None),),
            (('remove', {'_element': Any}, None),),
            (('set', {'_index': int, '_element': Any}, None),)
        )
    )
    ratio = score / max_score

    result_message_lines = [f"{'✅' if ratio == 1 else '❌'} {ratio:.0%}"]
    for failed_method in failed_methods:
        result_message_lines.append(f"{' ' * _TAB_SIZE}{failed_method}")
    return result_prefix, '\n'.join(result_message_lines)


def test() -> None:
    global _is_test_executed

    if _is_test_executed:
        return

    _is_test_executed = True

    for result_prefix, result_message in (
        _test_general(),
        _test_performance('__len__'),
        _test_performance('add', 1),
        _test_internal_use('get'),
        _test_internal_use('set'),
        _test_type_hints()
    ):
        print(f'{result_prefix:{_LEFT_MARGIN_SPACES}}{result_message}')


_is_test_executed = False
